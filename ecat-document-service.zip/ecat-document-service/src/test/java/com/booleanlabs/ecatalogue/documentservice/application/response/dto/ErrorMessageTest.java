package com.booleanlabs.ecatalogue.documentservice.application.response.dto;

import com.booleanlabs.ecatalogue.documentservice.JavaBeanTester;
import org.junit.jupiter.api.Test;

import java.beans.IntrospectionException;

/**
 * @author dilanka
 * @created 07/01/2024 - 8:12 AM
 * @project ecat-document-service
 */
class ErrorMessageTest {
    @Test
    void testBeanProperties() throws IntrospectionException {
        JavaBeanTester.test(ErrorMessage.class, new ErrorMessage.ErrorMessageBuilder().build());
    }
}