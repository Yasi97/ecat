package com.booleanlabs.ecatalogue.documentservice.application.exception.vm;

import com.booleanlabs.ecatalogue.documentservice.JavaBeanTester;
import org.junit.jupiter.api.Test;

import java.beans.IntrospectionException;

/**
 * @author dilanka
 * @created 07/01/2024 - 8:46 AM
 * @project ecat-document-service
 */
class ErrorFieldTest {
    @Test
    void test() throws IntrospectionException {
        JavaBeanTester.test(ErrorField.class, null);
    }
}