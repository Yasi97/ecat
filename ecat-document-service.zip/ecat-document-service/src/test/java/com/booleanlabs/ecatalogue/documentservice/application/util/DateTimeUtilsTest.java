package com.booleanlabs.ecatalogue.documentservice.application.util;

import com.booleanlabs.ecatalogue.documentservice.JavaBeanTester;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.beans.IntrospectionException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.springframework.test.util.AssertionErrors.assertEquals;

/**
 * @author dilanka
 * @created 07/01/2024 - 8:36 AM
 * @project ecat-document-service
 */
@ExtendWith(MockitoExtension.class)
class DateTimeUtilsTest {
    private DateTimeUtils datetimeUtil;

    @BeforeEach
    void init() {
        datetimeUtil = mock(DateTimeUtils.class);
    }

    @Test
    void testBeanProperties() throws IntrospectionException {
        JavaBeanTester.test(DateTimeUtils.class, datetimeUtil);
    }

    @Test
    void dateFormatterTest() {
        final Date date = new Date();
        final String formattedDate;
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        formattedDate = df.format(date);
        final String body = DateTimeUtils.format(date);
        assertEquals("Original message should be equal", formattedDate, body);
    }


    @Test
    void testNullDate() {
        assertThrows(NullPointerException.class, () -> {
            DateTimeUtils.format(null);
        });
    }

    @Test
    void dateParserTest() {
        final String date = "2021-12-01 12:23:20";
        final LocalDateTime parseDate = LocalDateTime.parse(date, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

        final LocalDateTime result = DateTimeUtils.parse(date);
        assertEquals("Original message should be equal", parseDate, result);
    }
}