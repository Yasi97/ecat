package com.booleanlabs.ecatalogue.documentservice.application.exception;

import com.booleanlabs.ecatalogue.documentservice.BaseTestUtil;
import com.booleanlabs.ecatalogue.documentservice.application.exception.vm.ErrorField;
import com.booleanlabs.ecatalogue.documentservice.application.response.dto.ErrorMessage;
import com.booleanlabs.ecatalogue.documentservice.application.util.MessageUtils;
import com.booleanlabs.ecatalogue.documentservice.application.util.ResponseUtils;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.fasterxml.jackson.databind.exc.MismatchedInputException;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Path;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.core.MethodParameter;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.util.NestedServletException;

import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.Collections;
import java.util.HashSet;
import java.util.Objects;

import static com.booleanlabs.ecatalogue.documentservice.application.constant.ErrorConstants.VALIDATION_FAILURE_ERROR_CODE;
import static org.springframework.test.util.AssertionErrors.assertEquals;
import static org.springframework.test.util.AssertionErrors.assertTrue;

/**
 * @author dilanka
 * @created 07/01/2024 - 10:27 AM
 * @project ecat-document-service
 */
class GlobalExceptionHandlerTest extends BaseTestUtil {
    private static GlobalExceptionHandler globalExceptionHandler;
    @Mock
    private MessageUtils messageUtils;

    @BeforeEach
    void init() throws NoSuchFieldException, IllegalAccessException {
        globalExceptionHandler = new GlobalExceptionHandler(new ResponseUtils(mockHttpServletRequest(null, false), messageUtils), messageUtils);
    }

    @Test
    void testMethodNotAllowedExceptionHandler() {
        final String exceptionMessage = "test Method not allowed ";
        final ResponseEntity<ErrorMessage> responseEntity = globalExceptionHandler
                .methodNotAllowedExceptionHandler(new HttpRequestMethodNotSupportedException(exceptionMessage));
        assertEquals("Original message should be equal", 405, responseEntity.getStatusCodeValue());
    }

    @Test
    void testNoHandlerFoundExceptionExceptionHandler() {
        final String url = "http://localhost:8080/api/test/";
        String method = "Get";
        final HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("Trace_id", "trace-id-123424");
        final ResponseEntity<ErrorMessage> responseEntity = globalExceptionHandler
                .noHandlerFoundExceptionHandler(new NoHandlerFoundException(method, url, httpHeaders));
        assertEquals("Original message should be equal", 404, responseEntity.getStatusCodeValue());
    }

    @Test
    void testHttpMediaTypeNotSupportedExceptionHandler() {
        final HttpMediaTypeNotSupportedException exception = Mockito.mock(HttpMediaTypeNotSupportedException.class);
        final ResponseEntity<ErrorMessage> responseEntity = globalExceptionHandler
                .httpMediaTypeNotSupportedExceptionHandler(exception);
        assertEquals("Original value should be equal", 400, responseEntity.getStatusCodeValue());
    }

    @Test
    void testNestedServletException() {
        final ResponseEntity<ErrorMessage> responseEntity = globalExceptionHandler
                .nestedServletExceptionHandler(new NestedServletException(""));
        assertEquals("Original message should be equal", 400, responseEntity.getStatusCodeValue());
    }

    @Test
    void testHttpMessageNotReadableExceptionHandler1() {

        final HttpMessageNotReadableException exception = Mockito.mock(HttpMessageNotReadableException.class);
        Mockito.when(exception.getCause()).thenReturn(new Throwable());
        Mockito.when(exception.getLocalizedMessage()).thenReturn("Json parse:message");
        final ResponseEntity<ErrorMessage> responseEntity = globalExceptionHandler
                .httpMessageNotReadableExceptionHandler(exception);
        assertEquals("Original message should be equal", 400, responseEntity.getStatusCodeValue());
    }

    @Test
    void testHttpMessageNotReadableExceptionHandler2() {

        final HttpMessageNotReadableException exception = Mockito.mock(HttpMessageNotReadableException.class);
        Mockito.when(exception.getLocalizedMessage()).thenReturn("Required request body is missing:message");
        final ResponseEntity<ErrorMessage> responseEntity = globalExceptionHandler
                .httpMessageNotReadableExceptionHandler(exception);
        assertEquals("Original value should be equal", 400, responseEntity.getStatusCodeValue());
    }

    @Test
    void testMismatchedInputExceptionHandler() {
        final ResponseEntity<ErrorMessage> responseEntity = globalExceptionHandler
                .mismatchedInputExceptionHandler(MismatchedInputException.from(Mockito.mock(JsonParser.class), "message: Failed to deserialize java.time.LocalDateTime:"));
        assertEquals("Original message should be equal", 400, responseEntity.getStatusCodeValue());
    }

    @Test
    void testMethodArgumentTypeMismatchExceptionHandler() {
        final MethodArgumentTypeMismatchException exception = Mockito.mock(MethodArgumentTypeMismatchException.class);
        final ResponseEntity<ErrorMessage> responseEntity = globalExceptionHandler
                .methodArgumentTypeMismatchExceptionHandler(exception);
        assertEquals("Original message should be equal", 400, responseEntity.getStatusCodeValue());
    }

    @Test
    void testMethodArgumentNotValidExceptionHandler() {
        final FieldError fieldError = Mockito.mock(FieldError.class);

        final BindingResult bindingResult = Mockito.mock(BindingResult.class);
        Mockito.when(bindingResult.getFieldErrors()).thenReturn(Collections.singletonList(fieldError));

        final MethodArgumentNotValidException exception = new MethodArgumentNotValidException(Mockito.mock(MethodParameter.class), bindingResult);
        Mockito.when(fieldError.getDefaultMessage()).thenReturn("defaultMessage");

        final ResponseEntity<ErrorMessage> responseEntity = globalExceptionHandler.methodArgumentNotValidExceptionHandler(exception);
        assertEquals("Original message should be equal", messageUtils.getPropertyValue(VALIDATION_FAILURE_ERROR_CODE), Objects.requireNonNull(responseEntity.getBody()).getCode());
        assertTrue("Original errors should be equal", "defaultMessage".equals(responseEntity.getBody().getData().getError().get(0).getMessage()));

    }

    @Test
    void testSQLIntegrityConstraintViolationException() {
        final ResponseEntity<ErrorMessage> responseEntity = globalExceptionHandler
                .sqlIntegrityConstraintViolationExceptionHandler(new SQLIntegrityConstraintViolationException("id"));
        assertEquals("Original message should be equal", 500, responseEntity.getStatusCodeValue());
    }


    @Test
    void testSqlExceptionHandler() {
        final String exceptionMessage = "test sql exception";
        final ResponseEntity<ErrorMessage> responseEntity = globalExceptionHandler
                .sqlExceptionHandler(new SQLException(exceptionMessage));
        assertEquals("Original message should be equal", 500, responseEntity.getStatusCodeValue());
    }

    @Test
    void testDataIntegrityViolationException() {
        final ResponseEntity<ErrorMessage> responseEntity = globalExceptionHandler
                .dataIntegrityViolationExceptionHandler(new DataIntegrityViolationException(""));
        assertEquals("Original value should be equal", 500, responseEntity.getStatusCodeValue());
    }

    @Test
    void testDataAccessExceptionHandler() {
        final String exceptionMessage = "test data access exception";
        final ResponseEntity<ErrorMessage> responseEntity = globalExceptionHandler
                .dataAccessExceptionHandler(new DataAccessException(exceptionMessage) {
                });
        assertEquals("Original message should be equal", 500, responseEntity.getStatusCodeValue());
    }

    @Test
    void testValidationExceptionHandler() {
        final ResponseEntity<ErrorMessage> responseEntity = globalExceptionHandler
                .validationExceptionHandler(new ValidationException(Collections.singletonList(ErrorField.of("code", "field", "message"))));
        assertEquals("Original message should be equal", 400, responseEntity.getStatusCodeValue());
    }

    @Test
    void testNotFoundExceptionHandler() {
        final ResponseEntity<ErrorMessage> responseEntity = globalExceptionHandler
                .notFoundExceptionHandler(new NotFoundException("message", "code"));
        assertEquals("Original message should be equal", "code", Objects.requireNonNull(responseEntity.getBody()).getData().getError().get(0).getCode());
    }

    @Test
    void testNullPointerExceptionHandler() {
        final String exceptionMessage = "test NullPointerException ";
        final ResponseEntity<ErrorMessage> responseEntity = globalExceptionHandler
                .nullPointerExceptionHandler(new NullPointerException(exceptionMessage));
        assertEquals("Original message should be equal", 500, responseEntity.getStatusCodeValue());
    }

    @Test
    void testArrayIndexOutOfBoundsExceptionHandler() {
        final String exceptionMessage = "test ArrayIndexOutOfBoundsException";
        final ResponseEntity<ErrorMessage> responseEntity = globalExceptionHandler
                .arrayIndexOutOfBoundExceptionHandler(new ArrayIndexOutOfBoundsException(exceptionMessage));
        assertEquals("Original value should be equal", 500, responseEntity.getStatusCodeValue());
    }

    @Test
    void testConstraintViolationHandler() {
        final ConstraintViolation<?> mockViolation = Mockito.mock(ConstraintViolation.class);
        Mockito.when(mockViolation.getMessage()).thenReturn("message");

        final Path mockPath = Mockito.mock(Path.class);
        Mockito.when(mockViolation.getPropertyPath()).thenReturn(mockPath);
        Mockito.when(mockPath.toString()).thenReturn("field");

        final ConstraintViolationException exception = new ConstraintViolationException("message", new HashSet<>(Collections.singletonList(mockViolation)));

        final ResponseEntity<ErrorMessage> responseEntity = globalExceptionHandler
                .constraintViolationHandler(exception);
        assertEquals("Original message should be equal", messageUtils.getPropertyValue(VALIDATION_FAILURE_ERROR_CODE), Objects.requireNonNull(responseEntity.getBody()).getCode());
        assertTrue("Original errors should be equal", "message".equals(responseEntity.getBody().getData().getError().get(0).getMessage()));

    }

    @Test
    void testCommonExceptionHandler() {
        final CommonException exception = new CommonException("message", "code", "type", HttpStatus.INTERNAL_SERVER_ERROR, new Exception());
        final ResponseEntity<ErrorMessage> responseEntity = globalExceptionHandler.commonExceptionHandler(exception);

        assertEquals("Original value should be equal", 500, responseEntity.getStatusCodeValue());
    }

    @Test
    void testIllegalArgumentExceptionHandler() {
        final IllegalArgumentException exception = new IllegalArgumentException("message");
        final ResponseEntity<ErrorMessage> responseEntity = globalExceptionHandler.illegalArgumentExceptionHandler(exception);

        assertEquals("Original value should be equal", 400, responseEntity.getStatusCodeValue());
    }

    @Test
    void testIllegalArgumentExceptionWhenInvalidFormatExceptionHandler() {
        final IllegalArgumentException exception = new IllegalArgumentException("message", Mockito.mock(InvalidFormatException.class));
        final ResponseEntity<ErrorMessage> responseEntity = globalExceptionHandler.illegalArgumentExceptionHandler(exception);

        assertEquals("Original value should be equal", 400, responseEntity.getStatusCodeValue());
    }

    @Test
    void testGlobalExceptionHandler() {
        final String exceptionMessage = "test GlobalException";
        final ResponseEntity<ErrorMessage> responseEntity = globalExceptionHandler
                .globalExceptionHandler(new ArithmeticException(exceptionMessage));
        assertEquals("Original message should be equal", 500, responseEntity.getStatusCodeValue());
    }
}