package com.booleanlabs.ecatalogue.documentservice.external.repository.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.when;

/**
 * @author dilanka
 * @created 21/01/2024 - 9:50 AM
 * @project ecat-document-service
 */
@ExtendWith(MockitoExtension.class)
class RepositoryUtilsTest {
    @Mock
    private ResultSet resultSet;

    @Test
    void getLongOrDefault() throws SQLException {
        //when
        when(resultSet.getLong("test")).thenReturn(5L);

        //then
        Long test = assertDoesNotThrow(() -> RepositoryUtils.getLongOrDefault(resultSet, "test", 50L));

        assertThat(test).isEqualTo(5L);
    }

    @Test
    void getLongOrDefaultTest() throws SQLException {

        //when
        when(resultSet.getLong("test")).thenThrow(new RuntimeException("Exception"));

        //then
        Long test = assertDoesNotThrow(() -> RepositoryUtils.getLongOrDefault(resultSet, "test", 50L));

        assertThat(test).isEqualTo(50L);
    }

    @Test
    void getStringOrDefault() throws SQLException {
        //when
        when(resultSet.getString("test")).thenReturn("value");

        //then
        String test = assertDoesNotThrow(() -> RepositoryUtils.getStringOrDefault(resultSet, "test", "default value"));

        assertThat(test).isEqualTo("value");
    }

    @Test
    void getStringOrDefaultTest() throws SQLException {
        //when
        when(resultSet.getString("test")).thenThrow(new RuntimeException("Exception"));

        //then
        String test = assertDoesNotThrow(() -> RepositoryUtils.getStringOrDefault(resultSet, "test", "default value"));

        assertThat(test).isEqualTo("default value");
    }

    @Test
    void addPagination() {
        //given
        final String query = "select * from test";

        //when
        final String result = RepositoryUtils.addPagination(query, 10, 1);

        //then
        assertThat(result).isEqualTo("select * from test OFFSET " +
                0 +
                " ROWS FETCH NEXT " +
                10 +
                " ROWS ONLY");
    }

    @Test
    void convertToCount() {
        //given
        final String query = "select * from test";

        //when
        final String result = RepositoryUtils.convertToCount(query);

        //then
        assertThat(result).isEqualTo("SELECT COUNT(*) FROM test");
    }
}