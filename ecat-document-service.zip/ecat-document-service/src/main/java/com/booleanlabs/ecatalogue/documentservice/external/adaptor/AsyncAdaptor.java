package com.booleanlabs.ecatalogue.documentservice.external.adaptor;

import com.booleanlabs.ecatalogue.documentservice.application.exception.AsyncExecutorException;
import com.booleanlabs.ecatalogue.documentservice.domain.boundary.AsyncAdaptorInterface;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Objects;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@Component
public class AsyncAdaptor implements AsyncAdaptorInterface {

    private final TaskExecutor executor;
    private static final String ASYNC_EXECUTOR = "asyncExecutor";

    @Value("${executor.default.timeout}")
    private Long defaultTimeOut;

    public AsyncAdaptor(@Qualifier(ASYNC_EXECUTOR) TaskExecutor executor) {
        this.executor = executor;
    }

    /**
     * Execute provided tasks in parallel. Http Request context will be propagated.
     * Complete when all tasks are completed.
     *
     * @param timeOut Specific TimeOut for input tasks
     * @param tasks   Tasks to run.
     */
    @Override
    @SneakyThrows
    public void runAll(Long timeOut, Runnable... tasks) {

        CompletableFuture<?>[] completableFutures = Arrays.stream(tasks)
                .map(task -> CompletableFuture.runAsync(task, executor)).toList()
                .toArray(new CompletableFuture[]{});

        try {
            CompletableFuture.allOf(completableFutures)
                    .get(Objects.nonNull(timeOut) ? timeOut : defaultTimeOut, TimeUnit.MILLISECONDS);
        } catch (CancellationException | TimeoutException ex) {
            throw new AsyncExecutorException(ex);
        } catch (ExecutionException ex) {
            throw ex.getCause();
        }
    }

    /**
     * Run provided Task in Async.
     *
     * @param task Task to run.
     */
    @Override
    public void runAsync(Runnable task) {

        executor.execute(task);
    }
}
