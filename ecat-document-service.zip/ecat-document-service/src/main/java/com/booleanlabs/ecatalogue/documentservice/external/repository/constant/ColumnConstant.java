package com.booleanlabs.ecatalogue.documentservice.external.repository.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * @author dilanka
 * @created 20/01/2024 - 6:55 PM
 * @project ecat-document-service
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ColumnConstant {
    public static final String ID = "ID";
}
