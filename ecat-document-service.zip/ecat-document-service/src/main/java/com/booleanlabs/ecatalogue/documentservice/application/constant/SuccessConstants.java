package com.booleanlabs.ecatalogue.documentservice.application.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * @author dilanka
 * @created 07/01/2024 - 8:02 PM
 * @project ecat-document-service
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class SuccessConstants {
    public static final String SUCCESS_MESSAGE = "success";
    public static final String ACTION_SUCCESS_MESSAGE = "action.success";
    public static final String SUCCESS_CODE = "0000";
}
