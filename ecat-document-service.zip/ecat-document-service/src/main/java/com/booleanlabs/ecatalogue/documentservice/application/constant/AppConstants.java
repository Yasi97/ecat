package com.booleanlabs.ecatalogue.documentservice.application.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * @author dilanka
 * @created 06/01/2024 - 9:45 PM
 * @project ecat-document-service
 */

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class AppConstants {
    public static final String APP_ROOT_V1_WEB = "document-service/v1/web";

    public static final String COLON = ":";
    public static final String SYSTEM_USER = "SYSTEM";

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class Actions {
        public static final String CREATE = "/create";
        public static final String UPDATE = "/update";
        public static final String DELETE = "/delete/{id}";
        public static final String LOAD = "/load";
        public static final String LOAD_ALL = "/load-all";
        public static final String SEARCH = "/search";
        public static final String READ = "/read/{id}";

    }
}

