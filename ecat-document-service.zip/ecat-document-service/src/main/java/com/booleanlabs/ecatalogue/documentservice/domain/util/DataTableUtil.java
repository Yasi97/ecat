package com.booleanlabs.ecatalogue.documentservice.domain.util;

import com.booleanlabs.ecatalogue.documentservice.application.request.dto.BaseSearchRequest;
import lombok.experimental.UtilityClass;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.util.ObjectUtils;

import java.util.stream.Collectors;

/**
 * Data table pagination and ordering util
 *
 * @author dilanka
 * @created 0/01/2024 - 11:28 AM
 * @project ecat-document-service
 */
@UtilityClass
public class DataTableUtil {

    @SuppressWarnings("squid:S6204")
    public static Pageable createPageRequest(final BaseSearchRequest searchDTO) {
        if (!searchDTO.getOrders().isEmpty()) {
            return PageRequest.of(
                    searchDTO.getCurrentPage(),
                    searchDTO.getItemPerPage(),
                    Sort.by(
                            searchDTO.getOrders().stream().map(orderBy -> new Sort.Order(orderBy.getSortingDirection(), orderBy.getSortingField())).collect(Collectors.toList())
                    )
            );
        } else if (!ObjectUtils.isEmpty(searchDTO.getSortingFields())) {
            return PageRequest.of(
                    searchDTO.getCurrentPage(),
                    searchDTO.getItemPerPage(),
                    Sort.by(
                            searchDTO.getSortingDirection(),
                            searchDTO.getSortingFields()
                    ));
        } else {
            return PageRequest.of(
                    searchDTO.getCurrentPage(),
                    searchDTO.getItemPerPage(),
                    Sort.by(
                            searchDTO.getSortingDirection(),
                            searchDTO.getSortingField()
                    ));
        }
    }
}
