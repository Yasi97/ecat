package com.booleanlabs.ecatalogue.documentservice.domain.dto;

/**
 * @author dilanka
 * @created 20/01/2024 - 8:58 PM
 * @project ecat-document-service
 */
public enum OperationType {
    READ,UPDATE
}
