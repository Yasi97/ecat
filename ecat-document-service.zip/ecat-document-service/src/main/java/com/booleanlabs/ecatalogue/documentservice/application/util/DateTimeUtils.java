package com.booleanlabs.ecatalogue.documentservice.application.util;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import static com.booleanlabs.ecatalogue.documentservice.application.constant.PatternConstants.PATTERN_DATE_FORMAT;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class DateTimeUtils {
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern(PATTERN_DATE_FORMAT);

    /**
     * Convert Date to Required String format
     *
     * @param date Date
     * @return formatted date in string
     */
    public static String format(Date date) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(PATTERN_DATE_FORMAT);
        return simpleDateFormat.format(date);
    }

    /**
     * Convert String to Required LocalDateTime format
     *
     * @param date date
     * @return parsed date to LocalDateTime
     */
    public static LocalDateTime parse(String date) {
        return LocalDateTime.parse(date, DATE_TIME_FORMATTER);
    }
}
