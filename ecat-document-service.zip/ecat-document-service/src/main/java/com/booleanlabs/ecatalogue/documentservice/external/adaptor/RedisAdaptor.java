package com.booleanlabs.ecatalogue.documentservice.external.adaptor;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * @author dilanka
 * @created 14/01/2024 - 9:29 AM
 * @project ecat-backend
 */
@Component
@RequiredArgsConstructor
public class RedisAdaptor<H, K, V> implements RedisOperationsInterface<H, K, V> {
    private final RedisTemplate<H, V> redisTemplate;
    private HashOperations<H, K, V> hashOperations;

    @PostConstruct
    private void postConstruct() {
        this.hashOperations = this.redisTemplate.opsForHash();
    }

    @Override
    public void save(H key, K hashKey, V value) {
        //creates one record in Redis DB if record with that hashKey is not present
        hashOperations.putIfAbsent(key, hashKey, value);
    }

    @Override
    public void update(H key, K hashKey, V value) {
        hashOperations.put(key, hashKey, value);
    }

    @Override
    public Map<K, V> getAll(H key) {
        return hashOperations.entries(key);
    }

    @Override
    public void saveAll(H key, Map<K, V> map) {
        hashOperations.putAll(key, map);
    }

    @Override
    public boolean hasKey(H key, K hashKey) {
        return hashOperations.hasKey(key, hashKey);
    }

    @Override
    public void delete(H key, K hashKey) {
        hashOperations.delete(key, hashKey);
    }

    @Override
    public void deleteAll(H key) {
        final Map<K, V> all = this.getAll(key);
        all.keySet().forEach(hashKey -> this.delete(key, hashKey));
    }

    @Override
    public V getOne(H key, K hashKey) {
        return hashOperations.get(key, hashKey);
    }

    //implement a way to search from a list by given `key`
}
