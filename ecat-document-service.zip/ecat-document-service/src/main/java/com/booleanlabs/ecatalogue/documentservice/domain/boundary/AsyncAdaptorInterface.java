package com.booleanlabs.ecatalogue.documentservice.domain.boundary;

public interface AsyncAdaptorInterface {

    void runAll(Long timeout, Runnable... tasks);

    void runAsync(Runnable task);

}
