package com.booleanlabs.ecatalogue.documentservice.application.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * @author dilanka
 * @created 06/01/2024 - 9:36 PM
 * @project ecat-document-service
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ErrorConstants {
    /* Error Types */
    public static final String GLOBAL_ERROR_TYPE = "error.type.global";
    public static final String VALIDATION_ERROR_TYPE = "error.type.validation";
    public static final String DB_ERROR_TYPE = "error.type.db";
    public static final String METHOD_NOT_ALLOWED_ERROR_TYPE = "error.type.methodNotAllowed";
    public static final String BUSINESS_ERROR_TYPE = "error.type.business";
    public static final String API_ERROR_TYPE = "error.type.api";
    public static final String EXECUTION_ERROR_TYPE = "error.type.execution";

    /* Error Codes */
    public static final String CONSTRAINT_VIOLATION_ERROR_CODE = "error.code.0001";
    public static final String VALIDATION_ERROR_CODE = "error.code.0001";
    public static final String INVALID_DATA_FORMAT_ERROR_CODE = "error.code.0002";
    public static final String NESTED_SERVLET_ERROR_CODE = "error.code.0002";
    public static final String HTTP_MESSAGE_NOT_READABLE_ERROR_CODE = "error.code.0002";
    public static final String SYSTEM_ERROR_CODE = "error.code.0006";
    public static final String DATABASE_ERROR_CODE = "error.code.0007";
    public static final String VALIDATION_FAILURE_ERROR_CODE = "error.code.0999";
    public static final String REQUEST_BODY_MISSING_ERROR_CODE = "error.code.0018";
    public static final String MEDIA_TYPE_NOT_SUPPORTED_ERROR_CODE = "error.code.0019";
    public static final String JSON_PARSE_ERROR_CODE = "error.code.0021";
    public static final String METHOD_NOT_ALLOWED_ERROR_CODE = "error.code.0023";
    public static final String INVALID_URL_ERROR_CODE = "error.code.0025";
    public static final String INVALID_RANGE_ERROR_CODE = "error.code.0026";
    public static final String METHOD_ARGUMENT_TYPE_MIS_MATCH_ERROR_CODE = "error.code.0027";
    public static final String DATA_INTEGRITY_VIOLATION_ERROR_CODE = "error.code.0028";
    public static final String RESOURCE_NOT_FOUND_ERROR_CODE = "error.code.0029";
    public static final String NULL_POINTER_ERROR_CODE = "error.code.0030";
    public static final String SQL_EXCEPTION_ERROR_CODE = "error.code.0031";
    public static final String SQL_INTEGRITY_VIOLATION_ERROR_CODE = "error.code.0032";
    public static final String DATA_ACCESS_EXCEPTION_ERROR_CODE = "error.code.0033";
    public static final String GLOBAL_ERROR_CODE = "error.code.0034";
    public static final String ARRAY_INDEX_OUT_OF_BOUND_ERROR_CODE = "error.code.0035";
    public static final String EXECUTION_ERROR_CODE = "error.code.0039";
    public static final String TIMEOUT_EXCEPTION_ERROR_CODE = "error.code.0040";
    public static final String CANCELLATION_EXCEPTION_ERROR_CODE = "error.code.0041";
    public static final String MISSING_PATH_VARIABLE_ERROR_CODE = "error.code.0042";
    public static final String MISSING_REQUEST_PARAMETER_ERROR_CODE = "error.code.0043";
    public static final String MISSING_REQUEST_HEADER_ERROR_CODE = "error.code.0044";

    /* Error Messages */
    public static final String DATA_TYPE_MISMATCH_ERROR_MESSAGE = "error.message.dataTypeMissMatch";
    public static final String HTTP_MESSAGE_NOT_READABLE_ERROR_MESSAGE = "error.message.messageNotReadable";
    public static final String INVALID_DATA_FORMAT_ERROR_MESSAGE = "error.message.invalidDataFormat";
    public static final String SYSTEM_ERROR_MESSAGE = "error.message.systemError";
    public static final String DATABASE_ERROR_MESSAGE = "error.message.databaseError";
    public static final String VALIDATION_FAILURE_ERROR_MESSAGE = "error.message.validationFailure";
    public static final String REQUEST_BODY_MISSING_ERROR_MESSAGE = "error.message.requestBodyMissing";
    public static final String JSON_PARSE_ERROR_MESSAGE = "error.message.jsonParseError";
    public static final String MEDIA_TYPE_NOT_SUPPORTED_ERROR_MESSAGE = "error.message.mediaTypeNotSupported";
    public static final String METHOD_NOT_ALLOWED_ERROR_MESSAGE = "error.message.methodNotAllowed";
    public static final String INVALID_URL_ERROR_MESSAGE = "error.message.invalidUrl";
    public static final String INVALID_RANGE_ERROR_MESSAGE = "error.message.invalidRange";
    public static final String METHOD_ARGUMENT_TYPE_MISMATCH_ERROR_MESSAGE = "error.message.methodArgumentTypeMismatch";
    public static final String DATA_INTEGRITY_VIOLATION_ERROR_MESSAGE = "error.message.dataIntegrityViolation";
    public static final String RESOURCE_NOT_FOUND_ERROR_MESSAGE = "error.message.resourceNotFound";
    public static final String NULL_POINTER_ERROR_MESSAGE = "error.message.nullPointer";
    public static final String SQL_EXCEPTION_ERROR_MESSAGE = "error.message.sqlException";
    public static final String SQL_INTEGRITY_VIOLATION_ERROR_MESSAGE = "error.message.sqlIntegrityViolation";
    public static final String DATA_ACCESS_EXCEPTION_ERROR_MESSAGE = "error.message.dataAccessException";
    public static final String GLOBAL_ERROR_MESSAGE = "error.message.global";
    public static final String ARRAY_INDEX_OUT_OF_BOUND_ERROR_MESSAGE = "error.message.arrayIndexOutOfBound";
    public static final String EXECUTION_ERROR_MESSAGE = "error.message.execution";
    public static final String TIMEOUT_EXCEPTION_ERROR_MESSAGE = "error.message.timeoutException";
    public static final String CANCELLATION_EXCEPTION_ERROR_MESSAGE = "error.message.cancellationException";
    public static final String MISSING_PATH_VARIABLE_ERROR_MESSAGE = "error.message.missingPathVariable";
    public static final String MISSING_REQUEST_PARAMETER_ERROR_MESSAGE = "error.message.missingRequestParameter";
    public static final String MISSING_REQUEST_HEADER_ERROR_MESSAGE = "error.message.missingRequestHeader";
    public static final String ERROR_MESSAGE_RECORD_EXISTS = "error.message.record.exists";

    /* Request Entity Validation */
    public static final String ENTITY_ERROR_NOT_NULL = "{error.0003.common}";
    public static final String ENTITY_ERROR_MAX_SIZE = "{error.0004.common}";
    public static final String ENTITY_ERROR_NOT_EMPTY = "{error.0012.common}";
    public static final String NEGATIVE_VALUE_ERROR = "{error.0005.common}";

    public static final String ERROR_0045 = "error.0045";
    public static final String ERROR_9000 = "error.9000";
    public static final String ERROR_9001 = "error.9001";
    public static final String ERROR_9002 = "error.9002";
    public static final String ERROR_9003 = "error.9003";
    public static final String ERROR_9004 = "error.9004";
    public static final String ERROR_9005 = "error.9005";
    public static final String ERROR_9006 = "error.9006";
}
