package com.booleanlabs.ecatalogue.customerservice.application.exception;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

/**
 * @author dilanka
 * @created 07/01/2024 - 8:44 PM
 * @project master-data-service
 */
class AsyncExecutorExceptionTest {
    @Test
    void testException() {
        final AsyncExecutorException exception = new AsyncExecutorException(new Throwable("Async Exception Message"));
        Assertions.assertEquals("java.lang.Throwable: Async Exception Message", exception.getLocalizedMessage(), "message should be Async Exception Message");

    }
}