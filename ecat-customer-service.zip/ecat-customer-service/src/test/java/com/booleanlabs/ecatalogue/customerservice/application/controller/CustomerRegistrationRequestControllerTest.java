package com.booleanlabs.ecatalogue.customerservice.application.controller;

import com.booleanlabs.ecatalogue.customerservice.application.request.dto.customerRegistrationRequest.CustomerRegistrationRequestCreateDto;
import com.booleanlabs.ecatalogue.customerservice.application.request.dto.customerRegistrationRequest.CustomerRegistrationRequestSearchRequest;
import com.booleanlabs.ecatalogue.customerservice.application.request.dto.customerRegistrationRequest.UpdateCustomerRegistrationRequestStatusRequest;
import com.booleanlabs.ecatalogue.customerservice.application.response.dto.SuccessMessage;
import com.booleanlabs.ecatalogue.customerservice.application.util.DateTimeUtils;
import com.booleanlabs.ecatalogue.customerservice.application.util.ResponseUtils;
import com.booleanlabs.ecatalogue.customerservice.application.validator.RequestEntityValidator;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.BaseSearchResponseDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.CustomerRegistrationRequest.CustomerRegistrationRequestDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.CustomerRegistrationRequest.CustomerRegistrationRequestSearchDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.CustomerRegistrationRequest.UpdateCustomerRegistrationRequestStatusDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.entities.CustomerRegistrationRequestSearchRequestEntity;
import com.booleanlabs.ecatalogue.customerservice.domain.service.CustomerRegistrationRequestService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.booleanlabs.ecatalogue.customerservice.application.constant.SuccessConstants.SUCCESS_CODE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.SuccessConstants.SUCCESS_MESSAGE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.refEq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class CustomerRegistrationRequestControllerTest {

    @Mock
    private ResponseUtils responseUtils;
    @Mock
    private CustomerRegistrationRequestService customerRegistrationRequestService;
    @Mock
    private RequestEntityValidator validator;
    @Mock
    private ObjectMapper mapper;
    @InjectMocks
    private CustomerRegistrationRequestController customerRegistrationRequestController;

    @BeforeEach
    void init() {
    }

    @Test
    void createCustomerRegistrationRequestTest() {

        final CustomerRegistrationRequestCreateDto customerRegistrationRequestCreateDto =
                new CustomerRegistrationRequestCreateDto(1L, 1L, "companyName", "purpose", "firstName", "lastName", "000000", "designation", "email@sample.com");

        CustomerRegistrationRequestDomainDto customerRegistrationRequestDomainDto =
                mapper.convertValue(customerRegistrationRequestCreateDto, CustomerRegistrationRequestDomainDto.class);

        Map<String, String> serviceResponse = new HashMap<>();
        serviceResponse.put("message", "Request been submitted. We will contact you soon");

        final SuccessMessage<Map<String, String>> successMessageBuilder = SuccessMessage.<Map<String, String>>builder()
                .code(SUCCESS_CODE)
                .data(serviceResponse)
                .message(SUCCESS_MESSAGE)
                .timestamp(DateTimeUtils.format(new Date()))
                .build();
        final ResponseEntity<SuccessMessage<Map<String, String>>> successMessage = ResponseEntity.status(HttpStatus.CREATED).body(successMessageBuilder);

        Mockito.when(mapper.convertValue(refEq(customerRegistrationRequestCreateDto), eq(CustomerRegistrationRequestDomainDto.class))).thenReturn(customerRegistrationRequestDomainDto);
        Mockito.when(customerRegistrationRequestService.createCustomerRegistrationRequest(refEq(customerRegistrationRequestDomainDto))).thenReturn(serviceResponse);
        when(responseUtils.wrapSuccess(refEq(serviceResponse), refEq(HttpStatus.CREATED))).thenReturn(successMessage);

        ResponseEntity<SuccessMessage<Map<String, String>>> response = assertDoesNotThrow(() -> customerRegistrationRequestController.createCustomerRegistrationRequest(customerRegistrationRequestCreateDto));

        Assertions.assertEquals(response.getStatusCode(), HttpStatus.CREATED);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        assertThat(customerRegistrationRequestCreateDto).hasNoNullFieldsOrProperties();
    }


    void searchCustomerRegistrationRequestsTest() {
        final CustomerRegistrationRequestSearchRequest customerRegistrationRequestSearchRequest =
                new CustomerRegistrationRequestSearchRequest(1, 1, "searchText", "dateFrom", "dateTo", 1L);

        CustomerRegistrationRequestSearchRequestEntity customerRegistrationRequestSearchRequestDomainDto =
                mapper.convertValue(customerRegistrationRequestSearchRequest, CustomerRegistrationRequestSearchRequestEntity.class);

        CustomerRegistrationRequestSearchDto customerRegistrationRequestSearchDto =
                new CustomerRegistrationRequestSearchDto();
        customerRegistrationRequestSearchDto.setRequestId(1L);

        List<CustomerRegistrationRequestSearchDto> customerRegistrationRequestSearchDtos =
                Arrays.asList(customerRegistrationRequestSearchDto);

        BaseSearchResponseDomainDto<CustomerRegistrationRequestSearchDto> baseSearchResponseDomainDto =   new BaseSearchResponseDomainDto();
        baseSearchResponseDomainDto.setItems(customerRegistrationRequestSearchDtos);

        final SuccessMessage<BaseSearchResponseDomainDto> successMessageBuilder = SuccessMessage.<BaseSearchResponseDomainDto>builder()
                .code(SUCCESS_CODE)
                .data(baseSearchResponseDomainDto)
                .message(SUCCESS_MESSAGE)
                .timestamp(DateTimeUtils.format(new Date()))
                .build();
        final ResponseEntity<SuccessMessage<BaseSearchResponseDomainDto>> successMessage = ResponseEntity.status(HttpStatus.OK).body(successMessageBuilder);

        Mockito.when(mapper.convertValue(refEq(customerRegistrationRequestSearchRequest), eq(CustomerRegistrationRequestSearchRequestEntity.class))).thenReturn(customerRegistrationRequestSearchRequestDomainDto);
        Mockito.when(customerRegistrationRequestService.searchCustomerRegistrationRequests(refEq(customerRegistrationRequestSearchRequestDomainDto))).thenReturn(baseSearchResponseDomainDto);
    }

    @Test
    void updateCustomerRegistrationRequestStatusTest() {

        final UpdateCustomerRegistrationRequestStatusRequest updateCustomerRegistrationRequestStatusRequest =
                new UpdateCustomerRegistrationRequestStatusRequest(1L, 1L);

        UpdateCustomerRegistrationRequestStatusDomainDto updateCustomerRegistrationRequestStatusDomainDto =
                mapper.convertValue(updateCustomerRegistrationRequestStatusRequest, UpdateCustomerRegistrationRequestStatusDomainDto.class);

        Map<String, String> serviceResponse = new HashMap<>();
        serviceResponse.put("message", "Request been submitted. We will contact you soon");

        final SuccessMessage<Map<String, String>> successMessageBuilder = SuccessMessage.<Map<String, String>>builder()
                .code(SUCCESS_CODE)
                .data(serviceResponse)
                .message(SUCCESS_MESSAGE)
                .timestamp(DateTimeUtils.format(new Date()))
                .build();
        final ResponseEntity<SuccessMessage<Map<String, String>>> successMessage = ResponseEntity.status(HttpStatus.OK).body(successMessageBuilder);

        Mockito.when(mapper.convertValue(refEq(updateCustomerRegistrationRequestStatusRequest), eq(UpdateCustomerRegistrationRequestStatusDomainDto.class))).thenReturn(updateCustomerRegistrationRequestStatusDomainDto);
        Mockito.when(customerRegistrationRequestService.updateCustomerRegistrationRequestStatus(refEq(updateCustomerRegistrationRequestStatusDomainDto))).thenReturn(serviceResponse);
        when(responseUtils.wrapSuccess(refEq(serviceResponse), refEq(HttpStatus.OK))).thenReturn(successMessage);

        ResponseEntity<SuccessMessage<Map<String, String>>> response = assertDoesNotThrow(() -> customerRegistrationRequestController.updateCustomerRegistrationRequestStatus(updateCustomerRegistrationRequestStatusRequest));

        Assertions.assertEquals(response.getStatusCode(), HttpStatus.OK);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
    }
}
