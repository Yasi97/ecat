package com.booleanlabs.ecatalogue.customerservice.application.exception;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

/**
 * @author dilanka
 * @created 07/01/2024 - 11:01 AM
 * @project master-data-service
 */
class CommonExceptionTest {
    @Test
    void testExceptionOne() {
        final CommonException commonException = new CommonException("Test Account Exception", "code", "type", HttpStatus.BAD_REQUEST);
        Assertions.assertEquals("Test Account Exception", commonException.getMessage(), "code should be tests");
        Assertions.assertEquals("code", commonException.getCode(), "type should be tests");
        Assertions.assertEquals("type", commonException.getType(), "type should be tests");
        Assertions.assertEquals(HttpStatus.BAD_REQUEST, commonException.getStatus(), "status should be OK");

    }

    @Test
    void testExceptionTwo() {
        final CommonException commonExceptionNew = new CommonException("Test Account Exception", "code", "type", HttpStatus.BAD_REQUEST, null);
        Assertions.assertEquals("Test Account Exception", commonExceptionNew.getMessage(), "code should be tests");
        Assertions.assertEquals("code", commonExceptionNew.getCode(), "type should be tests");
        Assertions.assertEquals("type", commonExceptionNew.getType(), "type should be tests");
        Assertions.assertEquals(HttpStatus.BAD_REQUEST, commonExceptionNew.getStatus(), "status should be OK");

    }

}