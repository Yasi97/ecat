package com.booleanlabs.ecatalogue.customerservice.application.request.dto;

import com.booleanlabs.ecatalogue.customerservice.JavaBeanTester;
import org.junit.jupiter.api.Test;

import java.beans.IntrospectionException;

/**
 * @author dilanka
 * @created 08/01/2024 - 12:56 PM
 * @project ecat-backend
 */
class BaseSearchRequestTest {
    @Test
    void testBeanProperties() throws IntrospectionException {
        JavaBeanTester.test(BaseSearchRequest.class, new BaseSearchRequest());
    }
}