package com.booleanlabs.ecatalogue.customerservice.application.exception;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import static org.junit.jupiter.api.Assertions.assertEquals;


/**
 * @author dilanka
 * @created 09/01/2024 - 10:42 PM
 * @project customer-service
 */
class ApiResponseExceptionTest {
    private ApiResponseException apiResponseException;

    @BeforeEach
    public void init() {
        apiResponseException = new ApiResponseException("message", HttpStatus.INTERNAL_SERVER_ERROR, null);
    }

    @Test
    void test() {
        assertEquals("message", apiResponseException.getMessage());
        assertEquals(500, apiResponseException.getStatus().value());
    }
}