package com.booleanlabs.ecatalogue.customerservice.application.response.dto;

import com.booleanlabs.ecatalogue.customerservice.JavaBeanTester;
import org.junit.jupiter.api.Test;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;

import java.beans.IntrospectionException;

/**
 * @author dilanka
 * @created 08/01/2024 - 12:58 PM
 * @project ecat-backend
 */
class BaseSearchResponseDtoTest {
    @Test
    void testBeanProperties() throws IntrospectionException {
        JavaBeanTester.test(BaseSearchResponseDto.class, BaseSearchResponseDto.builder().build());
    }

    @Test
    void testBeanPropertiesTwo() throws IntrospectionException {
        JavaBeanTester.test(BaseSearchResponseDto.class, BaseSearchResponseDto.builder().build().calculatePageable(Page.empty()));
    }
}