package com.booleanlabs.ecatalogue.customerservice.application.response.dto;

import com.booleanlabs.ecatalogue.customerservice.JavaBeanTester;
import org.junit.jupiter.api.Test;

import java.beans.IntrospectionException;

/**
 * @author dilanka
 * @created 07/01/2024 - 8:12 AM
 * @project master-data-service
 */
class ErrorMessageTest {
    @Test
    void testBeanProperties() throws IntrospectionException {
        JavaBeanTester.test(ErrorMessage.class, new ErrorMessage.ErrorMessageBuilder().build());
    }
}