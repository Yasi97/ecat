package com.booleanlabs.ecatalogue.customerservice.domain.service;

import com.booleanlabs.ecatalogue.customerservice.application.util.MessageUtils;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.CustomerRegistrationRequest.CustomerRegistrationRequestDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.entities.CustomerRegistrationRequestEntity;
import com.booleanlabs.ecatalogue.customerservice.external.repository.CustomerRegistrationRequestRepository;
import com.booleanlabs.ecatalogue.customerservice.external.repository.CustomerRegistrationRequestStatusRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class CustomerRegistrationRequestServiceTest {


    private ObjectMapper objectMapper;
    @Mock
    private MessageUtils messageUtils;
    @Mock
    private CustomerRegistrationRequestRepository customerRegistrationRequestRepository;
    @Mock
    private CustomerRegistrationRequestStatusRepository customerRegistrationRequestStatusRepository;
    @InjectMocks
    private CustomerRegistrationRequestService customerRegistrationRequestService;

    @BeforeEach
    void init() {
        MockitoAnnotations.openMocks(this);
    }


    void createCustomerRegistrationRequestTest() {


    }


    void testCreateCustomerRegistrationRequestSuccess() {
        CustomerRegistrationRequestDomainDto customerRegistrationRequestDomainDto
                = new CustomerRegistrationRequestDomainDto(1L, 1L, 1L, 1L, "companyName", "purpose", "firstName", "lastName", "000000", "designation", "email@sample.com");
        customerRegistrationRequestService.createCustomerRegistrationRequest(customerRegistrationRequestDomainDto);

        final CustomerRegistrationRequestEntity customerRegistrationRequestEntity
                = objectMapper.convertValue(customerRegistrationRequestDomainDto, CustomerRegistrationRequestEntity.class);



        when(customerRegistrationRequestStatusRepository.getStatusIdByStatusValue(any())).thenReturn(1L);
        when(customerRegistrationRequestRepository.save(any())).thenReturn(1);


        CustomerRegistrationRequestDomainDto requestDto = new CustomerRegistrationRequestDomainDto();

        Map<String, String> result = customerRegistrationRequestService.createCustomerRegistrationRequest(requestDto);


        assertEquals("Success message", result.get("message"));
    }
}
