package com.booleanlabs.ecatalogue.customerservice.application.request.dto.customer;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.ENTITY_ERROR_NOT_NULL;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CustomerDeleteDto {

    @NotNull(message = ENTITY_ERROR_NOT_NULL)
    private Long customerId;

    private Long newAdminId;
}
