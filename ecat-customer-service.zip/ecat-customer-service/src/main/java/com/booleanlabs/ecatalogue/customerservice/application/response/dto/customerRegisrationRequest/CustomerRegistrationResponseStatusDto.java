package com.booleanlabs.ecatalogue.customerservice.application.response.dto.customerRegisrationRequest;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerRegistrationResponseStatusDto {

    private Long statusId;
    private String statusName;
    private String statusColorCode;
}
