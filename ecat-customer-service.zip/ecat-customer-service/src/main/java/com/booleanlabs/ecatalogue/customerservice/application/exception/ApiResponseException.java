package com.booleanlabs.ecatalogue.customerservice.application.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;

public class ApiResponseException extends RuntimeException {

    @Getter
    private final HttpStatus status;

    /**
     * Api Response Exception
     *
     * @param message Message
     * @param status  Status
     * @param cause   Cause
     */
    public ApiResponseException(String message, HttpStatus status, Throwable cause) {
        super(message, cause);
        this.status = status;
    }
}
