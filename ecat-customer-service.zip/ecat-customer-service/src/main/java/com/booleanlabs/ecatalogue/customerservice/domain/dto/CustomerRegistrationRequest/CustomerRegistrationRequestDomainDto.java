package com.booleanlabs.ecatalogue.customerservice.domain.dto.CustomerRegistrationRequest;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerRegistrationRequestDomainDto {

    private Long id;
    private Long countryId;
    private Long industryId;
    private Long statusId;
    private String companyName;
    private String purpose;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String designation;
    private String emailAddress;
}
