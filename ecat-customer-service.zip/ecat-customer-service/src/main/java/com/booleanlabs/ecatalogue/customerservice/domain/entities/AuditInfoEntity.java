package com.booleanlabs.ecatalogue.customerservice.domain.entities;

import jakarta.persistence.Column;
import jakarta.persistence.MappedSuperclass;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 * @author dilanka
 * @created 07/01/2024 - 6:17 PM
 * @project master-data-service
 */

@MappedSuperclass
@Getter
@Setter
public class AuditInfoEntity {
    @Column(name = "created_user")
    private String createdUser;

    @Column(name = "updated_user")
    private String updatedUser;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "deleted")
    private Boolean deleted = Boolean.FALSE;

    @Column(name = "deleted")
    private Boolean active = Boolean.TRUE;

    @Column(name = "display_order")
    private Integer displayOrder;
}
