package com.booleanlabs.ecatalogue.customerservice.domain.dto.Customer;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CustomerDeleteDomainDto {

    private Long customerId;

    private Long newAdminId;
}
