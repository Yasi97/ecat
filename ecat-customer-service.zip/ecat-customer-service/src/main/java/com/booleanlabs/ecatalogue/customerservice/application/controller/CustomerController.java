package com.booleanlabs.ecatalogue.customerservice.application.controller;

import com.booleanlabs.ecatalogue.customerservice.application.request.dto.customer.CustomerCreateRequestDto;
import com.booleanlabs.ecatalogue.customerservice.application.request.dto.customer.CustomerDeleteDto;
import com.booleanlabs.ecatalogue.customerservice.application.request.dto.customer.CustomerFetchRequestDto;
import com.booleanlabs.ecatalogue.customerservice.application.request.dto.customer.CustomerSearchRequest;
import com.booleanlabs.ecatalogue.customerservice.application.request.dto.customer.UpdateCustomerRequest;
import com.booleanlabs.ecatalogue.customerservice.application.response.dto.ErrorMessage;
import com.booleanlabs.ecatalogue.customerservice.application.response.dto.SuccessMessage;
import com.booleanlabs.ecatalogue.customerservice.application.response.dto.customer.CustomerFetchResponseDto;
import com.booleanlabs.ecatalogue.customerservice.application.util.ResponseUtils;
import com.booleanlabs.ecatalogue.customerservice.application.validator.RequestEntityValidator;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.BaseResponseMessageDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.BaseSearchResponseDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.Customer.CustomerCreateDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.Customer.CustomerDeleteDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.Customer.CustomerFetchRequestDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.Customer.CustomerSearchDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.Customer.UpdateCustomerRequestDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.service.CustomerService;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.APP_ROOT_V1_WEB;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.Actions.CREATE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.Actions.DELETE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.Actions.LOAD;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.Actions.SEARCH;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.Actions.UPDATE;

@RestController
@RequestMapping(APP_ROOT_V1_WEB + "/customer")
@Validated
@RequiredArgsConstructor
@Slf4j
public class CustomerController {

    private final CustomerService customerService;
    private final RequestEntityValidator validator;
    private final ResponseUtils responseUtils;
    private final ObjectMapper mapper;
    private static final Logger LOGGER = LogManager.getLogger(CustomerRegistrationRequestController.class);

    @Operation(summary = "Create Customer")
    @ApiResponses(value = {
            @ApiResponse(description = "Create Customer Request Success", responseCode = "201"),
            @ApiResponse(description = "Bad Request in Customer Request", responseCode = "400", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))}),
            @ApiResponse(description = "Exception occurred when processing Create Customer Request", responseCode = "500", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))})})
    @PostMapping(value = CREATE, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessMessage<BaseResponseMessageDto>> createCustomer(@RequestBody CustomerCreateRequestDto customerCreateRequestDto) {

        LOGGER.info("Create Customer Initiated");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Request|" + customerCreateRequestDto.toString());
        }

        validator.validate(customerCreateRequestDto);
        CustomerCreateDomainDto customerCreateDomainDto = mapper.convertValue(customerCreateRequestDto, CustomerCreateDomainDto.class);

        BaseResponseMessageDto responseMessageDto = customerService.createCustomer(customerCreateDomainDto);

        final ResponseEntity<SuccessMessage<BaseResponseMessageDto>> response = responseUtils.wrapSuccess(responseMessageDto, HttpStatus.CREATED);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Request|" + responseMessageDto.toString());
        }
        LOGGER.info("Create Customer Registration Request Finish");
        return response;
    }

    @Operation(summary = "Search Customer")
    @ApiResponses(value = {
            @ApiResponse(description = "Search Customer Request Success", responseCode = "200"),
            @ApiResponse(description = "Bad Request in Search Customer Request", responseCode = "400", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))}),
            @ApiResponse(description = "Exception occurred when processing Search Customer Request", responseCode = "500", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))})})
    @PostMapping(value = SEARCH, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessMessage<BaseSearchResponseDomainDto>> searchCustomer(@RequestBody CustomerSearchRequest customerSearchRequest) {

        LOGGER.info("Search Customer Initiated");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Request|" + customerSearchRequest.toString());
        }

        validator.validate(customerSearchRequest);
        CustomerSearchDomainDto customerSearchDomainDto = mapper.convertValue(customerSearchRequest, CustomerSearchDomainDto.class);

        BaseSearchResponseDomainDto searchCustomerResponse = customerService.searchCustomer(customerSearchDomainDto);

        final ResponseEntity<SuccessMessage<BaseSearchResponseDomainDto>> response =
                responseUtils.wrapSuccess(searchCustomerResponse, HttpStatus.CREATED);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Request|" + searchCustomerResponse.toString());
        }
        LOGGER.info("Create Customer Registration Request Finish");
        return response;
    }

    @Operation(summary = "Fetch Customer information")
    @ApiResponses(value = {
            @ApiResponse(description = "Fetch Customer Request Success", responseCode = "200"),
            @ApiResponse(description = "Bad Request in fetch customer", responseCode = "400", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))}),
            @ApiResponse(description = "Exception occurred when processing fetch Customer Request", responseCode = "500", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))})})
    @PostMapping(value = LOAD, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessMessage<CustomerFetchResponseDto>> loadCustomer(@RequestBody CustomerFetchRequestDto customerFetchRequestDto) {

        LOGGER.info("Fetch Customer Initiated");
        LOGGER.info("Request|" + customerFetchRequestDto.toString());

        validator.validate(customerFetchRequestDto);
        CustomerFetchRequestDomainDto customerFetchRequestDomainDto = mapper.convertValue(customerFetchRequestDto, CustomerFetchRequestDomainDto.class);

        CustomerFetchResponseDto customerFetchResponseDto = customerService.fetchCustomer(customerFetchRequestDomainDto);

        final ResponseEntity<SuccessMessage<CustomerFetchResponseDto>> response = responseUtils.wrapSuccess(customerFetchResponseDto, HttpStatus.OK);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Request|" + customerFetchResponseDto.toString());
        }
        LOGGER.info("Create Customer Registration Request Finish");
        return response;
    }

    @Operation(summary = "Update Customer")
    @ApiResponses(value = {
            @ApiResponse(description = "Update Customer Success", responseCode = "200"),
            @ApiResponse(description = "Bad Request in Update Customer", responseCode = "400", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))}),
            @ApiResponse(description = "Exception occurred when processing Update Customer ", responseCode = "500", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))})})
    @PutMapping(value = UPDATE, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessMessage<BaseResponseMessageDto>> updateCustomer(@RequestBody UpdateCustomerRequest updateCustomerRequest) {

        LOGGER.info("Update Customer Initiated");
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("Request|{}", updateCustomerRequest.toString());
        }

        validator.validate(updateCustomerRequest);
        UpdateCustomerRequestDomainDto updateCustomerRequestDomainDto = mapper.convertValue(updateCustomerRequest, UpdateCustomerRequestDomainDto.class);
        BaseResponseMessageDto result = customerService.updateCustomer(updateCustomerRequestDomainDto);

        final ResponseEntity<SuccessMessage<BaseResponseMessageDto>> response = responseUtils.wrapSuccess(result, HttpStatus.OK);

        LOGGER.info("Update Customer Finish");
        return response;
    }

    @Operation(summary = "Delete Customer")
    @ApiResponses(value = {
            @ApiResponse(description = "Delete Customer Success", responseCode = "200"),
            @ApiResponse(description = "Bad Request in Delete Customer", responseCode = "400", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))}),
            @ApiResponse(description = "Exception occurred when processing Delete Customer ", responseCode = "500", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))})})
    @PostMapping(value = DELETE, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessMessage<BaseResponseMessageDto>> deleteCustomer(@RequestBody CustomerDeleteDto customerDeleteDto) {


        LOGGER.info("Delete Customer Initiated|customerId:{}", customerDeleteDto.getCustomerId());

        validator.validate(customerDeleteDto);

        CustomerDeleteDomainDto customerDeleteDomainDto = mapper.convertValue(customerDeleteDto, CustomerDeleteDomainDto.class);

        BaseResponseMessageDto result = customerService.deleteCustomer(customerDeleteDomainDto);

        final ResponseEntity<SuccessMessage<BaseResponseMessageDto>> response = responseUtils.wrapSuccess(result, HttpStatus.OK);

        LOGGER.info("Delete Customer Finish");
        return response;
    }
}
