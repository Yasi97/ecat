package com.booleanlabs.ecatalogue.customerservice.application.response.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class SuccessMessage<T> {
    private String code;
    private String message;
    private String traceId;
    private String timestamp;
    private T data;
}
