package com.booleanlabs.ecatalogue.customerservice.external.repository.mapper;

import com.booleanlabs.ecatalogue.customerservice.domain.entities.CustomerRegistrationRequestStatusEntity;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.ID;

public class CustomerRegistrationRequestStatusRowMapper implements RowMapper<CustomerRegistrationRequestStatusEntity> {
    @Override
    public CustomerRegistrationRequestStatusEntity mapRow(ResultSet rs, int rowNum) throws SQLException {
        CustomerRegistrationRequestStatusEntity customerRegistrationRequestStatusEntity = new CustomerRegistrationRequestStatusEntity();
        customerRegistrationRequestStatusEntity.setId(rs.getLong(ID));
        return customerRegistrationRequestStatusEntity;
    }
}
