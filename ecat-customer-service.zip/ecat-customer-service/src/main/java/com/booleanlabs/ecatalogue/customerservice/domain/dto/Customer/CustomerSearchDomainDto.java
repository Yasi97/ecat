package com.booleanlabs.ecatalogue.customerservice.domain.dto.Customer;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.ENTITY_ERROR_NOT_NULL;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder(toBuilder = true)
@ToString
public class CustomerSearchDomainDto {
    private Integer pageIndex;
    private Integer itemPerPage;
    private String searchText;
    private Long statusId;
    private Long brandId;
}
