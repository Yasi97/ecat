package com.booleanlabs.ecatalogue.customerservice.external.repository;

import com.booleanlabs.ecatalogue.customerservice.domain.dto.CompanyBrandDto;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Repository
@RequiredArgsConstructor
public class CompanyBrandRepository {

    private final JdbcTemplate jdbcTemplate;

    private static final Logger LOGGER = LogManager.getLogger(CompanyRepository.class);

    public void createCompanyBrand(List<CompanyBrandDto> companyBrands) {
        LOGGER.info("Company_Brand create repository stared");
        String sql = "INSERT INTO at_company_brand (company_id, brand_id) VALUES (?, ?)";

        jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                CompanyBrandDto companyBrand = companyBrands.get(i);
                ps.setLong(1, companyBrand.getCompanyId());
                ps.setLong(2, companyBrand.getBrandId());
            }

            @Override
            public int getBatchSize() {
                return companyBrands.size();
            }
        });
        LOGGER.info("Company_Brand create success");
    }
}
