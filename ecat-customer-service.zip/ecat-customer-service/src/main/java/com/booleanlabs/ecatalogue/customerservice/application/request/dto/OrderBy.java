package com.booleanlabs.ecatalogue.customerservice.application.request.dto;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.domain.Sort;

/**
 * @author dilanka
 * @created 0/01/2024 - 11:28 AM
 * @project master-data-service
 */
@Getter
@Setter
public class OrderBy {
    private String sortingField = "id";
    private Sort.Direction sortingDirection = Sort.Direction.ASC;
}
