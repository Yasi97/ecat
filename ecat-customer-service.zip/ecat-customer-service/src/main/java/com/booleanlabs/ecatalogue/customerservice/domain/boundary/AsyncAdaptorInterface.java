package com.booleanlabs.ecatalogue.customerservice.domain.boundary;

public interface AsyncAdaptorInterface {

    void runAll(Long timeout, Runnable... tasks);

    void runAsync(Runnable task);

}
