package com.booleanlabs.ecatalogue.customerservice.domain.dto.Customer;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CustomerCreateDomainDto implements Serializable {

    private Long companyId;
    private Long countryId;
    private Long industryId;
    private String companyName;
    private String companyAddress;
    private String purpose;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String designation;
    private String emailAddress;
    private Long customerBrandId;
    private List<Long> companyBrands;

}
