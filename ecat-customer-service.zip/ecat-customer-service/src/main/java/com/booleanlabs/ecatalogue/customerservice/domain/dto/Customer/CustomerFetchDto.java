package com.booleanlabs.ecatalogue.customerservice.domain.dto.Customer;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerFetchDto {
    //customer
    private Long customerId;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String designation;

    //user
    private Long userId;
    private String emailAddress;
    private Boolean active;

    //company
    private Long companyId;
    private String companyName;
    private String companyAddress;

    //brand
    private Long brandId;
    private String brandName;

    //industry
    private Long industryId;
    private String industryName;

    //country
    private Long countryId;
    private String countryName;

}
