package com.booleanlabs.ecatalogue.customerservice.external.repository.mapper;

import com.booleanlabs.ecatalogue.customerservice.domain.dto.Customer.CustomerFetchDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.CustomerRegistrationRequest.CustomerRegistrationRequestResponseDto;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.BRAND_NAME;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.COLOR_CODE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.COMPANY_NAME;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.COUNTRY_NAME;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.CREATED_DATE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.CUSTOMER_ID;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.DESIGNATION;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.EMAIL_ADDRESS;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.FIRST_NAME;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.INDUSTRY_NAME;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.IS_ACTIVE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.LAST_NAME;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.PHONE_NUMBER;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.PURPOSE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.REQUEST_ID;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.STATUS_ID;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.STATUS_NAME;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.UPDATED_DATE;

public class CustomerSearchRowMapper implements RowMapper<CustomerFetchDto> {


    @Override
    public CustomerFetchDto mapRow(ResultSet rs, int rowNum) throws SQLException {

        CustomerFetchDto customerRegistrationRequestResponseEntity = new CustomerFetchDto();

        customerRegistrationRequestResponseEntity.setCustomerId(rs.getLong(CUSTOMER_ID));
        customerRegistrationRequestResponseEntity.setBrandName(rs.getString(BRAND_NAME));
        customerRegistrationRequestResponseEntity.setCompanyName(rs.getString(COMPANY_NAME));
        customerRegistrationRequestResponseEntity.setFirstName(rs.getString(FIRST_NAME));
        customerRegistrationRequestResponseEntity.setLastName(rs.getString(LAST_NAME));
        customerRegistrationRequestResponseEntity.setEmailAddress(rs.getString(EMAIL_ADDRESS));
        customerRegistrationRequestResponseEntity.setActive(rs.getBoolean(IS_ACTIVE));


        return customerRegistrationRequestResponseEntity;
    }
}
