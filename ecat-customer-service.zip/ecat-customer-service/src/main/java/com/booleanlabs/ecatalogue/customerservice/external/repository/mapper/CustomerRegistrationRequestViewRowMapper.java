package com.booleanlabs.ecatalogue.customerservice.external.repository.mapper;

import com.booleanlabs.ecatalogue.customerservice.domain.dto.CustomerRegistrationRequest.CustomerRegistrationRequestResponseDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.CustomerRegistrationRequest.CustomerRegistrationRequestResponseViewDto;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.COMPANY_NAME;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.COUNTRY_ID;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.DESIGNATION;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.EMAIL_ADDRESS;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.FIRST_NAME;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.INDUSTRY_ID;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.LAST_NAME;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.PHONE_NUMBER;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.PURPOSE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.REQUEST_ID;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.STATUS_ID;

public class CustomerRegistrationRequestViewRowMapper implements RowMapper<CustomerRegistrationRequestResponseDto> {
    @Override
    public CustomerRegistrationRequestResponseDto mapRow(ResultSet rs, int rowNum) throws SQLException {

        CustomerRegistrationRequestResponseDto customerRegistrationRequestResponseDto = new CustomerRegistrationRequestResponseDto();
        customerRegistrationRequestResponseDto.setRequestId(rs.getLong(REQUEST_ID));
        customerRegistrationRequestResponseDto.setCompanyName(rs.getString(COMPANY_NAME));
        customerRegistrationRequestResponseDto.setPurpose(rs.getString(PURPOSE));
        customerRegistrationRequestResponseDto.setFirstName(rs.getString(FIRST_NAME));
        customerRegistrationRequestResponseDto.setLastName(rs.getString(LAST_NAME));
        customerRegistrationRequestResponseDto.setPhoneNumber(rs.getString(PHONE_NUMBER));
        customerRegistrationRequestResponseDto.setDesignation(rs.getString(DESIGNATION));
        customerRegistrationRequestResponseDto.setEmailAddress(rs.getString(EMAIL_ADDRESS));
        customerRegistrationRequestResponseDto.setCountryId(rs.getLong(COUNTRY_ID));
        customerRegistrationRequestResponseDto.setIndustryId(rs.getLong(INDUSTRY_ID));
        customerRegistrationRequestResponseDto.setStatusId(rs.getLong(STATUS_ID));

        return customerRegistrationRequestResponseDto;
    }
}
