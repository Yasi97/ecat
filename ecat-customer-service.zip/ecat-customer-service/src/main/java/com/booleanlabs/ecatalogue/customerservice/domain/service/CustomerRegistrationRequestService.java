package com.booleanlabs.ecatalogue.customerservice.domain.service;

import com.booleanlabs.ecatalogue.customerservice.application.exception.CommonException;
import com.booleanlabs.ecatalogue.customerservice.application.exception.NotFoundException;
import com.booleanlabs.ecatalogue.customerservice.application.util.MessageUtils;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.BaseSearchResponseDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.CustomerRegistrationRequest.CustomerRegistrationRequestDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.CustomerRegistrationRequest.CustomerRegistrationRequestResponseDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.CustomerRegistrationRequest.CustomerRegistrationRequestSearchDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.CustomerRegistrationRequest.CustomerRegistrationRequestStatusDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.CustomerRegistrationRequest.UpdateCustomerRegistrationRequestStatusDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.entities.CustomerRegistrationRequestEntity;
import com.booleanlabs.ecatalogue.customerservice.domain.entities.CustomerRegistrationRequestSearchRequestEntity;
import com.booleanlabs.ecatalogue.customerservice.domain.util.CustomerRegistrationRequestStatusEnum;
import com.booleanlabs.ecatalogue.customerservice.external.repository.CustomerRegistrationRequestRepository;
import com.booleanlabs.ecatalogue.customerservice.external.repository.CustomerRegistrationRequestStatusRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.CUSTOMER_ADMIN;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.MESSAGE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.CREATE_CUSTOMER_REQUEST_ERROR_CODE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.CREATE_CUSTOMER_REQUEST_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.CREATING_CUSTOMER_REQUEST_FORBIDDEN_COMPANY_NAME_ERROR_CODE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.CREATING_CUSTOMER_REQUEST_FORBIDDEN_COMPANY_NAME_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.CREATING_CUSTOMER_REQUEST_FORBIDDEN_EMAIL_ERROR_CODE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.CREATING_CUSTOMER_REQUEST_FORBIDDEN_EMAIL_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.CUSTOMER_REGISTRATION_REQUEST_FIND_ERROR_CODE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.CUSTOMER_REGISTRATION_REQUEST_FIND_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.CUSTOMER_REGISTRATION_REQUEST_STATUS_UPDATE_FAIL_ERROR_CODE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.CUSTOMER_REGISTRATION_REQUEST_STATUS_UPDATE_FAIL_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.DB_ERROR_TYPE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.NO_STATUS_FOUND_ERROR_CODE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.NO_STATUS_FOUND_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.VALIDATION_ERROR_TYPE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.SuccessConstants.CREATE_CUSTOMER_REGISTRATION_REQUEST_SUCCESS;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.SuccessConstants.UPDATE_CUSTOMER_REGISTRATION_REQUEST_STATUS_SUCCESS;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class CustomerRegistrationRequestService {

    private static final Logger LOGGER = LogManager.getLogger(CustomerRegistrationRequestService.class);

    private final ObjectMapper objectMapper;
    private final MessageUtils messageUtils;
    private final CustomerRegistrationRequestRepository customerRegistrationRequestRepository;
    private final CustomerRegistrationRequestStatusRepository customerRegistrationRequestStatusRepository;


    /**
     * create CustomerRegistrationRequest
     *
     * @param customerRegistrationRequestCreateDto
     * @return CreateCustomerRegistrationRequestResponseDto
     */
    public Map<String, String> createCustomerRegistrationRequest(final CustomerRegistrationRequestDomainDto customerRegistrationRequestCreateDto) {
        LOGGER.info("Create Customer Registration Request service started");

        final CustomerRegistrationRequestEntity customerRegistrationRequestEntity = objectMapper.convertValue(customerRegistrationRequestCreateDto, CustomerRegistrationRequestEntity.class);

        //TODO status table will be changed
        final Long requestStatusId = customerRegistrationRequestStatusRepository.getStatusIdByStatusValue(CustomerRegistrationRequestStatusEnum.PENDING);

        final LocalDateTime dateNow = LocalDateTime.now();
        customerRegistrationRequestEntity.setCreatedDate(dateNow);
        customerRegistrationRequestEntity.setUpdatedDate(dateNow);
        customerRegistrationRequestEntity.setCreatedUser(CUSTOMER_ADMIN);
        customerRegistrationRequestEntity.setUpdatedUser(CUSTOMER_ADMIN);
        customerRegistrationRequestEntity.setStatusId(requestStatusId);

        Long statusIdForEmail = customerRegistrationRequestStatusRepository.getStatusIdByStatusValueForEmail(customerRegistrationRequestCreateDto.getEmailAddress());
        if (statusIdForEmail > 0) {
            String status = customerRegistrationRequestStatusRepository.getStatusNameById(statusIdForEmail);
            LOGGER.warn("Create Customer Registration Request Rejected. Request already exists.|status:{}" + status);
            throw new CommonException(String.format(messageUtils.getPropertyValue(CREATING_CUSTOMER_REQUEST_FORBIDDEN_EMAIL_ERROR_MESSAGE), status),
                    messageUtils.getPropertyValue(CREATING_CUSTOMER_REQUEST_FORBIDDEN_EMAIL_ERROR_CODE), messageUtils.getPropertyValue(VALIDATION_ERROR_TYPE), HttpStatus.FORBIDDEN);
        }

        Long statusIdForCompany = customerRegistrationRequestStatusRepository.getStatusIdByStatusValueForCompanyName(customerRegistrationRequestCreateDto.getCompanyName());
        if (statusIdForCompany > 0) {
            String status = customerRegistrationRequestStatusRepository.getStatusNameById(statusIdForCompany);
            LOGGER.warn("Create Customer Registration Request Rejected. Request already exists.|status:{}" + status);
            throw new CommonException(String.format(messageUtils.getPropertyValue(CREATING_CUSTOMER_REQUEST_FORBIDDEN_COMPANY_NAME_ERROR_MESSAGE), status),
                    messageUtils.getPropertyValue(CREATING_CUSTOMER_REQUEST_FORBIDDEN_COMPANY_NAME_ERROR_CODE), messageUtils.getPropertyValue(VALIDATION_ERROR_TYPE), HttpStatus.FORBIDDEN);
        }

        int affectedRowCount = customerRegistrationRequestRepository.save(customerRegistrationRequestEntity);
        if (affectedRowCount == 1) {
            LOGGER.info("Create Customer Registration Request Success");
            Map<String, String> response = new HashMap<>();
            response.put(MESSAGE, messageUtils.getPropertyValue(CREATE_CUSTOMER_REGISTRATION_REQUEST_SUCCESS));
            return response;
        } else {
            LOGGER.error("Error occurred Create Customer Registration Request");
            throw new CommonException(messageUtils.getPropertyValue(CREATE_CUSTOMER_REQUEST_ERROR_MESSAGE),
                    messageUtils.getPropertyValue(CREATE_CUSTOMER_REQUEST_ERROR_CODE), messageUtils.getPropertyValue(DB_ERROR_TYPE), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }


    /**
     * search CustomerRegistrationRequests
     *
     * @param customerRegistrationRequestSearchRequestEntity
     * @return SearchCustomerRegistrationRequestResponseDto
     */
    public BaseSearchResponseDomainDto<CustomerRegistrationRequestSearchDto> searchCustomerRegistrationRequests(CustomerRegistrationRequestSearchRequestEntity customerRegistrationRequestSearchRequestEntity) {

        LOGGER.info("Search Customer Registration Request service started");

        BaseSearchResponseDomainDto<CustomerRegistrationRequestSearchDto> searchCustomerRegistrationRequestResponseDtoBaseSearchResponseDto = new BaseSearchResponseDomainDto<>();

        List<CustomerRegistrationRequestResponseDto> customerRegistrationRequestResponseEntities =
                customerRegistrationRequestRepository.searchCustomerRegistrationRequests(customerRegistrationRequestSearchRequestEntity,
                        searchCustomerRegistrationRequestResponseDtoBaseSearchResponseDto);

        List<CustomerRegistrationRequestSearchDto> searchCustomerRegistrationRequestResponseDtos =
                customerRegistrationRequestResponseEntities.stream().map(customerRegistrationRequestResponseEntity -> {

                    CustomerRegistrationRequestSearchDto customerRegistrationRequestResponseDto =
                            objectMapper.convertValue(customerRegistrationRequestResponseEntity, CustomerRegistrationRequestSearchDto.class);
                    CustomerRegistrationRequestStatusDto customerRegistrationRequestStatusDto =
                            objectMapper.convertValue(customerRegistrationRequestResponseEntity, CustomerRegistrationRequestStatusDto.class);

                    customerRegistrationRequestResponseDto.setStatus(customerRegistrationRequestStatusDto);
                    return customerRegistrationRequestResponseDto;
                }).toList();

        searchCustomerRegistrationRequestResponseDtoBaseSearchResponseDto.setItems(searchCustomerRegistrationRequestResponseDtos);
        return searchCustomerRegistrationRequestResponseDtoBaseSearchResponseDto;
    }

    /**
     * getCustomerRegistrationRequest
     *
     * @param id
     * @return
     */
    public CustomerRegistrationRequestResponseDto getCustomerRegistrationRequest(Long id) {

        LOGGER.info("View Customer Registration Request service started");
        CustomerRegistrationRequestResponseDto customerRegistrationRequest = customerRegistrationRequestRepository.getCustomerRegistrationRequest(id);
        if (ObjectUtils.isNotEmpty(customerRegistrationRequest)) {
            return customerRegistrationRequest;
        } else {
            throw new NotFoundException(messageUtils.getPropertyValue(CUSTOMER_REGISTRATION_REQUEST_FIND_ERROR_MESSAGE),
                    messageUtils.getPropertyValue(CUSTOMER_REGISTRATION_REQUEST_FIND_ERROR_CODE));
        }
    }

    /**
     * updateCustomerRegistrationRequestStatus
     *
     * @param updateCustomerRegistrationRequestStatusDomainDto
     * @return
     */
    public Map<String, String> updateCustomerRegistrationRequestStatus(UpdateCustomerRegistrationRequestStatusDomainDto updateCustomerRegistrationRequestStatusDomainDto) {

        LOGGER.info("Update Customer Registration Request Status service started");
        Map<String, String> resultMap = new HashMap<>();
        String statusName = customerRegistrationRequestStatusRepository.getStatusNameById(updateCustomerRegistrationRequestStatusDomainDto.getStatusId());
        if (StringUtils.isEmpty(statusName)) {
            throw new CommonException(String.format(messageUtils.getPropertyValue(NO_STATUS_FOUND_ERROR_MESSAGE), updateCustomerRegistrationRequestStatusDomainDto.getStatusId()),
                    messageUtils.getPropertyValue(NO_STATUS_FOUND_ERROR_CODE), messageUtils.getPropertyValue(VALIDATION_ERROR_TYPE), HttpStatus.NOT_FOUND);
        } else {

            int affectedRowCount = customerRegistrationRequestRepository.updateCustomerRegistrationRequestStatusRequest(updateCustomerRegistrationRequestStatusDomainDto);

            if (affectedRowCount == 1) {
                LOGGER.info("Update Customer Registration Request Status to {} is success", statusName);
                resultMap.put(MESSAGE, String.format(messageUtils.getPropertyValue(UPDATE_CUSTOMER_REGISTRATION_REQUEST_STATUS_SUCCESS), statusName));
            } else {
                LOGGER.error("Update Customer Registration Request Status to {} failed", statusName);
                throw new CommonException(String.format(messageUtils.getPropertyValue(CUSTOMER_REGISTRATION_REQUEST_STATUS_UPDATE_FAIL_ERROR_MESSAGE), updateCustomerRegistrationRequestStatusDomainDto.getStatusId()),
                        messageUtils.getPropertyValue(CUSTOMER_REGISTRATION_REQUEST_STATUS_UPDATE_FAIL_ERROR_CODE), messageUtils.getPropertyValue(DB_ERROR_TYPE), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }
        return resultMap;
    }


}
