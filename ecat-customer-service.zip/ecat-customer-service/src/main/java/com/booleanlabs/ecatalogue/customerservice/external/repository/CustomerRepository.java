package com.booleanlabs.ecatalogue.customerservice.external.repository;

import com.booleanlabs.ecatalogue.customerservice.application.exception.CommonException;
import com.booleanlabs.ecatalogue.customerservice.application.util.MessageUtils;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.BaseSearchResponseDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.Customer.CustomerFetchDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.Customer.CustomerFetchRequestDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.Customer.CustomerSearchDomainDto;
import com.booleanlabs.ecatalogue.customerservice.external.repository.mapper.CustomerFetchRowMapper;
import com.booleanlabs.ecatalogue.customerservice.external.repository.mapper.CustomerSearchRowMapper;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.VAR_READ;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.DATABASE_ERROR_CODE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.DATABASE_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.DB_ERROR_TYPE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.QueryConstants.FETCH_CUSTOMER_READ_QUERY;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.QueryConstants.FETCH_CUSTOMER_UPDATE_QUERY;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.QueryConstants.SEARCH_CUSTOMER_COUNT_QUERY;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.QueryConstants.SEARCH_CUSTOMER_QUERY;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.QueryConstants.UPDATE_CUSTOMER_QUERY;

@Repository
@RequiredArgsConstructor
public class CustomerRepository {

    private final JdbcTemplate jdbcTemplate;

    private final MessageUtils messageUtils;

    private static final Logger LOGGER = LogManager.getLogger(CompanyRepository.class);

    public int createCustomer(Long userId, Long companyId, Long brandId, String firstName, String lastName, String phoneNumber, String designation) {
        LOGGER.info("Customer create repository stared");

        String sql = "INSERT INTO t_customer (user_id, company_id, brand_id, first_name, last_name, phone_number, designation) VALUES (?, ?, ?, ?, ?, ?, ?)";

        int affectedCount = jdbcTemplate.update(sql, userId, companyId, brandId, firstName, lastName, phoneNumber, designation);
        LOGGER.info("Create Customer success");
        return affectedCount;
    }

    public BaseSearchResponseDomainDto<CustomerFetchDto> searchCustomer(CustomerSearchDomainDto customerSearchDomainDto) {
        String name = customerSearchDomainDto.getSearchText();
        Long brandId = customerSearchDomainDto.getBrandId();
        //Long statusId =  TODO do we need to filter by status id? Is it status of customer registration request
        int pageIndex = customerSearchDomainDto.getPageIndex();
        int itemsPerPage = customerSearchDomainDto.getItemPerPage();

        int offset = (pageIndex - 1) * itemsPerPage;

        try {
            List<CustomerFetchDto> customerFetchDtos = jdbcTemplate.query(SEARCH_CUSTOMER_QUERY, new CustomerSearchRowMapper(),
                    name, brandId, brandId, offset, itemsPerPage);

            int totalRecords = jdbcTemplate.queryForObject(SEARCH_CUSTOMER_COUNT_QUERY, Integer.class, name, brandId, brandId);

            int totalPages = (int) Math.ceil((double) totalRecords / itemsPerPage);

            BaseSearchResponseDomainDto<CustomerFetchDto> baseSearchResponseDomainDto = new BaseSearchResponseDomainDto<>();

            baseSearchResponseDomainDto.setTotalItems(totalRecords);
            baseSearchResponseDomainDto.setTotalPages(totalPages);
            baseSearchResponseDomainDto.setItems(customerFetchDtos);

            return baseSearchResponseDomainDto;
        } catch (EmptyResultDataAccessException emptyResultDataAccessException) {
            LOGGER.error(emptyResultDataAccessException.getMessage());
            throw new CommonException(messageUtils.getPropertyValue(DATABASE_ERROR_MESSAGE),
                    messageUtils.getPropertyValue(DATABASE_ERROR_CODE), messageUtils.getPropertyValue(DB_ERROR_TYPE), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public int updateCustomer(Long customerId, Long brandId, String firstName, String lastName, String phoneNumber, String designation) {

        LOGGER.info("Customer update repository stared");
        int affectedCount = jdbcTemplate.update(UPDATE_CUSTOMER_QUERY,
                brandId, brandId,
                firstName, firstName,
                lastName, lastName,
                phoneNumber, phoneNumber,
                designation, designation,
                customerId);

        LOGGER.info("Customer update success");
        return affectedCount;
    }

    public int deleteCustomer(Long customerId) {
        LOGGER.info("Customer delete repository stared");
        String sql = "update t_customer set is_deleted = 1 where customer_id = ?";
        return jdbcTemplate.update(sql, customerId);
    }

    public CustomerFetchDto getCustomerFetchInformation(CustomerFetchRequestDomainDto customerFetchRequestDomainDto) {
        LOGGER.info("Fetch Customer information repository started");

        Long customerId = customerFetchRequestDomainDto.getCustomerId();
        String operationType = customerFetchRequestDomainDto.getOperationType();

        String query = StringUtils.equals(operationType, VAR_READ)  ? FETCH_CUSTOMER_READ_QUERY : FETCH_CUSTOMER_UPDATE_QUERY;

        try {
            CustomerFetchDto customerFetchDto = jdbcTemplate.queryForObject(query, new CustomerFetchRowMapper(operationType), customerId);
            LOGGER.info("Get Customer Success|customerId:{}" + customerId);
            return customerFetchDto;
        } catch (EmptyResultDataAccessException e) {
            LOGGER.warn("Customer Registration Request Not Found");
            return null;
        }
    }

    public String getUserTypeByCustomerId(Long customerId) {
        String sql = "select usr.user_type \n" +
                "from t_customer cus, t_user usr\n" +
                "where cus.user_id = usr.user_id AND cus.customer_id = ?";
        return jdbcTemplate.queryForObject(sql, String.class, customerId);
    }

    public int changeCustomerUserTypeToAdmin(Long customerId) {
        String sql = "UPDATE t_user\n" +
                "SET user_type = 'CUSTOMER_ADMIN'\n" +
                "WHERE user_id = (\n" +
                "    SELECT usr.user_id\n" +
                "    FROM t_customer cus\n" +
                "    JOIN t_user usr ON cus.user_id = usr.user_id\n" +
                "    WHERE cus.customer_id = ? \n" +
                ") ";

        return jdbcTemplate.update(sql, customerId);

    }
}
