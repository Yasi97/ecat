package com.booleanlabs.ecatalogue.customerservice.domain.entities;

import com.booleanlabs.ecatalogue.customerservice.application.response.dto.customerRegisrationRequest.CustomerRegistrationResponseStatusDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class SearchCustomerRegistrationRequestResponseDto implements Serializable {
    private Long requestId;
    private String companyName;
    private String purpose;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String designation;
    private String emailAddress;
    private String countryName;
    private String industryName;
    private CustomerRegistrationResponseStatusDto status;
}
