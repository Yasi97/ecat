package com.booleanlabs.ecatalogue.customerservice.external.repository;

import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
@RequiredArgsConstructor
public class RoleRepository {

    private final JdbcTemplate jdbcTemplate;

    private static final Logger LOGGER = LogManager.getLogger(CompanyRepository.class);

    public Long getRoleIdByRoleValue(String roleValue) {
        LOGGER.info("Get Role_Id repository started");

        String sql = "SELECT role_id FROM t_role WHERE role_value =?";
        Long roleId = jdbcTemplate.queryForObject(sql, Long.class, roleValue);
        LOGGER.info("Get Role_Id success|roleId:{}", roleId);
        return roleId;
    }
}
