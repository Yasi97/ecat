package com.booleanlabs.ecatalogue.customerservice.external.repository;

import com.booleanlabs.ecatalogue.customerservice.domain.dto.BrandDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.CompanyBrandDto;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Repository
@RequiredArgsConstructor
public class BrandRepository {

    private final JdbcTemplate jdbcTemplate;

    private static final Logger LOGGER = LogManager.getLogger(CompanyRepository.class);

    public List<Long> createBrand(List<String> brandNames) {

        LOGGER.info("Brand create repository started");

        String getSeq = "select SEQ_BRAND.nextval from dual";
        String sql = "INSERT INTO t_brand (brand_id, brand_name) VALUES (?, ?)";

        List<BrandDto> brandDtoList = brandNames.stream().map(s -> {
            Long nextVal = jdbcTemplate.queryForObject(getSeq, Long.class);
            return new BrandDto(nextVal, s);
        }).collect(Collectors.toList());

        jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                BrandDto companyBrand = brandDtoList.get(i);
                ps.setLong(1, companyBrand.getBrandId());
                ps.setString(2, companyBrand.getBrandName());
            }

            @Override
            public int getBatchSize() {
                return brandDtoList.size();
            }
        });
        List<Long> createdIds = brandDtoList.stream().map(BrandDto::getBrandId).toList();
        LOGGER.info("Brand create success|brandIds:{}", createdIds);
        return createdIds;
    }
}
