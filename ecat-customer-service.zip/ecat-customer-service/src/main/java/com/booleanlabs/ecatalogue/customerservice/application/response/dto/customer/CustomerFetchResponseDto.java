package com.booleanlabs.ecatalogue.customerservice.application.response.dto.customer;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class CustomerFetchResponseDto {
    private Long customerId;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String designation;
    private UserDto user;
    private CompanyDto company;
    private BrandDto brand;

}
