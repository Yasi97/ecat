package com.booleanlabs.ecatalogue.customerservice.domain.util;

public enum UserRoleEnum {
    CUSTOMER_ADMIN,
    CUSTOMER

}
