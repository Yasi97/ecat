package com.booleanlabs.ecatalogue.customerservice.application.response.dto;

import com.booleanlabs.ecatalogue.customerservice.application.exception.vm.ErrorField;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class ErrorResponse {
    private List<ErrorField> error;
}
