package com.booleanlabs.ecatalogue.customerservice.application.config;


import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClientBuilder;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.core5.http.io.SocketConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.scheduling.concurrent.ConcurrentTaskExecutor;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.RequestContextListener;
import org.springframework.web.util.DefaultUriBuilderFactory;

import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

@Configuration
public class WebConfiguration {

    @Value("${rest.api.connection.timeout}")
    int connectTimeout;
    @Value("${rest.api.read.timeout}")
    int readTimeout;
    @Value("${rest.pool.maxTotal}")
    int maxTotal;
    @Value("${rest.pool.defaultMax}")
    int defaultMaxPerRoute;

    @Bean
    public RestTemplate restTemplate() {
        DefaultUriBuilderFactory uriBuilderFactory = new DefaultUriBuilderFactory();
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.setUriTemplateHandler(uriBuilderFactory);
        restTemplate.setRequestFactory(httpComponentsClientHttpRequestFactory());
        return restTemplate;
    }

    @Bean
    public HttpComponentsClientHttpRequestFactory httpComponentsClientHttpRequestFactory() {
        PoolingHttpClientConnectionManager poolingConnectionManager = new PoolingHttpClientConnectionManager();
        poolingConnectionManager.setDefaultSocketConfig(SocketConfig.custom().setSoTimeout(readTimeout, TimeUnit.MILLISECONDS).build());
        poolingConnectionManager.setMaxTotal(maxTotal);
        poolingConnectionManager.setDefaultMaxPerRoute(defaultMaxPerRoute);
        CloseableHttpClient client = HttpClientBuilder.create().setConnectionManager(poolingConnectionManager).build();
        HttpComponentsClientHttpRequestFactory clientHttpRequestFactory =
                new HttpComponentsClientHttpRequestFactory(client);
        clientHttpRequestFactory.setConnectTimeout(connectTimeout);
        return clientHttpRequestFactory;
    }

    @Bean
    public RequestContextListener requestContextListener() {
        return new RequestContextListener();
    }

    @Bean(name = "asyncExecutor")
    public TaskExecutor transactionalExecutor(@Value("${thread.count.dbapiexecutor}") int threads) {

        ConcurrentTaskExecutor executor = new ConcurrentTaskExecutor(Executors.newFixedThreadPool(threads));
        // Decorate with request attributes for HttpServletRequest header access.
        executor.setTaskDecorator(runnable -> {
            RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();

            return () -> {
                RequestContextHolder.setRequestAttributes(requestAttributes);

                runnable.run();
            };
        });

        return executor;
    }
}
