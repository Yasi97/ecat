package com.booleanlabs.ecatalogue.customerservice.application.config;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.util.Objects;

@Configuration
@PropertySource({"classpath:application.properties"})
@ComponentScan("com.booleanlabs.ecatalogue.customerservice.*")
@EnableTransactionManagement
public class DatabaseConfiguration {

    @Value("${jdbcTemplate.query.timeOut}")
    private int queryTimeOut;

    @Primary
    @Bean
    public DataSource dataSource(Environment env) {
        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setDriverClassName(env.getProperty("eecatalogue.jdbc.driverClassName"));
        dataSource.setJdbcUrl(env.getProperty("eecatalogue.jdbc.url"));
        dataSource.setUsername(env.getProperty("eecatalogue.jdbc.user"));
        dataSource.setPassword(env.getProperty("eecatalogue.jdbc.pass"));
        dataSource.setMaximumPoolSize(Integer.parseInt(Objects.requireNonNull(env.getProperty("eecatalogue.jdbc.connectionPool"))));
        dataSource.setMaxLifetime(Long.parseLong(Objects.requireNonNull(env.getProperty("eecatalogue.jdbc.maxLifetime"))));
        dataSource.setMinimumIdle(Integer.parseInt(Objects.requireNonNull(env.getProperty("eecatalogue.jdbc.minIdle"))));
        dataSource.setIdleTimeout(Integer.parseInt(Objects.requireNonNull(env.getProperty("eecatalogue.jdbc.idleTimeOut"))));
        dataSource.setConnectionTimeout(Integer.parseInt(Objects.requireNonNull(env.getProperty("eecatalogue.jdbc.connectionTimeOut"))));
        dataSource.setConnectionTestQuery("SELECT 1 FROM dual");
        dataSource.setConnectionTimeout(Integer.parseInt(Objects.requireNonNull(env.getProperty("eecatalogue.jdbc.connectionTimeOut"))));
        dataSource.addDataSourceProperty("oracle.jdbc.timezoneAsRegion", "false");
        return dataSource;
    }

    @Bean
    public NamedParameterJdbcTemplate namedParameterJdbcTemplate(DataSource dataSource) {
        return new NamedParameterJdbcTemplate(dataSource);
    }

    @Primary
    @Bean
    public JdbcTemplate readJdbcTemplate(final Environment env){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource(env));
        jdbcTemplate.setQueryTimeout(queryTimeOut);
        return jdbcTemplate;
    }

    @Primary
    @Bean("oracleTxManager")
    public PlatformTransactionManager transactionManager(DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }

}
