package com.booleanlabs.ecatalogue.customerservice.external.repository.mapper;

import com.booleanlabs.ecatalogue.customerservice.domain.dto.CustomerRegistrationRequest.CustomerRegistrationRequestResponseDto;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.COLOR_CODE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.COMPANY_NAME;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.COUNTRY_NAME;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.CREATED_DATE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.DESIGNATION;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.EMAIL_ADDRESS;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.FIRST_NAME;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.INDUSTRY_NAME;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.LAST_NAME;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.PHONE_NUMBER;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.PURPOSE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.REQUEST_ID;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.STATUS_ID;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.STATUS_NAME;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.UPDATED_DATE;

public class CustomerRegistrationRequestSearchRowMapper implements RowMapper<CustomerRegistrationRequestResponseDto> {


    @Override
    public CustomerRegistrationRequestResponseDto mapRow(ResultSet rs, int rowNum) throws SQLException {

        CustomerRegistrationRequestResponseDto customerRegistrationRequestResponseEntity = new CustomerRegistrationRequestResponseDto();
        customerRegistrationRequestResponseEntity.setRequestId(rs.getLong(REQUEST_ID));
        customerRegistrationRequestResponseEntity.setCompanyName(rs.getString(COMPANY_NAME));
        customerRegistrationRequestResponseEntity.setPurpose(rs.getString(PURPOSE));
        customerRegistrationRequestResponseEntity.setFirstName(rs.getString(FIRST_NAME));
        customerRegistrationRequestResponseEntity.setLastName(rs.getString(LAST_NAME));
        customerRegistrationRequestResponseEntity.setPhoneNumber(rs.getString(PHONE_NUMBER));
        customerRegistrationRequestResponseEntity.setDesignation(rs.getString(DESIGNATION));
        customerRegistrationRequestResponseEntity.setEmailAddress(rs.getString(EMAIL_ADDRESS));
        customerRegistrationRequestResponseEntity.setCreatedDate(rs.getDate(CREATED_DATE));
        customerRegistrationRequestResponseEntity.setUpdatedDate(rs.getDate(UPDATED_DATE));
        customerRegistrationRequestResponseEntity.setIndustryName(rs.getString(INDUSTRY_NAME));
        customerRegistrationRequestResponseEntity.setCountryName(rs.getString(COUNTRY_NAME));
        customerRegistrationRequestResponseEntity.setStatusId(rs.getLong(STATUS_ID));
        customerRegistrationRequestResponseEntity.setStatusName(rs.getString(STATUS_NAME));
        customerRegistrationRequestResponseEntity.setStatusColorCode(rs.getString(COLOR_CODE));

        return customerRegistrationRequestResponseEntity;
    }
}
