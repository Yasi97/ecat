package com.booleanlabs.ecatalogue.customerservice.domain.dto.CustomerRegistrationRequest;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder(toBuilder = true)
@ToString
public class UpdateCustomerRegistrationRequestStatusDomainDto {

    private Long requestId;
    private Long statusId;

}
