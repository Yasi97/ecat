package com.booleanlabs.ecatalogue.customerservice.domain.util;

public enum CustomerRegistrationRequestStatusEnum {
    REJECTED,
    COMPLETED,
    PENDING,
    IN_PROGRESS
}
