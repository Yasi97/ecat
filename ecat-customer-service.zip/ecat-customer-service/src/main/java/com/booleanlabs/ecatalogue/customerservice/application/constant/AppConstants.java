package com.booleanlabs.ecatalogue.customerservice.application.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * @author dilanka
 * @created 06/01/2024 - 9:45 PM
 * @project master-data-service
 */

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class AppConstants {
    public static final String APP_ROOT_V1_WEB = "customer-service/v1/web";
    public static final String COLON = ":";
    public static final String CUSTOMER_ADMIN = "CUSTOMER_ADMIN";
    public static final String COMPLETED = "COMPLETED";
    public static final String MESSAGE = "message";
    public static final String ID = "ID";


    public static final String REQUEST_ID = "REQUEST_ID";
    public static final String COMPANY_NAME = "COMPANY_NAME";
    public static final String CUSTOMER_ID = "CUSTOMER_ID";
    public static final String BRAND_NAME = "BRAND_NAME";
    public static final String PURPOSE = "PURPOSE";
    public static final String FIRST_NAME = "FIRST_NAME";
    public static final String LAST_NAME = "LAST_NAME";
    public static final String PHONE_NUMBER = "PHONE_NUMBER";
    public static final String DESIGNATION = "DESIGNATION";
    public static final String EMAIL_ADDRESS = "EMAIL_ADDRESS";
    public static final String CREATED_DATE = "CREATED_DATE";
    public static final String UPDATED_DATE = "UPDATED_DATE";
    public static final String INDUSTRY_NAME = "INDUSTRY_NAME";
    public static final String INDUSTRY_ID = "INDUSTRY_ID";
    public static final String COUNTRY_NAME = "COUNTRY_NAME";
    public static final String COUNTRY_ID = "COUNTRY_ID";
    public static final String STATUS_ID = "STATUS_ID";
    public static final String STATUS_NAME = "STATUS_NAME";
    public static final String COLOR_CODE = "COLOR_CODE";
    public static final String IS_ACTIVE = "IS_ACTIVE";
    public static final String VAR_UPDATE = "UPDATE";
    public static final String VAR_READ = "READ";


    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class Actions {
        public static final String CREATE = "/create";
        public static final String READ = "/read/{id}";
        public static final String UPDATE = "/update";
        public static final String DELETE = "/delete";
        public static final String LOAD_ALL = "/load-all";
        public static final String LOAD_ID = "/load/{id}";
        public static final String LOAD = "/load";
        public static final String SEARCH = "/search";
        public static final String UPDATE_STATUS = "/update-status";

    }
}

