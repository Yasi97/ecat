package com.booleanlabs.ecatalogue.customerservice.domain.service;

import com.booleanlabs.ecatalogue.customerservice.application.exception.CommonException;
import com.booleanlabs.ecatalogue.customerservice.application.exception.NotFoundException;
import com.booleanlabs.ecatalogue.customerservice.application.response.dto.customer.BrandDto;
import com.booleanlabs.ecatalogue.customerservice.application.response.dto.customer.CompanyDto;
import com.booleanlabs.ecatalogue.customerservice.application.response.dto.customer.CustomerFetchResponseDto;
import com.booleanlabs.ecatalogue.customerservice.application.response.dto.customer.UserDto;
import com.booleanlabs.ecatalogue.customerservice.application.util.MessageUtils;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.BaseResponseMessageDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.BaseSearchResponseDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.CompanyBrandDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.Customer.CustomerCreateDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.Customer.CustomerDeleteDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.Customer.CustomerFetchDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.Customer.CustomerFetchRequestDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.Customer.CustomerSearchDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.Customer.UpdateCustomerRequestDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.util.UserRoleEnum;
import com.booleanlabs.ecatalogue.customerservice.domain.util.UserTypeEnum;
import com.booleanlabs.ecatalogue.customerservice.external.repository.BrandRepository;
import com.booleanlabs.ecatalogue.customerservice.external.repository.CompanyBrandRepository;
import com.booleanlabs.ecatalogue.customerservice.external.repository.CompanyRepository;
import com.booleanlabs.ecatalogue.customerservice.external.repository.CustomerRepository;
import com.booleanlabs.ecatalogue.customerservice.external.repository.RoleRepository;
import com.booleanlabs.ecatalogue.customerservice.external.repository.UserRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.CUSTOMER_CREATE_FAIL_DUPLICATE_COMPANY_ERROR_CODE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.CUSTOMER_CREATE_FAIL_DUPLICATE_COMPANY_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.CUSTOMER_CREATE_FAIL_ERROR_CODE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.CUSTOMER_CREATE_FAIL_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.CUSTOMER_DELETE_ADMIN_FAIL_ERROR_CODE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.CUSTOMER_DELETE_ADMIN_FAIL_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.CUSTOMER_DELETE_FAIL_ERROR_CODE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.CUSTOMER_DELETE_FAIL_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.CUSTOMER_FETCH_FOUND_FAIL_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.CUSTOMER_FETCH_NOT_FOUND_ERROR_CODE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.CUSTOMER_UPDATE_FAIL_ERROR_CODE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.CUSTOMER_UPDATE_FAIL_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.GLOBAL_ERROR_TYPE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.VALIDATION_ERROR_TYPE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.SuccessConstants.CUSTOMER_CREATE_SUCCESS;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.SuccessConstants.CUSTOMER_DELETE_SUCCESS;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.SuccessConstants.CUSTOMER_UPDATE_SUCCESS;

@Slf4j
@Service
@RequiredArgsConstructor
//@Transactional
public class CustomerService {

    private final CompanyRepository companyRepository;
    private final BrandRepository brandRepository;
    private final CompanyBrandRepository companyBrandRepository;
    private final RoleRepository roleRepository;
    private final UserRepository userRepository;
    private final CustomerRepository customerRepository;
    private final MessageUtils messageUtils;
    private final ObjectMapper objectMapper;

    private static final Logger LOGGER = LogManager.getLogger(CustomerService.class);

    /**
     * createCustomer service method
     *
     * @param customerCreateDomainDto
     * @return
     */
    public BaseResponseMessageDto createCustomer(CustomerCreateDomainDto customerCreateDomainDto) {
        LOGGER.info("Customer create service started");

        Long companyId = customerCreateDomainDto.getCompanyId();
        UserRoleEnum userRoleEnum = UserRoleEnum.CUSTOMER;
        UserTypeEnum userTypeEnum = UserTypeEnum.CUSTOMER;

        if(companyId == null) {
            userRoleEnum = UserRoleEnum.CUSTOMER_ADMIN;
            userTypeEnum = UserTypeEnum.CUSTOMER_ADMIN;
            final int companyCount = companyRepository.countCompanyNames(customerCreateDomainDto.getCompanyName());
            if(companyCount > 0) {
                throw new CommonException(messageUtils.getPropertyValue(CUSTOMER_CREATE_FAIL_DUPLICATE_COMPANY_ERROR_MESSAGE),
                        messageUtils.getPropertyValue(CUSTOMER_CREATE_FAIL_DUPLICATE_COMPANY_ERROR_CODE), messageUtils.getPropertyValue(VALIDATION_ERROR_TYPE), HttpStatus.FORBIDDEN);
            }
            companyId = companyRepository.createCompany(customerCreateDomainDto);
        }

        if (CollectionUtils.isNotEmpty(customerCreateDomainDto.getCompanyBrands())) {
            LOGGER.info("New Brands found. Creating new brands");

            Long finalCompanyId = companyId;
            List<CompanyBrandDto> companyBrandDtos = customerCreateDomainDto.getCompanyBrands().stream().map(aLong -> {
                return new CompanyBrandDto(finalCompanyId, aLong);
            }).collect(Collectors.toList());

            companyBrandRepository.createCompanyBrand(companyBrandDtos);
        }

        Long customerRoleId = checkAttemptAndGetCustomerRoleId(userRoleEnum);

        Long createdUserId = userRepository.createUser(customerRoleId, userTypeEnum, customerCreateDomainDto.getEmailAddress(), null, true);

        int affectedRowCount = customerRepository.createCustomer(createdUserId, companyId,
                customerCreateDomainDto.getCustomerBrandId(), customerCreateDomainDto.getFirstName(),
                customerCreateDomainDto.getLastName(), customerCreateDomainDto.getPhoneNumber(),
                customerCreateDomainDto.getDesignation());

        if (affectedRowCount == 1) {
            LOGGER.info("Customer create service success");
            return new BaseResponseMessageDto(messageUtils.getPropertyValue(CUSTOMER_CREATE_SUCCESS));
        } else {
            LOGGER.info("Error in creating Customer");
            throw new CommonException(messageUtils.getPropertyValue(CUSTOMER_CREATE_FAIL_ERROR_MESSAGE),
                    messageUtils.getPropertyValue(CUSTOMER_CREATE_FAIL_ERROR_CODE), messageUtils.getPropertyValue(GLOBAL_ERROR_TYPE), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     *
     * @param customerSearchDomainDto
     * @return
     */
    public BaseSearchResponseDomainDto<CustomerFetchDto> searchCustomer(CustomerSearchDomainDto customerSearchDomainDto) {

        LOGGER.info("Customer search service started");
        return customerRepository.searchCustomer(customerSearchDomainDto);
    }

    /**
     * update customer service method
     *
     * @param updateCustomerRequestDomainDto
     * @return
     */
    public BaseResponseMessageDto updateCustomer(UpdateCustomerRequestDomainDto updateCustomerRequestDomainDto) {
        LOGGER.info("Customer create service started");

        //TODO update company
        companyRepository.updateCompany(updateCustomerRequestDomainDto);
        LOGGER.info("Company data updated|companyId:{}", updateCustomerRequestDomainDto.getCompanyId());

        //TODO update customer
        final int affectedCustomerRowCount = customerRepository.updateCustomer(updateCustomerRequestDomainDto.getCustomerId(), updateCustomerRequestDomainDto.getBrandId(),
                updateCustomerRequestDomainDto.getFirstName(), updateCustomerRequestDomainDto.getLastName(),
                updateCustomerRequestDomainDto.getPhoneNumber(), updateCustomerRequestDomainDto.getDesignation());

        if (affectedCustomerRowCount == 1) {
            LOGGER.info("Customer update service success");
            return new BaseResponseMessageDto(messageUtils.getPropertyValue(CUSTOMER_UPDATE_SUCCESS));
        } else {
            LOGGER.info("Error in creating Customer");
            throw new CommonException(messageUtils.getPropertyValue(CUSTOMER_UPDATE_FAIL_ERROR_MESSAGE),
                    messageUtils.getPropertyValue(CUSTOMER_UPDATE_FAIL_ERROR_CODE), messageUtils.getPropertyValue(GLOBAL_ERROR_TYPE), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    /**
     *
     * @param customerDeleteDomainDto
     * @return
     */
    public BaseResponseMessageDto deleteCustomer(CustomerDeleteDomainDto customerDeleteDomainDto) {
        LOGGER.info("Customer delete service started");

        final Long customerId = customerDeleteDomainDto.getCustomerId();
        final Long newAdminId = customerDeleteDomainDto.getNewAdminId();

        //TODO get userType
        final String userType = customerRepository.getUserTypeByCustomerId(customerId);

        if(StringUtils.equals(userType, UserTypeEnum.CUSTOMER_ADMIN.name())) {
            if(newAdminId == null) {
                LOGGER.info("Error in deleting Customer");
                throw new CommonException(messageUtils.getPropertyValue(CUSTOMER_DELETE_ADMIN_FAIL_ERROR_MESSAGE),
                        messageUtils.getPropertyValue(CUSTOMER_DELETE_ADMIN_FAIL_ERROR_CODE), messageUtils.getPropertyValue(VALIDATION_ERROR_TYPE), HttpStatus.FORBIDDEN);
            } else {
                int affectedRowCountForTypeChange = customerRepository.changeCustomerUserTypeToAdmin(newAdminId);
                if(affectedRowCountForTypeChange == 1) {
                    return invokeDelete(customerId);
                }else {
                    LOGGER.info("Error in deleting Customer");
                    throw new CommonException(messageUtils.getPropertyValue(CUSTOMER_DELETE_FAIL_ERROR_MESSAGE),
                            messageUtils.getPropertyValue(CUSTOMER_DELETE_FAIL_ERROR_CODE), messageUtils.getPropertyValue(GLOBAL_ERROR_TYPE), HttpStatus.INTERNAL_SERVER_ERROR);
                }
            }

        } else {
            return invokeDelete(customerId);
        }
    }

    /**
     *
     * @param customerFetchRequestDomainDto
     * @return
     */
    public CustomerFetchResponseDto fetchCustomer(CustomerFetchRequestDomainDto customerFetchRequestDomainDto) {

        LOGGER.info("Customer fetch service started");
        CustomerFetchDto customerFetchDto = customerRepository.getCustomerFetchInformation(customerFetchRequestDomainDto);

        if (ObjectUtils.isNotEmpty(customerFetchDto)) {
            LOGGER.info("Customer fetch success|customerId:{}", customerFetchRequestDomainDto.getCustomerId());
            return buildResponseObject(customerFetchDto);
        } else {
            LOGGER.error("Customer not found|customerId:{}");
            throw new NotFoundException(messageUtils.getPropertyValue(CUSTOMER_FETCH_FOUND_FAIL_ERROR_MESSAGE),
                    messageUtils.getPropertyValue(CUSTOMER_FETCH_NOT_FOUND_ERROR_CODE));
        }

    }

    private BaseResponseMessageDto invokeDelete(Long customerId) {
        int affectedRowCount = customerRepository.deleteCustomer(customerId);

        if (affectedRowCount == 1) {
            LOGGER.info("Customer delete service success");
            return new BaseResponseMessageDto(messageUtils.getPropertyValue(CUSTOMER_DELETE_SUCCESS));
        } else {
            LOGGER.info("Error in deleting Customer");
            throw new CommonException(messageUtils.getPropertyValue(CUSTOMER_DELETE_FAIL_ERROR_MESSAGE),
                    messageUtils.getPropertyValue(CUSTOMER_DELETE_FAIL_ERROR_CODE), messageUtils.getPropertyValue(GLOBAL_ERROR_TYPE), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    private CustomerFetchResponseDto buildResponseObject(CustomerFetchDto customerFetchDto) {
        UserDto userDto = new UserDto(customerFetchDto.getUserId(), customerFetchDto.getEmailAddress(), customerFetchDto.getActive());

        CompanyDto companyDto = objectMapper.convertValue(customerFetchDto, CompanyDto.class);

        BrandDto brandDto = new BrandDto(customerFetchDto.getBrandId(), customerFetchDto.getBrandName());

        CustomerFetchResponseDto customerFetchResponseDto = new CustomerFetchResponseDto(customerFetchDto.getCustomerId(),
                customerFetchDto.getFirstName(), customerFetchDto.getLastName(), customerFetchDto.getPhoneNumber(),
                customerFetchDto.getDesignation(), userDto, companyDto, brandDto);

        return customerFetchResponseDto;
    }

    private Long checkAttemptAndGetCustomerRoleId(UserRoleEnum userRoleEnum) {
        Long companyAdminRoleId = roleRepository.getRoleIdByRoleValue(userRoleEnum.name());
        return companyAdminRoleId;

    }
}
