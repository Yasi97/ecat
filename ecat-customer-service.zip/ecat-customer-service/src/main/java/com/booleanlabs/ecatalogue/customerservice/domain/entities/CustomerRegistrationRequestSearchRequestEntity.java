package com.booleanlabs.ecatalogue.customerservice.domain.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder(toBuilder = true)
@ToString
public class CustomerRegistrationRequestSearchRequestEntity {
    private Integer pageIndex;
    private Integer itemPerPage;
    private String searchText;
    private String dateFrom;
    private String dateTo;
    private Long statusId;
}
