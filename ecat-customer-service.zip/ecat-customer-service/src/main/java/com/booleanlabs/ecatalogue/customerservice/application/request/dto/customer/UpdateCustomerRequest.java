package com.booleanlabs.ecatalogue.customerservice.application.request.dto.customer;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.ENTITY_ERROR_MAX_SIZE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.ENTITY_ERROR_NOT_NULL;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder(toBuilder = true)
@ToString
public class UpdateCustomerRequest {

    @NotNull(message = ENTITY_ERROR_NOT_NULL)
    private Long customerId;

    private Long countryId;
    private Long industryId;
    private Long companyId;

    @Size(max = 50, message = ENTITY_ERROR_MAX_SIZE)
    private String companyName;

    @Size(max = 200, message = ENTITY_ERROR_MAX_SIZE)
    private String companyAddress;

    private Long brandId;

    @Size(max = 50, message = ENTITY_ERROR_MAX_SIZE)
    private String firstName;

    @Size(max = 50, message = ENTITY_ERROR_MAX_SIZE)
    private String lastName;

    @Size(max = 20, message = ENTITY_ERROR_MAX_SIZE)
    private String phoneNumber;

    @Size(max = 100, message = ENTITY_ERROR_MAX_SIZE)
    private String designation;

}
