package com.booleanlabs.ecatalogue.customerservice.application.request.dto.customer;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.ENTITY_ERROR_NOT_NULL;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CustomerFetchRequestDto implements Serializable {

    @NotNull(message = ENTITY_ERROR_NOT_NULL)
    private Long customerId;

    @NotEmpty(message = ENTITY_ERROR_NOT_NULL)
    @Pattern(regexp = "^(UPDATE|READ)$", message = "Invalid operation type. Please use (UPDATE/READ)")
    private String operationType;
}
