package com.booleanlabs.ecatalogue.customerservice.application.request.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import org.springframework.data.domain.Sort.Direction;

import java.util.ArrayList;
import java.util.List;

/**
 * @author dilanka
 * @created 0/01/2024 - 11:28 AM
 * @project master-data-service
 */

@Data
public class BaseSearchRequest {
    @NotNull
    private Integer pageIndex = 0;
    private String sortingField = "id";
    // Order by multiple fields
    private String[] sortingFields;
    // Order by multiple fields and direction
    private List<OrderBy> orders = new ArrayList<>();
    private Direction sortingDirection = Direction.ASC;
    @NotNull
    private Integer itemPerPage = 10;
    private boolean deleted = Boolean.FALSE;
}
