package com.booleanlabs.ecatalogue.customerservice.external.repository;

import com.booleanlabs.ecatalogue.customerservice.application.exception.CommonException;
import com.booleanlabs.ecatalogue.customerservice.application.util.MessageUtils;
import com.booleanlabs.ecatalogue.customerservice.domain.util.CustomerRegistrationRequestStatusEnum;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.EXECUTION_ERROR_TYPE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.NO_STATUS_FIND_BY_NAME_ERROR_CODE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.NO_STATUS_FIND_BY_NAME_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.QueryConstants.GET_STATUS_ID_BY_STATUS_VALUE_FOR_COMPANY_NAME_QUERY;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.QueryConstants.GET_STATUS_ID_BY_STATUS_VALUE_FOR_EMAIL_QUERY;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.QueryConstants.GET_STATUS_NAME_BY_ID_QUERY;

@Repository
@RequiredArgsConstructor
public class CustomerRegistrationRequestStatusRepository {

    private final JdbcTemplate jdbcTemplate;

    private final MessageUtils messageUtils;

    private static final Logger LOGGER = LogManager.getLogger(CustomerRegistrationRequestStatusRepository.class);

    /**
     *
     * @param emailAddress
     * @return
     */
    public Long getStatusIdByStatusValueForEmail( String emailAddress) {

        try {
            Long id = jdbcTemplate.queryForObject(GET_STATUS_ID_BY_STATUS_VALUE_FOR_EMAIL_QUERY, Long.class,
                    //companyName,
                    emailAddress);
            LOGGER.info("Status id fetch success|{}", id);
            return id;
        } catch (EmptyResultDataAccessException e) {
            LOGGER.info("No status found");
            return 0L;
        }
    }

    public Long getStatusIdByStatusValueForCompanyName(String companyName) {

        try {
            Long id = jdbcTemplate.queryForObject(GET_STATUS_ID_BY_STATUS_VALUE_FOR_COMPANY_NAME_QUERY, Long.class,companyName);
            LOGGER.info("Status id fetch success|{}", id);
            return id;
        } catch (EmptyResultDataAccessException e) {
            LOGGER.info("No status found");
            return 0L;
        }
    }

    /**
     * getStatusNameById
     * @param statusId
     * @return
     */
    public String getStatusNameById(Long statusId) {
        try {
            String name = jdbcTemplate.queryForObject(GET_STATUS_NAME_BY_ID_QUERY, String.class, statusId);
            LOGGER.info("Status name fetch success|{}", name);
            return name;
        } catch (EmptyResultDataAccessException e) {
            LOGGER.info("No status found");
            return null;
        }
    }

    public Long getStatusIdByStatusValue(CustomerRegistrationRequestStatusEnum status) {

        String sql = "SELECT id FROM t_customer_registration_request_status where value = ?";

        try {
            Long id = jdbcTemplate.queryForObject(sql, Long.class, status.name());
            LOGGER.info("Status id fetch success|{}", status.name());
            return id;
        } catch (EmptyResultDataAccessException e) {
            LOGGER.info("No status found");
            throw new CommonException(String.format(messageUtils.getPropertyValue(NO_STATUS_FIND_BY_NAME_ERROR_MESSAGE), status),
                    messageUtils.getPropertyValue(NO_STATUS_FIND_BY_NAME_ERROR_CODE), messageUtils.getPropertyValue(EXECUTION_ERROR_TYPE), HttpStatus.NOT_FOUND);
        }
    }


}
