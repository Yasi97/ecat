package com.booleanlabs.ecatalogue.customerservice.domain.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import static jakarta.persistence.GenerationType.SEQUENCE;

/**
 * @author chamindu
 * @created 08/01/2024 - 4:45 PM
 * @project master-data-service
 */
@Entity
@Table(name = "T_CUSTOMER_REGISTRATION_REQUEST_STATUS")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CustomerRegistrationRequestStatusEntity extends AuditInfoEntity{
    @Id
    @Column(name = "id")
    @SequenceGenerator(name = "SEQ_REQUEST_STATUS", sequenceName = "SEQ_REQUEST_STATUS", allocationSize = 1)
    @GeneratedValue(strategy = SEQUENCE, generator = "SEQ_REQUEST_STATUS")
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "color_code")
    private String colorCode;
}
