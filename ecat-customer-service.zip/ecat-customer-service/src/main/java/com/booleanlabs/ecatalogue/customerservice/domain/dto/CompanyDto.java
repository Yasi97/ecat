package com.booleanlabs.ecatalogue.customerservice.domain.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CompanyDto {
    private Long companyId;
    private Long countryId;
    private Long industryId;
    private String companyName;
    private String companyAddress;
    private String purpose;
}
