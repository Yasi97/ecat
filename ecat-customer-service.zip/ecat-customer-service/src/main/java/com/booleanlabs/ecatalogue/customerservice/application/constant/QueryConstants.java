package com.booleanlabs.ecatalogue.customerservice.application.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class QueryConstants {

    public static final String SEARCH_CUSTOMER_REGISTRATION_REQUESTS_QUERY = "SELECT " +
            "crr.request_id, " +
            "crr.status_id, " +
            "crr.company_name, " +
            "crr.purpose, " +
            "crr.first_name, " +
            "crr.last_name, " +
            "crr.phone_number, " +
            "crr.designation, " +
            "crr.email_address, " +
            "crr.created_date, " +
            "crr.updated_date, " +
            "crrs.name as status_name, " +
            "crrs.color_code, " +
            "i.name as industry_name, " +
            "c.name as country_name " +
            "FROM t_customer_registration_request crr " +
            "JOIN t_customer_registration_request_status crrs ON crr.status_id = crrs.id " +
            "JOIN t_country c ON crr.country_id = c.id " +
            "JOIN t_industry i ON crr.industry_id = i.id " +
            "WHERE " +
            "((UPPER(crr.first_name) || ' ' || UPPER(crr.last_name)) LIKE '%' || UPPER(?) || '%') " +
            "AND (? IS NULL OR crr.created_date >= TO_DATE(?, 'YYYY-MM-DD')) " +
            "AND (? IS NULL OR crr.created_date <= TO_DATE(?, 'YYYY-MM-DD')) " +
            "AND (? IS NULL OR crr.status_id = ?) " +
            "ORDER BY crr.request_id OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

    public static final String SEARCH_CUSTOMER_REGISTRATION_REQUESTS_COUNT_QUERY = "SELECT COUNT(*) FROM t_customer_registration_request crr " +
            "WHERE " +
            "((UPPER(crr.first_name) || ' ' || UPPER(crr.last_name)) LIKE '%' || UPPER(?) || '%') " +
            "AND (? IS NULL OR crr.created_date >= TO_DATE(?, 'YYYY-MM-DD')) " +
            "AND (? IS NULL OR crr.created_date <= TO_DATE(?, 'YYYY-MM-DD')) " +
            "AND (? IS NULL OR crr.status_id = ?)";

    public static final String GET_STATUS_ID_BY_STATUS_VALUE_FOR_EMAIL_QUERY = "SELECT status_id FROM t_customer_registration_request " +
            "WHERE " +
            //"UPPER(company_name) = UPPER(?) AND " +
            "UPPER(email_address) = UPPER(?)";
            //" AND " +
           // "status_id IN (SELECT id FROM t_customer_registration_request_status WHERE name != ?)";

    public static final String GET_STATUS_ID_BY_STATUS_VALUE_FOR_COMPANY_NAME_QUERY = "SELECT status_id FROM t_customer_registration_request " +
            "WHERE " +
            "UPPER(company_name) = UPPER(?) ";
            //"AND " +
            //"UPPER(email_address) = UPPER(?) AND " +
           // "status_id IN (SELECT id FROM t_customer_registration_request_status WHERE name != ?)";

    public static final String GET_STATUS_NAME_BY_ID_QUERY = "select name from t_customer_registration_request_status where id = ?";

    public static final String CREATE_CUSTOMER_REGISTRATION_REQUEST_QUERY = "insert into T_CUSTOMER_REGISTRATION_REQUEST " +
            "(country_id, industry_id, status_id, company_name, purpose, first_name, last_name, phone_number, designation, email_address, created_user, created_date, updated_user, updated_date, is_deleted, is_active)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    public static final String GET_CUSTOMER_REGISTRATION_REQUEST_BY_ID_QUERY  = "SELECT \n" +
            "    crr.request_id, crr.country_id,\n" +
            "    crr.industry_id,\n" +
            "    crr.status_id,\n" +
            "    crr.company_name,\n" +
            "    crr.purpose,\n" +
            "    crr.first_name,\n" +
            "    crr.last_name,\n" +
            "    crr.phone_number,\n" +
            "    crr.designation,\n" +
            "    crr.email_address\n" +
            "FROM t_customer_registration_request crr\n" +
            "WHERE crr.request_id = ?";

    public static final String UPDATE_CUSTOMER_REGISTRATION_REQUEST_STATUS_QUERY = "UPDATE t_customer_registration_request SET status_id = ? WHERE request_id = ?";

    public static final String INSERT_COMPANY_QUERY = "INSERT INTO t_company ( country_id, industry_id, company_name, company_address, purpose\n" +
            ") VALUES ( ?, ?, ?, ?, ?);";

    public static final String UPDATE_COMPANY_QUERY = "UPDATE t_company \n" +
            " SET \n" +
            "    country_id = CASE WHEN ? IS NOT NULL THEN ? ELSE country_id END,\n" +
            "    industry_id = CASE WHEN ? IS NOT NULL THEN ? ELSE industry_id END,\n" +
            "    company_name = CASE WHEN ? IS NOT NULL THEN ? ELSE company_name END, \n" +
            "    company_address = CASE WHEN ? IS NOT NULL THEN ? ELSE company_address END \n" +
            " WHERE\n" +
            "    company_id = ? \n";

    public static final String UPDATE_CUSTOMER_QUERY = "UPDATE t_customer\n" +
            "SET\n" +
            "    brand_id = CASE WHEN ? IS NOT NULL THEN ? ELSE brand_id END,\n" +
            "    first_name = CASE WHEN ? IS NOT NULL THEN ? ELSE first_name END,\n" +
            "    last_name = CASE WHEN ? IS NOT NULL THEN ? ELSE last_name END,\n" +
            "    phone_number = CASE WHEN ? IS NOT NULL THEN ? ELSE phone_number END,\n" +
            "    designation = CASE WHEN ? IS NOT NULL THEN ? ELSE designation END \n" +
            "WHERE\n" +
            "    customer_id = ? \n";

    public static final String DELETE_CUSTOMER_QUERY = "DELETE FROM t_customer WHERE customer_id = ?";

    public static final String FETCH_CUSTOMER_READ_QUERY = "select cus.customer_id, cus.first_name, cus.last_name, cus.phone_number, cus.designation,\n" +
            "            usr.user_id, usr.email_address, usr.is_active,\n" +
            "            br.brand_id, br.brand_name,\n" +
            "            cmp.company_id, cmp.company_name, cmp.company_address,\n" +
            "            i.name as industry_name, cn.name as country_name \n" +
            "            from t_customer cus\n" +
            "            join t_brand br on cus.brand_id = br.brand_id\n" +
            "            join t_company cmp on cus.company_id = cmp.company_id\n" +
            "            join t_industry i on cmp.industry_id = i.id\n" +
            "            join t_country cn on cmp.country_id = cn.id\n" +
            "            join t_user usr on cus.user_id = usr.user_id\n" +
            "            where cus.customer_id = ?";

    public static final String FETCH_CUSTOMER_UPDATE_QUERY = "select cus.customer_id, cus.first_name, cus.last_name, cus.phone_number, cus.designation,\n" +
            "            usr.user_id, usr.email_address, usr.is_active,\n" +
            "            br.brand_id, br.brand_name,\n" +
            "            cmp.company_id, cmp.company_name, cmp.company_address,\n" +
            "            i.id as industry_id, cn.id as country_id\n" +
            "            from t_customer cus\n" +
            "            join t_brand br on cus.brand_id = br.brand_id\n" +
            "            join t_company cmp on cus.company_id = cmp.company_id\n" +
            "            join t_industry i on cmp.industry_id = i.id\n" +
            "            join t_country cn on cmp.country_id = cn.id\n" +
            "            join t_user usr on cus.user_id = usr.user_id\n" +
            "            where cus.customer_id = ?";


    public static final String SEARCH_CUSTOMER_QUERY = "select  c.customer_id, u.email_address , c.first_name, c.last_name, b.brand_name, u.is_active , cmp.company_name\n" +
            "        from t_customer c\n" +
            "        left join t_brand b on c.brand_id = b.brand_id\n" +
            "        left join t_user u on c.user_id = u.user_id\n" +
            "        left join t_company cmp on c.company_id = cmp.company_id   \n" +
            "        where ((UPPER(c.first_name) || ' ' || UPPER(c.last_name)) LIKE '%' || UPPER(?) || '%')\n" +
            "        AND   (? IS NULL OR c.brand_id = ?)\n" +
            "        order by c.customer_id desc \n" +
            "        OFFSET ? ROWS FETCH NEXT ? ROWS ONLY ";

    public static final String SEARCH_CUSTOMER_COUNT_QUERY = "select COUNT(*) \n" +
            "        from t_customer c\n" +
            "        left join t_brand b on c.brand_id = b.brand_id\n" +
            "        left join t_user u on c.user_id = u.user_id\n" +
            "        left join t_company cmp on c.company_id = cmp.company_id   \n" +
            "        where ((UPPER(c.first_name) || ' ' || UPPER(c.last_name)) LIKE '%' || UPPER(?) || '%')\n" +
            "        AND   (? IS NULL OR c.brand_id = ?) ";


}
