package com.booleanlabs.ecatalogue.customerservice.domain.util;

public enum UserTypeEnum {
    CUSTOMER,
    ADMIN,
    CUSTOMER_ADMIN
}
