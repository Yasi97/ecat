package com.booleanlabs.ecatalogue.customerservice.application.response.dto.customer;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class CompanyDto {

       private Long companyId;
       private Long countryId;
       private Long industryId;
       private String countryName;
       private String industryName;
       private String companyName;
       private String companyAddress;
}

