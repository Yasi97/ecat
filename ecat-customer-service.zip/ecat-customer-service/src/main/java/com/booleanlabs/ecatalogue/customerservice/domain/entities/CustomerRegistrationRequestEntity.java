package com.booleanlabs.ecatalogue.customerservice.domain.entities;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.ENTITY_ERROR_MAX_SIZE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.ENTITY_ERROR_NOT_NULL;
import static jakarta.persistence.GenerationType.SEQUENCE;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CustomerRegistrationRequestEntity extends AuditInfoEntity {

    private Long id;
    private Long countryId;
    private Long industryId;
    private Long statusId;
    private String companyName;
    private String purpose;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String designation;
    private String emailAddress;
}
