package com.booleanlabs.ecatalogue.customerservice.external.adaptor;

import java.util.Map;

/**
 * @author dilanka
 * @created 14/01/2024 - 9:34 AM
 * @project ecat-backend
 */
public interface RedisOperationsInterface<H, K, V> {
    void save(H key, K hashKey, V value);

    V getOne(H key, K hashKey);

    void update(H key, K hashKey, V value);

    Map<K, V> getAll(H key);

    void delete(H key, K hashKey);

    void deleteAll(H key);

    void saveAll(H key, Map<K, V> map);

    boolean hasKey(H key, K hashKey);
}
