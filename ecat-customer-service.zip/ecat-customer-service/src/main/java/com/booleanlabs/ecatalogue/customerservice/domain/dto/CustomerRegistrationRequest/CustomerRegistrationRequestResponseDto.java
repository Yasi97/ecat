package com.booleanlabs.ecatalogue.customerservice.domain.dto.CustomerRegistrationRequest;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.sql.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerRegistrationRequestResponseDto implements Serializable {

    private Long requestId;
    private String companyName;
    private String purpose;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String designation;
    private String emailAddress;
    private Date createdDate;
    private Date updatedDate;
    private String countryName;
    private Long countryId;
    private String industryName;
    private Long industryId;
    private Long statusId;
    private String statusName;
    private String statusColorCode;

}
