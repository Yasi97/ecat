package com.booleanlabs.ecatalogue.customerservice.application.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class PatternConstants {
    public static final String PATTERN_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static final String PATTERN_DATE_FORMAT_YYYY_MM_DD = "YYYY-MM-dd";
}
