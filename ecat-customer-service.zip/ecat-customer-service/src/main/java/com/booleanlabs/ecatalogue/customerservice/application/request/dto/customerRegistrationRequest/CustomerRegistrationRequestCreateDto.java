package com.booleanlabs.ecatalogue.customerservice.application.request.dto.customerRegistrationRequest;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

import java.io.Serializable;

import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.ENTITY_ERROR_MAX_SIZE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.ErrorConstants.ENTITY_ERROR_NOT_NULL;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder(toBuilder = true)
@ToString
public class CustomerRegistrationRequestCreateDto implements Serializable {


    @NotNull(message = ENTITY_ERROR_NOT_NULL)
    private Long countryId;

    @NotNull(message = ENTITY_ERROR_NOT_NULL)
    private Long industryId;

    @NotEmpty(message = ENTITY_ERROR_NOT_NULL)
    @Size(max = 50, message = ENTITY_ERROR_MAX_SIZE)
    private String companyName;

    @Size(max = 300, message = ENTITY_ERROR_MAX_SIZE)
    private String purpose;

    @NotEmpty(message = ENTITY_ERROR_NOT_NULL)
    @Size(max = 50, message = ENTITY_ERROR_MAX_SIZE)
    private String firstName;

    @NotEmpty(message = ENTITY_ERROR_NOT_NULL)
    @Size(max = 50, message = ENTITY_ERROR_MAX_SIZE)
    private String lastName;

    @NotEmpty(message = ENTITY_ERROR_NOT_NULL)
    @Size(max = 50, message = ENTITY_ERROR_MAX_SIZE)
    private String phoneNumber;

    @Size(max = 100, message = ENTITY_ERROR_MAX_SIZE)
    private String designation;

    @NotEmpty(message = ENTITY_ERROR_NOT_NULL)
    @Size(max = 100, message = ENTITY_ERROR_MAX_SIZE)
    private String emailAddress;

}
