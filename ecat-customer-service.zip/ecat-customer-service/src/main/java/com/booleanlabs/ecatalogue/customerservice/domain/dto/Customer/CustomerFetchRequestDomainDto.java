package com.booleanlabs.ecatalogue.customerservice.domain.dto.Customer;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CustomerFetchRequestDomainDto implements Serializable {

    private Long customerId;
    private String operationType;
}
