package com.booleanlabs.ecatalogue.customerservice.external.repository.mapper;

import com.booleanlabs.ecatalogue.customerservice.domain.dto.Customer.CustomerFetchDto;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.VAR_READ;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.VAR_UPDATE;

@AllArgsConstructor
public class CustomerFetchRowMapper implements RowMapper<CustomerFetchDto> {

    private String operationType;
    @Override
    public CustomerFetchDto mapRow(ResultSet rs, int rowNum) throws SQLException {

        CustomerFetchDto customerFetchDto = new CustomerFetchDto();
        customerFetchDto.setCustomerId(rs.getLong("CUSTOMER_ID"));
        customerFetchDto.setFirstName(rs.getString("FIRST_NAME"));
        customerFetchDto.setLastName(rs.getString("LAST_NAME"));
        customerFetchDto.setPhoneNumber(rs.getString("PHONE_NUMBER"));
        customerFetchDto.setDesignation(rs.getString("DESIGNATION"));
        customerFetchDto.setUserId(rs.getLong("USER_ID"));
        customerFetchDto.setEmailAddress(rs.getString("EMAIL_ADDRESS"));
        customerFetchDto.setActive(rs.getBoolean("IS_ACTIVE"));
        customerFetchDto.setBrandId(rs.getLong("BRAND_ID"));
        customerFetchDto.setBrandName(rs.getString("BRAND_NAME"));
        customerFetchDto.setCompanyId(rs.getLong("COMPANY_ID"));
        customerFetchDto.setCompanyName(rs.getString("COMPANY_NAME"));
        customerFetchDto.setCompanyAddress(rs.getString("COMPANY_ADDRESS"));

        if(StringUtils.equals(operationType, VAR_UPDATE)) {
            customerFetchDto.setIndustryId(rs.getLong("INDUSTRY_ID"));
            customerFetchDto.setCountryId(rs.getLong("COUNTRY_ID"));
        } else if (StringUtils.equals(operationType, VAR_READ)) {
            customerFetchDto.setIndustryName(rs.getString("INDUSTRY_NAME"));
            customerFetchDto.setCountryName(rs.getString("COUNTRY_NAME"));
        }

        return customerFetchDto;
    }
}
