package com.booleanlabs.ecatalogue.customerservice.external.repository;

import com.booleanlabs.ecatalogue.customerservice.application.exception.CommonException;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.BaseSearchResponseDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.CustomerRegistrationRequest.CustomerRegistrationRequestResponseDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.CustomerRegistrationRequest.CustomerRegistrationRequestResponseViewDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.CustomerRegistrationRequest.CustomerRegistrationRequestSearchDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.CustomerRegistrationRequest.UpdateCustomerRegistrationRequestStatusDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.entities.CustomerRegistrationRequestEntity;
import com.booleanlabs.ecatalogue.customerservice.domain.entities.CustomerRegistrationRequestSearchRequestEntity;
import com.booleanlabs.ecatalogue.customerservice.external.repository.mapper.CustomerRegistrationRequestSearchRowMapper;
import com.booleanlabs.ecatalogue.customerservice.external.repository.mapper.CustomerRegistrationRequestViewRowMapper;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static com.booleanlabs.ecatalogue.customerservice.application.constant.PatternConstants.PATTERN_DATE_FORMAT;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.PatternConstants.PATTERN_DATE_FORMAT_YYYY_MM_DD;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.QueryConstants.CREATE_CUSTOMER_REGISTRATION_REQUEST_QUERY;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.QueryConstants.GET_CUSTOMER_REGISTRATION_REQUEST_BY_ID_QUERY;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.QueryConstants.SEARCH_CUSTOMER_REGISTRATION_REQUESTS_COUNT_QUERY;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.QueryConstants.SEARCH_CUSTOMER_REGISTRATION_REQUESTS_QUERY;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.QueryConstants.UPDATE_CUSTOMER_REGISTRATION_REQUEST_STATUS_QUERY;

@Repository
@RequiredArgsConstructor
public class CustomerRegistrationRequestRepository {

    private final JdbcTemplate jdbcTemplate;

    private static final Logger LOGGER = LogManager.getLogger(CustomerRegistrationRequestRepository.class);

    /**
     * Create customer registration request repository
     *
     * @param customerRegistrationRequestEntity
     * @return
     */
    public int save(CustomerRegistrationRequestEntity customerRegistrationRequestEntity) {

        LOGGER.info("Create Customer Registration Request repository started");

        int affectedCount = jdbcTemplate.update(CREATE_CUSTOMER_REGISTRATION_REQUEST_QUERY,
                customerRegistrationRequestEntity.getCountryId(),
                customerRegistrationRequestEntity.getIndustryId(),
                customerRegistrationRequestEntity.getStatusId(),
                customerRegistrationRequestEntity.getCompanyName(),
                customerRegistrationRequestEntity.getPurpose(),
                customerRegistrationRequestEntity.getFirstName(),
                customerRegistrationRequestEntity.getLastName(),
                customerRegistrationRequestEntity.getPhoneNumber(),
                customerRegistrationRequestEntity.getDesignation(),
                customerRegistrationRequestEntity.getEmailAddress(),
                customerRegistrationRequestEntity.getCreatedUser(),
                customerRegistrationRequestEntity.getCreatedDate(),
                customerRegistrationRequestEntity.getUpdatedUser(),
                customerRegistrationRequestEntity.getUpdatedDate(),
                customerRegistrationRequestEntity.getDeleted(),
                customerRegistrationRequestEntity.getActive()
        );
        LOGGER.info("Create Customer Registration Request success with id:{}", affectedCount);
        return affectedCount;
    }

    /**
     * searchCustomerRegistrationRequests
     *
     * @param searchCustomerRegistrationRequestResponseDtoBaseSearchResponseDto
     * @return List<CustomerRegistrationRequestResponseEntity>
     */
    public List<CustomerRegistrationRequestResponseDto> searchCustomerRegistrationRequests(CustomerRegistrationRequestSearchRequestEntity customerRegistrationRequestSearchRequestEntity            ,
                                                                                           BaseSearchResponseDomainDto<CustomerRegistrationRequestSearchDto> searchCustomerRegistrationRequestResponseDtoBaseSearchResponseDto) {

        LOGGER.info("Search Customer Registration Requests repository started");

        String name = customerRegistrationRequestSearchRequestEntity.getSearchText();
        String fromDate = convertToOracleDate(customerRegistrationRequestSearchRequestEntity.getDateFrom());
        String toDate = convertToOracleDate(customerRegistrationRequestSearchRequestEntity.getDateTo());
        Long statusId = customerRegistrationRequestSearchRequestEntity.getStatusId();
        int pageIndex = customerRegistrationRequestSearchRequestEntity.getPageIndex();
        int itemsPerPage = customerRegistrationRequestSearchRequestEntity.getItemPerPage();

        int offset = (pageIndex - 1) * itemsPerPage;

        List<CustomerRegistrationRequestResponseDto> customerRegistrationRequestResponseEntities = jdbcTemplate.query(
                SEARCH_CUSTOMER_REGISTRATION_REQUESTS_QUERY, new CustomerRegistrationRequestSearchRowMapper(),
                name, fromDate, fromDate, toDate, toDate, statusId, statusId, offset, itemsPerPage);

        int totalRecords = jdbcTemplate.queryForObject(
                SEARCH_CUSTOMER_REGISTRATION_REQUESTS_COUNT_QUERY, Integer.class,
                name, fromDate, fromDate, toDate, toDate, statusId, statusId);

        int totalPages = (int) Math.ceil((double) totalRecords / itemsPerPage);

        searchCustomerRegistrationRequestResponseDtoBaseSearchResponseDto.setTotalItems(totalRecords);
        searchCustomerRegistrationRequestResponseDtoBaseSearchResponseDto.setTotalPages(totalPages);

        LOGGER.info("Search Customer Registration Requests success");
        return customerRegistrationRequestResponseEntities;
    }

    /**
     * getCustomerRegistrationRequest
     *
     * @param requestId
     * @return
     */
    public CustomerRegistrationRequestResponseDto getCustomerRegistrationRequest(Long requestId) {
        LOGGER.info("Search Customer Registration Requests repository started");
        try {
            CustomerRegistrationRequestResponseDto customerRegistrationRequestResponseDto
                    = jdbcTemplate.queryForObject(GET_CUSTOMER_REGISTRATION_REQUEST_BY_ID_QUERY, new CustomerRegistrationRequestViewRowMapper(), requestId);
            LOGGER.info("Get Customer Registration Request Success|requestId:{}", requestId);
            return customerRegistrationRequestResponseDto;
        } catch (EmptyResultDataAccessException e) {
            LOGGER.warn("Customer Registration Request Not Found");
            return null;
        }
    }


    /**
     * updateCustomerRegistrationRequestStatusRequest
     * @param updateCustomerRegistrationRequestStatusDomainDto
     * @return
     */
    public int updateCustomerRegistrationRequestStatusRequest(UpdateCustomerRegistrationRequestStatusDomainDto updateCustomerRegistrationRequestStatusDomainDto) {
        LOGGER.info("Update Customer Registration Requests Status repository started");
        return jdbcTemplate.update(UPDATE_CUSTOMER_REGISTRATION_REQUEST_STATUS_QUERY,
                updateCustomerRegistrationRequestStatusDomainDto.getStatusId(), updateCustomerRegistrationRequestStatusDomainDto.getRequestId());
    }


    private String convertToOracleDate(String inputDate) {
        if (StringUtils.isEmpty(inputDate)) {
            return null;
        }
        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat(PATTERN_DATE_FORMAT);
            Date date = inputFormat.parse(inputDate);

            SimpleDateFormat outputFormat = new SimpleDateFormat(PATTERN_DATE_FORMAT_YYYY_MM_DD);
            return outputFormat.format(date).toUpperCase();
        } catch (ParseException e) {
            e.printStackTrace();
            throw new CommonException("Error in creating customer request", "0019", "INTERNAL", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
