package com.booleanlabs.ecatalogue.customerservice.domain.dto.Customer;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder(toBuilder = true)
@ToString
public class UpdateCustomerRequestDomainDto {

    private Long customerId;
    private Long countryId;
    private Long industryId;
    private Long companyId;
    private String companyName;
    private String companyAddress;
    private Long brandId;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String designation;

}
