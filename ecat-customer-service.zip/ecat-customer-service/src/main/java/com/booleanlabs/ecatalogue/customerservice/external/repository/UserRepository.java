package com.booleanlabs.ecatalogue.customerservice.external.repository;

import com.booleanlabs.ecatalogue.customerservice.domain.util.UserTypeEnum;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
@RequiredArgsConstructor
public class UserRepository {

    private final JdbcTemplate jdbcTemplate;

    private static final Logger LOGGER = LogManager.getLogger(UserRepository.class);

    public Long createUser(Long roleId, UserTypeEnum userType, String emailAddress, String password, Boolean isActive) {
        LOGGER.info("Create User repository stared");
        String getSeq = "select SEQ_USER.nextval from dual";
        String sql = "INSERT INTO t_user (user_id, role_id, user_type, email_address, user_password, is_active) VALUES (?, ?, ?, ?, ?, ?)";

        Long nextVal = jdbcTemplate.queryForObject(getSeq, Long.class);
        jdbcTemplate.update(sql, nextVal, roleId, userType.name(), emailAddress, password, isActive);

        LOGGER.info("Create User success|userId:{}", nextVal);
        return nextVal;
    }
}
