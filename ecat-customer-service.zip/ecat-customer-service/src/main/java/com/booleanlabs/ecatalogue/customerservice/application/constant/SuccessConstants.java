package com.booleanlabs.ecatalogue.customerservice.application.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * @author dilanka
 * @created 07/01/2024 - 8:02 PM
 * @project master-data-service
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class SuccessConstants {
    public static final String SUCCESS_MESSAGE = "success";
    public static final String ACTION_SUCCESS_MESSAGE = "action.success";
    public static final String SUCCESS_CODE = "0000";

    public static final String CREATE_CUSTOMER_REGISTRATION_REQUEST_SUCCESS = "message.create.customer.registration.request.success";
    public static final String UPDATE_CUSTOMER_REGISTRATION_REQUEST_STATUS_SUCCESS = "message.customer.registration.request.status.update.success";
    public static final String CUSTOMER_CREATE_SUCCESS = "message.customer.create.success";
    public static final String CUSTOMER_UPDATE_SUCCESS = "message.customer.update.success";
    public static final String CUSTOMER_DELETE_SUCCESS = "message.customer.delete.success";
}
