package com.booleanlabs.ecatalogue.customerservice.external.repository;

import com.booleanlabs.ecatalogue.customerservice.domain.dto.Customer.CustomerCreateDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.Customer.UpdateCustomerRequestDomainDto;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import static com.booleanlabs.ecatalogue.customerservice.application.constant.QueryConstants.UPDATE_COMPANY_QUERY;

@Repository
@RequiredArgsConstructor
public class CompanyRepository {

    private final JdbcTemplate jdbcTemplate;
    private static final Logger LOGGER = LogManager.getLogger(CompanyRepository.class);

    @Transactional
    public Long createCompany(CustomerCreateDomainDto customerCreateDomainDto) {

        Long country_id = customerCreateDomainDto.getCountryId();
        Long industry_id = customerCreateDomainDto.getIndustryId();
        String company_name = customerCreateDomainDto.getCompanyName();
        String company_address = customerCreateDomainDto.getCompanyAddress();
        String purpose = customerCreateDomainDto.getPurpose();

        LOGGER.info("Company create repository stared");
        String getSeq = "select SEQ_COMPANY.nextval from dual";
        String sql = "INSERT INTO t_company (company_id, country_id, industry_id, company_name, company_address, purpose) VALUES (?, ?, ?, ?, ?, ?)";

        Long nextVal = jdbcTemplate.queryForObject(getSeq, Long.class);
        jdbcTemplate.update(sql, nextVal, country_id, industry_id, company_name, company_address, purpose);

        LOGGER.info("Company create success|companyId:{}", nextVal);

        return nextVal;
    }

    public int updateCompany(UpdateCustomerRequestDomainDto updateCustomerRequestDomainDto) {
        LOGGER.info("Company update repository stared");
        Long company_id = updateCustomerRequestDomainDto.getCompanyId();
        Long country_id = updateCustomerRequestDomainDto.getCountryId();
        Long industry_id = updateCustomerRequestDomainDto.getIndustryId();
        String company_name = updateCustomerRequestDomainDto.getCompanyName();
        String company_address = updateCustomerRequestDomainDto.getCompanyAddress();

        int affectedRowCount = jdbcTemplate.update(UPDATE_COMPANY_QUERY,
                country_id, country_id,
                industry_id, industry_id,
                company_name, company_name,
                company_address, company_address,
                company_id);
        return affectedRowCount;
    }

    public int countCompanyNames(String companyName) {
        String sql = "SELECT COUNT(company_id) FROM t_company WHERE UPPER(company_name) = UPPER(?)";
        return jdbcTemplate.queryForObject(sql, Integer.class, companyName);
    }
}
