package com.booleanlabs.ecatalogue.customerservice.application.controller;

import com.booleanlabs.ecatalogue.customerservice.application.request.dto.customerRegistrationRequest.CustomerRegistrationRequestCreateDto;
import com.booleanlabs.ecatalogue.customerservice.application.request.dto.customerRegistrationRequest.CustomerRegistrationRequestSearchRequest;
import com.booleanlabs.ecatalogue.customerservice.application.request.dto.customerRegistrationRequest.UpdateCustomerRegistrationRequestStatusRequest;
import com.booleanlabs.ecatalogue.customerservice.application.response.dto.ErrorMessage;
import com.booleanlabs.ecatalogue.customerservice.application.response.dto.SuccessMessage;
import com.booleanlabs.ecatalogue.customerservice.application.util.ResponseUtils;
import com.booleanlabs.ecatalogue.customerservice.application.validator.RequestEntityValidator;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.BaseSearchResponseDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.CustomerRegistrationRequest.CustomerRegistrationRequestDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.CustomerRegistrationRequest.CustomerRegistrationRequestResponseDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.CustomerRegistrationRequest.CustomerRegistrationRequestSearchDto;
import com.booleanlabs.ecatalogue.customerservice.domain.dto.CustomerRegistrationRequest.UpdateCustomerRegistrationRequestStatusDomainDto;
import com.booleanlabs.ecatalogue.customerservice.domain.entities.CustomerRegistrationRequestSearchRequestEntity;
import com.booleanlabs.ecatalogue.customerservice.domain.service.CustomerRegistrationRequestService;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.APP_ROOT_V1_WEB;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.Actions.CREATE;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.Actions.LOAD_ID;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.Actions.SEARCH;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.Actions.UPDATE_STATUS;
import static com.booleanlabs.ecatalogue.customerservice.application.constant.AppConstants.MESSAGE;

@RestController
@RequestMapping(APP_ROOT_V1_WEB + "/customer-registration-request")
@Validated
@RequiredArgsConstructor
@Slf4j
public class CustomerRegistrationRequestController {

    private final ResponseUtils responseUtils;
    private final CustomerRegistrationRequestService customerRegistrationRequestService;
    private final RequestEntityValidator validator;

    private final ObjectMapper mapper;
    private static final Logger LOGGER = LogManager.getLogger(CustomerRegistrationRequestController.class);


    @Operation(summary = "Create Customer Registration Request")
    @ApiResponses(value = {
            @ApiResponse(description = "Create Customer Registration Request Success", responseCode = "201"),
            @ApiResponse(description = "Bad Request in Customer Registration Request", responseCode = "400", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))}),
            @ApiResponse(description = "Exception occurred when processing Create Customer Registration Request", responseCode = "500", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))})})
    @PostMapping(value = CREATE, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessMessage<Map<String, String>>> createCustomerRegistrationRequest(@RequestBody final CustomerRegistrationRequestCreateDto customerRegistrationRequestCreateDto) {

        LOGGER.info("Create Customer Registration Request Initiated");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Request|" + customerRegistrationRequestCreateDto.toString());
        }

        validator.validate(customerRegistrationRequestCreateDto);

        CustomerRegistrationRequestDomainDto customerRegistrationRequestDomainDto =
                mapper.convertValue(customerRegistrationRequestCreateDto, CustomerRegistrationRequestDomainDto.class);

        Map<String, String> serviceResponse =
                customerRegistrationRequestService.createCustomerRegistrationRequest(customerRegistrationRequestDomainDto);

        final ResponseEntity<SuccessMessage<Map<String, String>>> response = responseUtils.wrapSuccess(serviceResponse, HttpStatus.CREATED);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Response|" + serviceResponse.get(MESSAGE));
        }
        LOGGER.info("Create Customer Registration Request Finish");
        return response;
    }


    @Operation(summary = "Search Customer Registration Request")
    @ApiResponses(value = {
            @ApiResponse(description = "Search Customer Registration Request Success", responseCode = "200"),
            @ApiResponse(description = "Bad Request in Search Customer Registration Request", responseCode = "400", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))}),
            @ApiResponse(description = "Exception occurred when processing Search Customer Registration Request", responseCode = "500", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))})})
    @PostMapping(value = SEARCH, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessMessage<BaseSearchResponseDomainDto>> searchCustomerRegistrationRequests(@RequestBody CustomerRegistrationRequestSearchRequest customerRegistrationRequestSearchRequest) {

        LOGGER.info("Search Customer Registration Request Initiated");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Request|" + customerRegistrationRequestSearchRequest.toString());
        }
        validator.validate(customerRegistrationRequestSearchRequest);

        CustomerRegistrationRequestSearchRequestEntity CustomerRegistrationRequestSearchRequestDomainDto =
                mapper.convertValue(customerRegistrationRequestSearchRequest, CustomerRegistrationRequestSearchRequestEntity.class);

        BaseSearchResponseDomainDto<CustomerRegistrationRequestSearchDto> searchCustomerRegistrationRequestResponseDtoBaseSearchResponseDto =
                customerRegistrationRequestService.searchCustomerRegistrationRequests(CustomerRegistrationRequestSearchRequestDomainDto);

        final ResponseEntity<SuccessMessage<BaseSearchResponseDomainDto>> response = responseUtils.wrapSuccess(searchCustomerRegistrationRequestResponseDtoBaseSearchResponseDto, HttpStatus.OK);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Request|" + searchCustomerRegistrationRequestResponseDtoBaseSearchResponseDto.toString());
        }
        LOGGER.info("Search Customer Registration Request Finish");
        return response;
    }

    @Operation(summary = "View Customer Registration Request")
    @ApiResponses(value = {
            @ApiResponse(description = "Get Customer Registration Request Success", responseCode = "200"),
            @ApiResponse(description = "Bad Request in Get Customer Registration Request", responseCode = "400", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))}),
            @ApiResponse(description = "Exception occurred when processing Get Customer Registration Request", responseCode = "500", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))})})
    @GetMapping(value = LOAD_ID, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessMessage<CustomerRegistrationRequestResponseDto>> getCustomerRegistrationRequest(@Validated @NotNull @PathVariable Long id) {

        LOGGER.info("View Customer Registration Request Initiated");
        LOGGER.debug("RequestId|" + id);

        CustomerRegistrationRequestResponseDto customerRegistrationRequestResponse =
                customerRegistrationRequestService.getCustomerRegistrationRequest(id);

        final ResponseEntity<SuccessMessage<CustomerRegistrationRequestResponseDto>> response
                = responseUtils.wrapSuccess(customerRegistrationRequestResponse, HttpStatus.OK);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Request|" + customerRegistrationRequestResponse.toString());
        }

        LOGGER.info("View Customer Registration Request Finish");
        return response;
    }

    @Operation(summary = "Update Customer Registration Request Status")
    @ApiResponses(value = {
            @ApiResponse(description = "Update Customer Registration Request Status Success", responseCode = "200"),
            @ApiResponse(description = "Bad Request in Update Customer Registration Request Status", responseCode = "400", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))}),
            @ApiResponse(description = "Exception occurred when processing Update Customer Registration Request Status", responseCode = "500", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))})})
    @PutMapping(value = UPDATE_STATUS, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessMessage<Map<String,String>>> updateCustomerRegistrationRequestStatus(@RequestBody UpdateCustomerRegistrationRequestStatusRequest updateCustomerRegistrationRequestStatusRequest) {

        LOGGER.info("Update Customer Registration Request Status Initiated");
        LOGGER.info("Request|{}", updateCustomerRegistrationRequestStatusRequest.toString());

        validator.validate(updateCustomerRegistrationRequestStatusRequest);

        UpdateCustomerRegistrationRequestStatusDomainDto updateCustomerRegistrationRequestStatusDomainDto =
                mapper.convertValue(updateCustomerRegistrationRequestStatusRequest, UpdateCustomerRegistrationRequestStatusDomainDto.class);

        Map<String, String> resultMap
                = customerRegistrationRequestService.updateCustomerRegistrationRequestStatus(updateCustomerRegistrationRequestStatusDomainDto);

        final ResponseEntity<SuccessMessage<Map<String, String>>> response = responseUtils.wrapSuccess(resultMap, HttpStatus.OK);

        LOGGER.info("Update Customer Registration Request Status Finish");
        return response;
    }
}
