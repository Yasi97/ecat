package com.booleanlabs.ecatalogue.authservice.ecatauthservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcatAuthServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
