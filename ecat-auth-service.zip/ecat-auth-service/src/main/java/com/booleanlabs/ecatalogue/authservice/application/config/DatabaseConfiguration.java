package com.booleanlabs.ecatalogue.authservice.application.config;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.*;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.util.Objects;

@Configuration
@PropertySource({"classpath:application.properties"})
@ComponentScan("com.booleanlabs.ecatalogue.authservice.*")
@EnableTransactionManagement
public class DatabaseConfiguration {

    @Value("${jdbcTemplate.query.timeOut}")
    private int queryTimeOut;

    @Primary
    @Bean
    public DataSource dataSource(Environment env) {
        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setDriverClassName(env.getProperty("ecatelog.jdbc.driverClassName"));
        dataSource.setJdbcUrl(env.getProperty("ecatelog.jdbc.url"));
        dataSource.setUsername(env.getProperty("ecatelog.jdbc.user"));
        dataSource.setPassword(env.getProperty("ecatelog.jdbc.pass"));
        dataSource.setMaximumPoolSize(Integer.parseInt(Objects.requireNonNull(env.getProperty("ecatelog.jdbc.connectionPool"))));
        dataSource.setMaxLifetime(Long.parseLong(Objects.requireNonNull(env.getProperty("ecatelog.jdbc.maxLifetime"))));
        dataSource.setMinimumIdle(Integer.parseInt(Objects.requireNonNull(env.getProperty("ecatelog.jdbc.minIdle"))));
        dataSource.setIdleTimeout(Integer.parseInt(Objects.requireNonNull(env.getProperty("ecatelog.jdbc.idleTimeOut"))));
        dataSource.setConnectionTimeout(Integer.parseInt(Objects.requireNonNull(env.getProperty("ecatelog.jdbc.connectionTimeOut"))));
        dataSource.setConnectionTestQuery("SELECT 1 FROM dual");
        dataSource.setConnectionTimeout(Integer.parseInt(Objects.requireNonNull(env.getProperty("ecatelog.jdbc.connectionTimeOut"))));
        dataSource.addDataSourceProperty("oracle.jdbc.timezoneAsRegion", "false");
        return dataSource;
    }

    @Bean
    public NamedParameterJdbcTemplate namedParameterJdbcTemplate(DataSource dataSource) {
        return new NamedParameterJdbcTemplate(dataSource);
    }

    @Primary
    @Bean
    public JdbcTemplate readJdbcTemplate(final Environment env) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource(env));
        jdbcTemplate.setQueryTimeout(queryTimeOut);
        return jdbcTemplate;
    }

    @Primary
    @Bean("oracleTxManager")
    public PlatformTransactionManager transactionManager(DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }

}
