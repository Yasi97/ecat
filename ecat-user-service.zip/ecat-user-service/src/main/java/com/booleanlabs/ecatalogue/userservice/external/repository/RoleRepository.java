package com.booleanlabs.ecatalogue.userservice.external.repository;

import com.booleanlabs.ecatalogue.userservice.domain.dto.role.RoleDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.entities.RoleEntity;
import com.booleanlabs.ecatalogue.userservice.external.repository.constant.QueryConstants;
import com.booleanlabs.ecatalogue.userservice.external.repository.mapper.role.RoleResultRowMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author dilanka
 * @created 23/01/2024 - 9:27 PM
 * @project ecat-user-service
 */
@Repository
@RequiredArgsConstructor
@Slf4j
public class RoleRepository {
    private final JdbcTemplate jdbcTemplate;

    /**
     * Create User in T_ROLE table
     *
     * @param request request
     */
    public void createRole(RoleDomainDto request) {
        final Long nextVal = jdbcTemplate.queryForObject(QueryConstants.ROLE.SEQ_NEXT_VAL, Long.class);
        jdbcTemplate.update(QueryConstants.ROLE.CREATE, nextVal, request.getRoleName(), request.getSystemActorId(), request.getRoleValue());

        log.info("Create role success|userId:{}", nextVal);
    }

    /**
     * Load all roles
     *
     * @return roles
     */
    public List<RoleEntity> loadAll() {
        return jdbcTemplate.query(QueryConstants.ROLE.LOAD_ALL, new RoleResultRowMapper());
    }
}
