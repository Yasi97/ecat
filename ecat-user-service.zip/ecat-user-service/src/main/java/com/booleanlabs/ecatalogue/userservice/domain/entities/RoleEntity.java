package com.booleanlabs.ecatalogue.userservice.domain.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author dilanka
 * @created 23/01/2024 - 9:22 PM
 * @project ecat-user-service
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class RoleEntity {

    private Long roleId;
    private String roleName;
    private String roleValue;
    private Long systemActorId;
    private Boolean isDefault;
}
