package com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author dilanka
 * @created 20/01/2024 - 5:59 PM
 * @project ecat-user-service
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class InternalUserSearchResponseDomainDto {
    private Long userId;
    private String roleName;
    private String firstName;
    private String lastName;
    private String plantName;
    private String departmentName;
}
