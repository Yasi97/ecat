package com.booleanlabs.ecatalogue.userservice.application.request.dto.role;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.ENTITY_ERROR_MAX_SIZE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.ENTITY_ERROR_NOT_NULL;

/**
 * @author dilanka
 * @created 23/01/2024 - 9:22 PM
 * @project ecat-user-service
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class RoleCreateRequest {

    @NotEmpty(message = ENTITY_ERROR_NOT_NULL)
    @Size(
            max = 150,
            message = ENTITY_ERROR_MAX_SIZE
    )
    private String roleName;

    @NotNull(message = ENTITY_ERROR_NOT_NULL)
    private Long systemActorId;
}
