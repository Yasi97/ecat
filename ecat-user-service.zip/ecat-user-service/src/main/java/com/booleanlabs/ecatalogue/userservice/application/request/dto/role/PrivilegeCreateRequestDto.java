package com.booleanlabs.ecatalogue.userservice.application.request.dto.role;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.ENTITY_ERROR_NOT_NULL;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PrivilegeCreateRequestDto {
    @NotNull(message = ENTITY_ERROR_NOT_NULL)
    private Long roleId;

    @NotNull(message = ENTITY_ERROR_NOT_NULL)
    private List<Long> privilegeIds;
}