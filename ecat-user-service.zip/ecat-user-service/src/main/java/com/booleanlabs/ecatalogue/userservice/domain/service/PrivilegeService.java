package com.booleanlabs.ecatalogue.userservice.domain.service;

import com.booleanlabs.ecatalogue.userservice.application.exception.NotFoundException;
import com.booleanlabs.ecatalogue.userservice.application.exception.vm.ErrorField;
import com.booleanlabs.ecatalogue.userservice.application.util.MessageUtils;
import com.booleanlabs.ecatalogue.userservice.domain.dto.BaseResponseMessageDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.role.PrivilegeDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.role.RolePrivilegeSearchResponseDomainDto;
import com.booleanlabs.ecatalogue.userservice.external.repository.PrivilegeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.ERROR_9006;

/**
 * @author dilanka
 * @created 24/01/2024 - 6:21 AM
 * @project ecat-user-service
 */
@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class PrivilegeService {
    private final PrivilegeRepository privilegeRepository;
    private final MessageUtils messageUtils;

    /**
     * Create Role privilege
     *
     * @param requestDro request
     * @return response
     */
    public BaseResponseMessageDomainDto createRolePrivileges(PrivilegeDomainDto requestDro) {
        //Clear existing privileges
        privilegeRepository.clearRolePrivilegesByRoleId(requestDro.getRoleId());

        //Add new privileges
        privilegeRepository.createRolePrivilege(requestDro);

        return new BaseResponseMessageDomainDto("Privileges added successfully");
    }

    /**
     * Get all privileges by role id
     *
     * @param roleId role id
     * @return privileges
     */
    public RolePrivilegeSearchResponseDomainDto loadUpdate(Long roleId) {
        List<Long> privileges = privilegeRepository.loadUpdate(roleId);

        if (CollectionUtils.isEmpty(privileges)){
            final ErrorField errorField = messageUtils.getErrorField(ERROR_9006);
            throw new NotFoundException(errorField.getMessage(), errorField.getCode());
        }

        return new RolePrivilegeSearchResponseDomainDto(privileges);
    }
}
