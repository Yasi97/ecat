package com.booleanlabs.ecatalogue.userservice.domain.service;

import com.booleanlabs.ecatalogue.userservice.application.exception.ValidationException;
import com.booleanlabs.ecatalogue.userservice.application.exception.vm.ErrorField;
import com.booleanlabs.ecatalogue.userservice.application.util.MessageUtils;
import com.booleanlabs.ecatalogue.userservice.domain.dto.BaseLoadRequestDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.BaseResponseMessageDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.BaseSearchResponseDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.OperationType;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserCreateDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserLoadResponseDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserSearchRequestDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserSearchResponseDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserUpdateDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.entities.InternalUserSearchResultEntity;
import com.booleanlabs.ecatalogue.userservice.external.repository.InternalUserBrandRepository;
import com.booleanlabs.ecatalogue.userservice.external.repository.InternalUserRepository;
import com.booleanlabs.ecatalogue.userservice.external.repository.UserRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.ERROR_MESSAGE_RECORD_EXISTS;

/**
 * @author dilanka
 * @created 20/01/2024 - 7:57 AM
 * @project ecat-user-service
 */
@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class InternalUserUserService {
    private final UserRepository userRepository;
    private final InternalUserRepository internalUserRepository;
    private final InternalUserBrandRepository internalUserBrandRepository;
    private final MessageUtils messageUtils;
    private final ObjectMapper mapper;

    /**
     * Internal user creation
     *
     * @param request request
     * @return response
     */
    public BaseResponseMessageDomainDto createInternalUser(InternalUserCreateDomainDto request) {
        //validate if user already exists
        if (userRepository.isUserExist(request.getEmailAddress())) {
            final ErrorField errorField = messageUtils.getErrorField(ERROR_MESSAGE_RECORD_EXISTS);
            errorField.setField("emailAddress");
            throw new ValidationException(List.of(errorField));
        }

        //create user
        final Long userId = userRepository.createUser(request);

        //create internal user
        final Long internalUserId = internalUserRepository.createInternalUser(userId, request);

        //create internal user brand
        internalUserBrandRepository.createInternalUserBrand(internalUserId, request.getUserBrandIds());

        return new BaseResponseMessageDomainDto("User created successfully");
    }

    /**
     * Soft delete internal user
     *
     * @param id internal user id
     */
    public BaseResponseMessageDomainDto deleteInternalUser(Long id) {
        internalUserRepository.softDeleteUser(id);
        return new BaseResponseMessageDomainDto("User deleted successfully");
    }

    /**
     * Update internal user
     *
     * @param userUpdateDomainDto update request
     * @return response
     */
    public BaseResponseMessageDomainDto updateInternalUser(InternalUserUpdateDomainDto userUpdateDomainDto) {
        //update user
        userRepository.updateUser(userUpdateDomainDto);

        //update internal user
        internalUserRepository.updateInternalUser(userUpdateDomainDto);

        //update internal user brand
        final Long internalUserId = internalUserRepository.findIdByUserId(userUpdateDomainDto.getUserId());
        if (CollectionUtils.isNotEmpty(userUpdateDomainDto.getUserBrandIds())) {
            //delete old internal user brand
            internalUserBrandRepository.deleteInternalUserBrand(internalUserId);

            //create new internal user brand
            internalUserBrandRepository.createInternalUserBrand(internalUserId, userUpdateDomainDto.getUserBrandIds());
        } else {
            //delete old internal user brand
            internalUserBrandRepository.deleteInternalUserBrand(internalUserId);
        }

        return new BaseResponseMessageDomainDto("User updated successfully");
    }

    /**
     * Search internal user
     *
     * @param customerSearchDomainDto search request
     * @return search response
     */
    public BaseSearchResponseDomainDto<InternalUserSearchResponseDomainDto> searchInternalUser(InternalUserSearchRequestDomainDto customerSearchDomainDto) {
        final BaseSearchResponseDomainDto<InternalUserSearchResultEntity> searched = internalUserRepository.searchInternalUser(customerSearchDomainDto);
        return mapper.convertValue(searched, new TypeReference<>() {
        });
    }

    /**
     * Load internal user data by operation type
     *
     * @param loadRequestDomainDto load request
     * @return load response
     */
    public InternalUserLoadResponseDomainDto loadInternalUser(BaseLoadRequestDomainDto loadRequestDomainDto) {

        final InternalUserSearchResultEntity internalUserSearchResultEntity = internalUserRepository.loadInternalUser(loadRequestDomainDto);
        final InternalUserLoadResponseDomainDto responseDomainDto = mapper.convertValue(internalUserSearchResultEntity, InternalUserLoadResponseDomainDto.class);

        if (OperationType.READ.equals(loadRequestDomainDto.getOperationType())) {
            responseDomainDto.setUserBrandNames(internalUserBrandRepository.loadRead(internalUserSearchResultEntity.getId()));
        } else if (OperationType.UPDATE.equals(loadRequestDomainDto.getOperationType())) {
            responseDomainDto.setUserBrandIds(internalUserBrandRepository.loadUpdate(internalUserSearchResultEntity.getId()));
        }

        return responseDomainDto;
    }
}
