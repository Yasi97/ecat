package com.booleanlabs.ecatalogue.userservice.external.repository;

import com.booleanlabs.ecatalogue.userservice.domain.dto.BaseLoadRequestDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.BaseSearchResponseDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.OperationType;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserCreateDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserSearchRequestDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserUpdateDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.entities.InternalUserSearchResultEntity;
import com.booleanlabs.ecatalogue.userservice.external.repository.constant.QueryConstants;
import com.booleanlabs.ecatalogue.userservice.external.repository.mapper.internal.user.InternalUserLoadResultRowMapper;
import com.booleanlabs.ecatalogue.userservice.external.repository.util.RepositoryUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author dilanka
 * @created 20/01/2024 - 9:29 AM
 * @project ecat-user-service
 */
@Repository
@RequiredArgsConstructor
@Slf4j
public class InternalUserRepository {
    private final JdbcTemplate jdbcTemplate;

    /**
     * Create User in T_INTERNAL_USER table
     *
     * @param userId  user id
     * @param request request
     * @return internal user id
     */
    public Long createInternalUser(Long userId, InternalUserCreateDomainDto request) {

        final Long nextVal = jdbcTemplate.queryForObject(QueryConstants.InternalUser.SEQ_NEXT_VAL, Long.class);
        jdbcTemplate.update(QueryConstants.InternalUser.CREATE, nextVal, userId, request.getFirstName(), request.getLastName(),
                request.getPhoneNumber(), request.getDepartmentId(), request.getPlantId());

        log.info("Create internal user success|userId:{}", nextVal);
        return nextVal;
    }

    /**
     * Soft delete user from T_INTERNAL_USER
     *
     * @param internalUserId internal user id
     */
    public void softDeleteUser(Long internalUserId) {
        jdbcTemplate.update(QueryConstants.InternalUser.DELETE, internalUserId);

        log.info("delete internal user success|internalUserId:{}", internalUserId);
    }

    /**
     * Create User in T_INTERNAL_USER table
     *
     * @param userId user id
     * @return internal user id
     */
    public Long findIdByUserId(Long userId) {
        final Long internalUserId = jdbcTemplate.queryForObject(QueryConstants.InternalUser.FIND_ID_BY_USER_ID, Long.class, userId);
        log.info("Find internal user id success|{}|{}", userId, internalUserId);
        return internalUserId;
    }

    /**
     * Update User in T_INTERNAL_USER table
     *
     * @param request request
     */
    public void updateInternalUser(InternalUserUpdateDomainDto request) {
        jdbcTemplate.update(QueryConstants.InternalUser.UPDATE, request.getFirstName(), request.getLastName(), request.getPhoneNumber(),
                request.getDepartmentId(), request.getPlantId(), request.getUserId());

        log.info("Update internal user success|userId:{}", request.getUserId());
    }

    /**
     * Search internal user
     *
     * @param customerSearchDomainDto request
     * @return response
     */
    public BaseSearchResponseDomainDto<InternalUserSearchResultEntity> searchInternalUser(InternalUserSearchRequestDomainDto customerSearchDomainDto) {
        final String searchQuery = RepositoryUtils.addPagination(QueryConstants.InternalUser.SEARCH, customerSearchDomainDto.getItemPerPage(), customerSearchDomainDto.getPageIndex());

        //search
        final List<InternalUserSearchResultEntity> customerFetchDtos = jdbcTemplate.query(searchQuery, new InternalUserLoadResultRowMapper(),
                customerSearchDomainDto.getName(),
                customerSearchDomainDto.getEmailAddress(),
                customerSearchDomainDto.getPlantId(), customerSearchDomainDto.getPlantId(),
                customerSearchDomainDto.getDepartmentId(), customerSearchDomainDto.getDepartmentId());

        //total count
        final String countQuery = RepositoryUtils.convertToCount(QueryConstants.InternalUser.SEARCH);
        final Long size = jdbcTemplate.queryForObject(countQuery, Long.class,
                customerSearchDomainDto.getName(),
                customerSearchDomainDto.getEmailAddress(),
                customerSearchDomainDto.getPlantId(), customerSearchDomainDto.getPlantId(),
                customerSearchDomainDto.getDepartmentId(), customerSearchDomainDto.getDepartmentId());

        log.info("Search internal user success|{}", size);

        return BaseSearchResponseDomainDto.<InternalUserSearchResultEntity>builder()
                .items(customerFetchDtos)
                .build()
                .calculatePageable(size, customerSearchDomainDto.getPageIndex(), customerSearchDomainDto.getItemPerPage());
    }

    /**
     * Load internal user data by operation type
     *
     * @param loadRequestDomainDto load request
     * @return load response
     */
    public InternalUserSearchResultEntity loadInternalUser(BaseLoadRequestDomainDto loadRequestDomainDto) {
        final String query = OperationType.READ.equals(loadRequestDomainDto.getOperationType()) ? QueryConstants.InternalUser.LOAD_READ : QueryConstants.InternalUser.LOAD_UPDATE;

        return jdbcTemplate.queryForObject(query, new InternalUserLoadResultRowMapper(), loadRequestDomainDto.getId());
    }
}
