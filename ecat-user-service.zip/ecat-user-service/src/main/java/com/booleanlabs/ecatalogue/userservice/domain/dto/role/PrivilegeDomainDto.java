package com.booleanlabs.ecatalogue.userservice.domain.dto.role;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * @author dilanka
 * @created 24/01/2024 - 6:10 AM
 * @project ecat-user-service
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PrivilegeDomainDto {
    private Long roleId;
    private List<Long> privilegeIds;
}
