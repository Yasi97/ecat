package com.booleanlabs.ecatalogue.userservice.application.controller;

import com.booleanlabs.ecatalogue.userservice.application.request.dto.role.PrivilegeCreateRequestDto;
import com.booleanlabs.ecatalogue.userservice.application.response.dto.ErrorMessage;
import com.booleanlabs.ecatalogue.userservice.application.response.dto.SuccessMessage;
import com.booleanlabs.ecatalogue.userservice.application.util.ResponseUtils;
import com.booleanlabs.ecatalogue.userservice.application.validator.RequestEntityValidator;
import com.booleanlabs.ecatalogue.userservice.domain.dto.BaseResponseMessageDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.role.PrivilegeDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.role.RolePrivilegeSearchResponseDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.service.PrivilegeService;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Objects;

import static com.booleanlabs.ecatalogue.userservice.application.constant.AppConstants.APP_ROOT_V1_WEB;
import static com.booleanlabs.ecatalogue.userservice.application.constant.AppConstants.Actions.CREATE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.AppConstants.Actions.READ;

/**
 * @author dilanka
 * @created 24/01/2024 - 6:30 AM
 * @project ecat-user-service
 */
@RestController
@RequestMapping(APP_ROOT_V1_WEB + "/privilege")
@Validated
@RequiredArgsConstructor
@Slf4j
public class PrivilegeController {
    private final ResponseUtils responseUtils;
    private final RequestEntityValidator validator;
    private final ObjectMapper mapper;
    private final PrivilegeService privilegeService;

    @Operation(summary = "Create Role Privilege")
    @ApiResponses(value = {
            @ApiResponse(description = "Create Role Privilege Success", responseCode = "201"),
            @ApiResponse(description = "Bad Request in Create Role Privilege", responseCode = "400", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))}),
            @ApiResponse(description = "Exception occurred when processing Role Privilege", responseCode = "500", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))})})
    @PostMapping(value = CREATE, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessMessage<BaseResponseMessageDomainDto>> createRole(@RequestBody PrivilegeCreateRequestDto createRequest) {

        log.info("Create Role Privilege started");

        //validation
        validator.validate(createRequest);

        final PrivilegeDomainDto requestDro = mapper.convertValue(createRequest, PrivilegeDomainDto.class);

        final BaseResponseMessageDomainDto message = privilegeService.createRolePrivileges(requestDro);

        final ResponseEntity<SuccessMessage<BaseResponseMessageDomainDto>> response = responseUtils.wrapSuccess(message, HttpStatus.CREATED);

        log.info("Create Role Privilege completed|{}|{}", Objects.requireNonNull(response.getBody()).getCode(), Objects.requireNonNull(response.getBody()).getMessage());

        return response;
    }


    @Operation(summary = "Load Role Privileges")
    @ApiResponses(value = {
            @ApiResponse(description = "Load Role Privileges Success", responseCode = "200"),
            @ApiResponse(description = "User role privileges not found", responseCode = "404"),
            @ApiResponse(description = "Bad Request in Load Role Privileges Request", responseCode = "400", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))}),
            @ApiResponse(description = "Exception occurred when processing Load Role Privileges Request", responseCode = "500", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))})})
    @GetMapping(value = READ, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessMessage<RolePrivilegeSearchResponseDomainDto>> loadAll(@Validated @NotNull @PathVariable Long id) {
        log.info("Load Role Privileges started");

        final RolePrivilegeSearchResponseDomainDto privileges = privilegeService.loadUpdate(id);
        final ResponseEntity<SuccessMessage<RolePrivilegeSearchResponseDomainDto>> response = responseUtils.wrapSuccess(privileges, HttpStatus.OK);

        log.info("Load Role Privileges Request completed");
        return response;
    }
}
