package com.booleanlabs.ecatalogue.userservice.external.repository.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * @author dilanka
 * @created 20/01/2024 - 6:55 PM
 * @project ecat-user-service
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ColumnConstant {
    public static final String USER_ID = "USER_ID";
    public static final String FIRST_NAME = "FIRST_NAME";
    public static final String LAST_NAME = "LAST_NAME";
    public static final String ROLE_NAME = "ROLE_NAME";
    public static final String PLANT_NAME = "PLANT_NAME";
    public static final String DEPARTMENT_NAME = "DEPARTMENT_NAME";
    public static final String ID = "ID";
    public static final String EMAIL_ADDRESS = "EMAIL_ADDRESS";
    public static final String PHONE_NUMBER = "PHONE_NUMBER";
    public static final String ROLE_ID = "ROLE_ID";
    public static final String PLANT_ID = "PLANT_ID";
    public static final String DEPARTMENT_ID = "DEPARTMENT_ID";
    public static final String SYSTEM_ACTOR_ID = "SYSTEM_ACTOR_ID";
    public static final String IS_DEFAULT = "IS_DEFAULT";
    public static final String ROLE_VALUE = "ROLE_VALUE";

}
