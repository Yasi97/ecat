package com.booleanlabs.ecatalogue.userservice.external.repository;

import com.booleanlabs.ecatalogue.userservice.domain.dto.UserTypeEnum;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserCreateDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserUpdateDomainDto;
import com.booleanlabs.ecatalogue.userservice.external.repository.constant.QueryConstants;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
@RequiredArgsConstructor
@Slf4j
public class UserRepository {

    private final JdbcTemplate jdbcTemplate;

    /**
     * check if email exist in T_USER table
     *
     * @param emailAddress email
     * @return true if exist
     */
    public boolean isUserExist(String emailAddress) {

        final Integer count = jdbcTemplate.queryForObject(QueryConstants.User.COUNT_EMAIL, Integer.class, emailAddress);

        return ObjectUtils.isNotEmpty(count) && count != 0;
    }

    /**
     * Create User in T_USER table
     *
     * @param request request
     * @return user id
     */
    public Long createUser(InternalUserCreateDomainDto request) {

        final Long nextVal = jdbcTemplate.queryForObject(QueryConstants.User.SEQ_NEXT_VAL, Long.class);
        jdbcTemplate.update(QueryConstants.User.CREATE, nextVal, request.getRoleId(), UserTypeEnum.CUSTOMER.name(), request.getEmailAddress(), true);

        log.info("Create User success|userId:{}", nextVal);
        return nextVal;
    }

    /**
     * Update User in T_USER table
     * @param request request
     */
    public void updateUser(InternalUserUpdateDomainDto request) {

        jdbcTemplate.update(QueryConstants.User.UPDATE, request.getRoleId(), request.getUserId());

        log.info("Update User success|userId:{}", request.getUserId());
    }
}