package com.booleanlabs.ecatalogue.userservice.external.repository.mapper.internal.user;

import com.booleanlabs.ecatalogue.userservice.domain.entities.InternalUserSearchResultEntity;
import com.booleanlabs.ecatalogue.userservice.external.repository.util.RepositoryUtils;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;

import static com.booleanlabs.ecatalogue.userservice.external.repository.constant.ColumnConstant.DEPARTMENT_ID;
import static com.booleanlabs.ecatalogue.userservice.external.repository.constant.ColumnConstant.DEPARTMENT_NAME;
import static com.booleanlabs.ecatalogue.userservice.external.repository.constant.ColumnConstant.EMAIL_ADDRESS;
import static com.booleanlabs.ecatalogue.userservice.external.repository.constant.ColumnConstant.FIRST_NAME;
import static com.booleanlabs.ecatalogue.userservice.external.repository.constant.ColumnConstant.ID;
import static com.booleanlabs.ecatalogue.userservice.external.repository.constant.ColumnConstant.LAST_NAME;
import static com.booleanlabs.ecatalogue.userservice.external.repository.constant.ColumnConstant.PHONE_NUMBER;
import static com.booleanlabs.ecatalogue.userservice.external.repository.constant.ColumnConstant.PLANT_ID;
import static com.booleanlabs.ecatalogue.userservice.external.repository.constant.ColumnConstant.PLANT_NAME;
import static com.booleanlabs.ecatalogue.userservice.external.repository.constant.ColumnConstant.ROLE_ID;
import static com.booleanlabs.ecatalogue.userservice.external.repository.constant.ColumnConstant.ROLE_NAME;
import static com.booleanlabs.ecatalogue.userservice.external.repository.constant.ColumnConstant.USER_ID;

/**
 * @author dilanka
 * @created 20/01/2024 - 9:39 PM
 * @project ecat-user-service
 */
public class InternalUserLoadResultRowMapper implements RowMapper<InternalUserSearchResultEntity> {
    @Override
    public InternalUserSearchResultEntity mapRow(ResultSet rs, int rowNum) {
        final InternalUserSearchResultEntity entity = new InternalUserSearchResultEntity();

            entity.setId(RepositoryUtils.getLongOrDefault(rs, ID, null));
        entity.setUserId(RepositoryUtils.getLongOrDefault(rs, USER_ID, null));

        entity.setFirstName(RepositoryUtils.getStringOrDefault(rs, FIRST_NAME, null));
        entity.setLastName(RepositoryUtils.getStringOrDefault(rs, LAST_NAME, null));
        entity.setEmailAddress(RepositoryUtils.getStringOrDefault(rs, EMAIL_ADDRESS, null));
        entity.setPhoneNumber(RepositoryUtils.getStringOrDefault(rs, PHONE_NUMBER, null));

        entity.setRoleId(RepositoryUtils.getLongOrDefault(rs, ROLE_ID, null));
        entity.setRoleName(RepositoryUtils.getStringOrDefault(rs, ROLE_NAME, null));

        entity.setPlantId(RepositoryUtils.getLongOrDefault(rs, PLANT_ID, null));
        entity.setPlantName(RepositoryUtils.getStringOrDefault(rs, PLANT_NAME, null));

        entity.setDepartmentId(RepositoryUtils.getLongOrDefault(rs, DEPARTMENT_ID, null));
        entity.setDepartmentName(RepositoryUtils.getStringOrDefault(rs, DEPARTMENT_NAME, null));

        return entity;
    }
}
