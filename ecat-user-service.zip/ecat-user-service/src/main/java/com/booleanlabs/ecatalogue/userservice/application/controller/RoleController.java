package com.booleanlabs.ecatalogue.userservice.application.controller;

import com.booleanlabs.ecatalogue.userservice.application.request.dto.role.RoleCreateRequest;
import com.booleanlabs.ecatalogue.userservice.application.response.dto.ErrorMessage;
import com.booleanlabs.ecatalogue.userservice.application.response.dto.SuccessMessage;
import com.booleanlabs.ecatalogue.userservice.application.util.ResponseUtils;
import com.booleanlabs.ecatalogue.userservice.application.validator.RequestEntityValidator;
import com.booleanlabs.ecatalogue.userservice.domain.dto.BaseResponseMessageDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.role.RoleDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.service.RoleService;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Objects;

import static com.booleanlabs.ecatalogue.userservice.application.constant.AppConstants.APP_ROOT_V1_WEB;
import static com.booleanlabs.ecatalogue.userservice.application.constant.AppConstants.Actions.CREATE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.AppConstants.Actions.LOAD_ALL;

/**
 * @author dilanka
 * @created 23/01/2024 - 9:20 PM
 * @project ecat-user-service
 */

@RestController
@RequestMapping(APP_ROOT_V1_WEB + "/role")
@Validated
@RequiredArgsConstructor
@Slf4j
public class RoleController {

    private final ResponseUtils responseUtils;
    private final RequestEntityValidator validator;
    private final ObjectMapper mapper;
    private final RoleService roleService;

    @Operation(summary = "Create role")
    @ApiResponses(value = {
            @ApiResponse(description = "Create Role Success", responseCode = "201"),
            @ApiResponse(description = "Bad Request in Create Role", responseCode = "400", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))}),
            @ApiResponse(description = "Exception occurred when processing Role", responseCode = "500", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))})})
    @PostMapping(value = CREATE, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessMessage<BaseResponseMessageDomainDto>> createRole(@RequestBody RoleCreateRequest createRequest) {

        log.info("Create Role started");

        //validation
        validator.validate(createRequest);

        final RoleDomainDto requestDro = mapper.convertValue(createRequest, RoleDomainDto.class);

        final BaseResponseMessageDomainDto message = roleService.createRole(requestDro);

        final ResponseEntity<SuccessMessage<BaseResponseMessageDomainDto>> response = responseUtils.wrapSuccess(message, HttpStatus.CREATED);

        log.info("Create Role completed|{}|{}", Objects.requireNonNull(response.getBody()).getCode(), Objects.requireNonNull(response.getBody()).getMessage());

        return response;
    }


    @Operation(summary = "Load all roles")
    @ApiResponses(value = {
            @ApiResponse(description = "Load roles Success", responseCode = "200"),
            @ApiResponse(description = "Bad Request in Load role Request", responseCode = "400", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))}),
            @ApiResponse(description = "Exception occurred when processing Load role Request", responseCode = "500", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))})})
    @GetMapping(value = LOAD_ALL, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessMessage<List<RoleDomainDto>>> loadAll() {
        log.info("Load role started");

        final List<RoleDomainDto> loadAll = roleService.loadAll();
        final ResponseEntity<SuccessMessage<List<RoleDomainDto>>> response = responseUtils.wrapSuccess(loadAll, HttpStatus.OK);

        log.info("Load role Request completed");
        return response;
    }
}
