package com.booleanlabs.ecatalogue.userservice.domain.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.ENTITY_ERROR_NOT_NULL;

/**
 * @author dilanka
 * @created 20/01/2024 - 8:56 PM
 * @project ecat-user-service
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BaseLoadRequestDomainDto {
    @NotNull(message = ENTITY_ERROR_NOT_NULL)
    private Long id;

    @NotNull(message = ENTITY_ERROR_NOT_NULL)
    private OperationType operationType;
}
