package com.booleanlabs.ecatalogue.userservice.external.repository.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * @author dilanka
 * @created 20/01/2024 - 8:15 AM
 * @project ecat-user-service
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class QueryConstants {

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class User {
        public static final String COUNT_EMAIL = "select count(1) as count from ECAT.T_USER where EMAIL_ADDRESS=?";
        public static final String SEQ_NEXT_VAL = "select SEQ_USER.nextval from dual";
        public static final String CREATE = "INSERT INTO t_user (user_id, role_id, user_type, email_address, is_active,CREATED_USER) VALUES (?, ?, ?, ?, ?,'SYSTEM')";
        public static final String UPDATE = "UPDATE T_USER SET ROLE_ID=?, UPDATED_USER='SYSTEM',UPDATED_DATE=CURRENT_TIMESTAMP WHERE USER_ID=?";
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class InternalUser {

        public static final String SEQ_NEXT_VAL = "select SEQ_INTERNAL_USER.nextval from dual";
        public static final String CREATE = "INSERT INTO T_INTERNAL_USER(ID, USER_ID, FIRST_NAME, LAST_NAME, PHONE_NUMBER,DEPARTMENT_ID,PLANT_ID, CREATED_USER) VALUES (?,?,?,?,?,?,?,'SYSTEM')";
        public static final String DELETE = "UPDATE T_INTERNAL_USER SET IS_ACTIVE=1, UPDATED_USER='SYSTEM',UPDATED_DATE=CURRENT_TIMESTAMP WHERE ID=?";
        public static final String FIND_ID_BY_USER_ID = "SELECT ID FROM T_INTERNAL_USER WHERE USER_ID=?";
        public static final String SEARCH = """
                SELECT TIU.USER_ID,TIU.FIRST_NAME,TIU.LAST_NAME,TR.ROLE_NAME,TP.NAME AS PLANT_NAME,TD.NAME AS DEPARTMENT_NAME
                 FROM T_INTERNAL_USER TIU
                    INNER JOIN T_USER TU ON TIU.USER_ID = TU.USER_ID
                    INNER JOIN T_ROLE TR ON TU.ROLE_ID = TR.ROLE_ID
                    INNER JOIN T_PLANT TP on TIU.PLANT_ID = TP.ID
                    INNER JOIN T_DEPARTMENT TD on TIU.DEPARTMENT_ID = TD.ID
                WHERE ((UPPER(TIU.FIRST_NAME) || ' ' || UPPER(TIU.LAST_NAME)) LIKE '%' ||UPPER(?)||'%')
                AND ((UPPER(TU.EMAIL_ADDRESS)) LIKE '%' ||UPPER(?)||'%')
                AND (? IS NULL OR TIU.PLANT_ID = ?)
                AND (? IS NULL OR TIU.DEPARTMENT_ID = ?)""";

        public static final String LOAD_UPDATE = """
                SELECT TIU.ID,TIU.USER_ID,TIU.FIRST_NAME,TIU.LAST_NAME,TU.EMAIL_ADDRESS,TIU.PHONE_NUMBER, TU.ROLE_ID,TIU.PLANT_ID,TIU.DEPARTMENT_ID
                FROM T_INTERNAL_USER TIU
                         INNER JOIN T_USER TU ON TIU.USER_ID = TU.USER_ID
                         INNER JOIN T_ROLE TR ON TU.ROLE_ID = TR.ROLE_ID
                WHERE TIU.USER_ID=?
                """;

        public static final String LOAD_READ = """
                SELECT TIU.ID,TIU.FIRST_NAME,TIU.LAST_NAME,TU.EMAIL_ADDRESS,TIU.PHONE_NUMBER, TR.ROLE_NAME,TP.NAME AS PLANT_NAME,TD.NAME AS DEPARTMENT_NAME
                FROM T_INTERNAL_USER TIU
                         INNER JOIN T_USER TU ON TIU.USER_ID = TU.USER_ID
                         INNER JOIN T_ROLE TR ON TU.ROLE_ID = TR.ROLE_ID
                         INNER JOIN T_PLANT TP on TIU.PLANT_ID = TP.ID
                         INNER JOIN T_DEPARTMENT TD on TIU.DEPARTMENT_ID = TD.ID
                WHERE TIU.USER_ID=?
                """;
        public static final String UPDATE = "UPDATE T_INTERNAL_USER SET FIRST_NAME=?,LAST_NAME=?,PHONE_NUMBER=?,DEPARTMENT_ID=?,PLANT_ID=?, UPDATED_USER='SYSTEM',UPDATED_DATE=CURRENT_TIMESTAMP WHERE USER_ID=?";
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class InternalUserBrand {
        public static final String CREATE = "INSERT INTO AT_INTERNAL_USER_BRAND(INTERNAL_USER_ID, BRAND_ID, CREATED_USER) VALUES (?,?,'SYSTEM')";
        public static final String DELETE = "DELETE FROM AT_INTERNAL_USER_BRAND WHERE INTERNAL_USER_ID=?";
        public static final String LOAD_READ = "SELECT TB.BRAND_NAME FROM AT_INTERNAL_USER_BRAND IUB INNER JOIN T_BRAND TB ON IUB.BRAND_ID=TB.BRAND_ID WHERE INTERNAL_USER_ID=?";
        public static final String LOAD_UPDATE = "SELECT BRAND_ID FROM AT_INTERNAL_USER_BRAND WHERE INTERNAL_USER_ID=?";
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class ROLE {
        public static final String SEQ_NEXT_VAL = "select SEQ_ROLE.nextval from dual";
        public static final String CREATE = "INSERT INTO T_ROLE (ROLE_ID, ROLE_NAME, SYSTEM_ACTOR_ID, ROLE_VALUE) VALUES (?,?,?,?)";
        public static final String LOAD_ALL = "SELECT * FROM T_ROLE";
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class PRIVILEGE {
        public static final String CREATE = "INSERT INTO AT_ROLE_PRIVILEGE(ROLE_ID, PRIVILEGE_ID, CREATED_USER) VALUES (?,?,'SYSTEM')";
        public static final String DELETE = "DELETE FROM AT_ROLE_PRIVILEGE WHERE ROLE_ID=?";
        public static final String LOAD = "SELECT PRIVILEGE_ID FROM AT_ROLE_PRIVILEGE WHERE ROLE_ID=?";
    }
}

