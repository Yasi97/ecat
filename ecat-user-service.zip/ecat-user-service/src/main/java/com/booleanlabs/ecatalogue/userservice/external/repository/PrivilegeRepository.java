package com.booleanlabs.ecatalogue.userservice.external.repository;

import com.booleanlabs.ecatalogue.userservice.domain.dto.role.PrivilegeDomainDto;
import com.booleanlabs.ecatalogue.userservice.external.repository.constant.QueryConstants;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author dilanka
 * @created 24/01/2024 - 6:20 AM
 * @project ecat-user-service
 */
@Repository
@RequiredArgsConstructor
@Slf4j
public class PrivilegeRepository {
    private final JdbcTemplate jdbcTemplate;

    /**
     * Create User in AT_ROLE_PRIVILEGE table
     *
     * @param request request
     */
    public void createRolePrivilege(PrivilegeDomainDto request) {
        int batchSize = 100;
        int[][] batchUpdate = jdbcTemplate.batchUpdate(QueryConstants.PRIVILEGE.CREATE, request.getPrivilegeIds(), batchSize, (ps, privilegeId) -> {

            ps.setLong(1, request.getRoleId());
            ps.setLong(2, privilegeId);
        });

        log.info("batchUpdate role privilege:{}", (Object) batchUpdate);
    }

    /**
     * Soft delete user from AT_ROLE_PRIVILEGE
     *
     * @param roleId role id
     */
    public void clearRolePrivilegesByRoleId(Long roleId) {
        jdbcTemplate.update(QueryConstants.PRIVILEGE.DELETE, roleId);

        log.info("delete role privilege success|roleId:{}", roleId);
    }

    /**
     *  Load all privilege ids by role id
     * @param roleId role od
     * @return privilege ids
     */
    public List<Long> loadUpdate(Long roleId) {
        return jdbcTemplate.queryForList(QueryConstants.PRIVILEGE.LOAD, Long.class, roleId);
    }
}
