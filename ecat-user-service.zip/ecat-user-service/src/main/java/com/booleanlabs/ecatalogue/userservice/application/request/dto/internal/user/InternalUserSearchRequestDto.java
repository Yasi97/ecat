package com.booleanlabs.ecatalogue.userservice.application.request.dto.internal.user;

import com.booleanlabs.ecatalogue.userservice.application.request.dto.BaseSearchRequest;
import lombok.Getter;
import lombok.Setter;

/**
 * @author dilanka
 * @created 20/01/2024 - 5:42 PM
 * @project ecat-user-service
 */
@Getter
@Setter
public class InternalUserSearchRequestDto extends BaseSearchRequest {
    private String emailAddress;
    private String name;
    private Long plantId;
    private Long departmentId;
}
