package com.booleanlabs.ecatalogue.userservice.domain.dto.role;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * @author dilanka
 * @created 24/01/2024 - 6:25 AM
 * @project ecat-user-service
 */
@Getter
@Setter
@AllArgsConstructor
public class RolePrivilegeSearchResponseDomainDto {
    private List<Long> privilegeIds;
}
