package com.booleanlabs.ecatalogue.userservice.application.util;

import com.booleanlabs.ecatalogue.userservice.application.exception.vm.ErrorField;
import com.booleanlabs.ecatalogue.userservice.application.response.dto.ErrorMessage;
import com.booleanlabs.ecatalogue.userservice.application.response.dto.ErrorResponse;
import com.booleanlabs.ecatalogue.userservice.application.response.dto.SuccessMessage;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

import static com.booleanlabs.ecatalogue.userservice.application.constant.SuccessConstants.ACTION_SUCCESS_MESSAGE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.SuccessConstants.SUCCESS_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.SuccessConstants.SUCCESS_MESSAGE;

@Component
@RequiredArgsConstructor
public class ResponseUtils {

    private final HttpServletRequest servletRequest;
    private final MessageUtils messageUtils;

    /**
     * Success Message response entity message
     *
     * @param value      Any Object value
     * @param httpStatus Http Status Code
     * @param <T>        Generic type value
     * @return @{@link SuccessMessage}
     */
    public <T> ResponseEntity<SuccessMessage<T>> wrapSuccess(T value, HttpStatus httpStatus) {
        SuccessMessage.SuccessMessageBuilder<T> builder = SuccessMessage.builder();
        SuccessMessage<T> successMessage = builder
                .code(SUCCESS_CODE)
                .data(value)
                .message(SUCCESS_MESSAGE)
                .timestamp(DateTimeUtils.format(new Date()))
                .build();
        return ResponseEntity.status(httpStatus).body(successMessage);
    }

    /**
     * Success Message response entity message
     *
     * @param value      Any Object value
     * @param message success message
     * @param httpStatus Http Status Code
     * @param <T>        Generic type value
     * @return @{@link SuccessMessage}
     */
    public <T> ResponseEntity<SuccessMessage<T>> wrapSuccess(T value, String message, HttpStatus httpStatus) {
        SuccessMessage.SuccessMessageBuilder<T> builder = SuccessMessage.builder();
        final String actionSuccess = messageUtils.getPropertyValue(ACTION_SUCCESS_MESSAGE);

        SuccessMessage<T> successMessage = builder
                .code(SUCCESS_CODE)
                .data(value)
                .message(String.format(actionSuccess, message))
                .timestamp(DateTimeUtils.format(new Date()))
                .build();
        return ResponseEntity.status(httpStatus).body(successMessage);
    }

    /**
     * @param errorFieldList Object value
     * @param errorCode      Error Code
     * @param type           Error Type
     * @param globalMessage  Global Message
     * @param httpStatus     Http Status
     * @return Return Error Message Response Entity
     */
    public ResponseEntity<ErrorMessage> wrapErrors(List<ErrorField> errorFieldList, String errorCode, String type, String globalMessage, HttpStatus httpStatus) {
        ErrorMessage errorMessage = ErrorMessage.builder()
                .code(errorCode)
                .type(type)
                .origin(servletRequest.getRequestURI())
                .message(globalMessage)
                .data(new ErrorResponse(errorFieldList))
                .timestamp(DateTimeUtils.format(new Date()))
                .build();
        return ResponseEntity.status(httpStatus).body(errorMessage);
    }

}
