package com.booleanlabs.ecatalogue.userservice.external.repository;

import com.booleanlabs.ecatalogue.userservice.external.repository.constant.QueryConstants;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author dilanka
 * @created 20/01/2024 - 9:58 AM
 * @project ecat-user-service
 */
@Repository
@RequiredArgsConstructor
@Slf4j
public class InternalUserBrandRepository {
    private final JdbcTemplate jdbcTemplate;

    /**
     * Create User in T_INTERNAL_USER_BRAND table
     *
     * @param internalUserId internal user id
     * @param brandIds       brand ids
     */
    public void createInternalUserBrand(Long internalUserId, List<Long> brandIds) {
        int batchSize = 100;
        int[][] batchUpdate = jdbcTemplate.batchUpdate(QueryConstants.InternalUserBrand.CREATE, brandIds, batchSize, (ps, brandId) -> {

            ps.setLong(1, internalUserId);
            ps.setLong(2, brandId);
        });
        log.info("batchUpdate:{}", (Object) batchUpdate);
    }

    /**
     * Delete all internal user brand by internal user id
     *
     * @param internalUserId internal user id
     */
    public void deleteInternalUserBrand(Long internalUserId) {

        jdbcTemplate.update(QueryConstants.InternalUserBrand.DELETE, internalUserId);
    }

    /**
     * Load all brand names by internal user id
     * @param internalUserId internal user id
     * @return brand names
     */
    public List<String> loadRead(Long internalUserId) {
        return jdbcTemplate.queryForList(QueryConstants.InternalUserBrand.LOAD_READ, String.class, internalUserId);
    }

    /**
     *  Load all brand ids by internal user id
     * @param internalUserId internal user id
     * @return brand ids
     */
    public List<Long> loadUpdate(Long internalUserId) {
        return jdbcTemplate.queryForList(QueryConstants.InternalUserBrand.LOAD_UPDATE, Long.class, internalUserId);
    }
}
