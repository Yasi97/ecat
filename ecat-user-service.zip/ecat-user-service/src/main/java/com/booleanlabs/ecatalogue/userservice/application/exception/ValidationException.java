package com.booleanlabs.ecatalogue.userservice.application.exception;

import com.booleanlabs.ecatalogue.userservice.application.exception.vm.ErrorField;
import lombok.Getter;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.util.List;

@Getter
@ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
public class ValidationException extends RuntimeException {

    private final transient List<ErrorField> errors;

    /**
     * Validation Exception
     *
     * @param errors Error Field Wrapper
     * @param <T>    Target Type
     */
    public <T> ValidationException(List<ErrorField> errors) {
        this.errors = errors;
    }

}
