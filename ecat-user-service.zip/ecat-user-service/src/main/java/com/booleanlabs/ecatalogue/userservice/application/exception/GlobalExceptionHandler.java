package com.booleanlabs.ecatalogue.userservice.application.exception;

import com.booleanlabs.ecatalogue.userservice.application.exception.vm.ErrorField;
import com.booleanlabs.ecatalogue.userservice.application.response.dto.ErrorMessage;
import com.booleanlabs.ecatalogue.userservice.application.util.MessageUtils;
import com.booleanlabs.ecatalogue.userservice.application.util.ResponseUtils;
import com.fasterxml.jackson.core.exc.InputCoercionException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.fasterxml.jackson.databind.exc.MismatchedInputException;
import jakarta.servlet.ServletException;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.lang.NonNull;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingPathVariableException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;

import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.StringJoiner;
import java.util.concurrent.CancellationException;
import java.util.concurrent.TimeoutException;

import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.ARRAY_INDEX_OUT_OF_BOUND_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.ARRAY_INDEX_OUT_OF_BOUND_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.BUSINESS_ERROR_TYPE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.CANCELLATION_EXCEPTION_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.CANCELLATION_EXCEPTION_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.CONSTRAINT_VIOLATION_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.DATABASE_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.DATABASE_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.DATA_ACCESS_EXCEPTION_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.DATA_ACCESS_EXCEPTION_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.DATA_INTEGRITY_VIOLATION_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.DATA_INTEGRITY_VIOLATION_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.DATA_TYPE_MISMATCH_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.DB_ERROR_TYPE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.EXECUTION_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.EXECUTION_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.EXECUTION_ERROR_TYPE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.GLOBAL_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.GLOBAL_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.GLOBAL_ERROR_TYPE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.HTTP_MESSAGE_NOT_READABLE_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.HTTP_MESSAGE_NOT_READABLE_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.INVALID_DATA_FORMAT_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.INVALID_DATA_FORMAT_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.INVALID_RANGE_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.INVALID_RANGE_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.INVALID_URL_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.INVALID_URL_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.JSON_PARSE_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.JSON_PARSE_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.MEDIA_TYPE_NOT_SUPPORTED_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.MEDIA_TYPE_NOT_SUPPORTED_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.METHOD_ARGUMENT_TYPE_MISMATCH_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.METHOD_ARGUMENT_TYPE_MIS_MATCH_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.METHOD_NOT_ALLOWED_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.METHOD_NOT_ALLOWED_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.METHOD_NOT_ALLOWED_ERROR_TYPE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.MISSING_PATH_VARIABLE_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.MISSING_PATH_VARIABLE_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.MISSING_REQUEST_PARAMETER_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.MISSING_REQUEST_PARAMETER_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.NESTED_SERVLET_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.NULL_POINTER_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.NULL_POINTER_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.REQUEST_BODY_MISSING_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.REQUEST_BODY_MISSING_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.RESOURCE_NOT_FOUND_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.RESOURCE_NOT_FOUND_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.SQL_EXCEPTION_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.SQL_EXCEPTION_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.SQL_INTEGRITY_VIOLATION_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.SQL_INTEGRITY_VIOLATION_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.SYSTEM_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.SYSTEM_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.TIMEOUT_EXCEPTION_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.TIMEOUT_EXCEPTION_ERROR_MESSAGE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.VALIDATION_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.VALIDATION_ERROR_TYPE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.VALIDATION_FAILURE_ERROR_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.VALIDATION_FAILURE_ERROR_MESSAGE;

/**
 * @author dilanka
 * @created 07/01/2024 - 9:50 AM
 * @project user-service
 */
@Slf4j
@ControllerAdvice
@RequiredArgsConstructor
public class GlobalExceptionHandler {
    private final ResponseUtils responseUtils;
    private final MessageUtils messageUtils;

    /**
     * Catch HttpRequestMethodNotSupportedException
     *
     * @param ex @{@link HttpRequestMethodNotSupportedException}
     * @return @{@link ErrorMessage}
     */
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<ErrorMessage> methodNotAllowedExceptionHandler(HttpRequestMethodNotSupportedException ex) {
        log.error("HttpRequestMethodNotSupportedException", ex);

        return responseUtils.wrapErrors(
                Collections.singletonList(ErrorField.of(messageUtils.getPropertyValue(METHOD_NOT_ALLOWED_ERROR_CODE), null,
                        messageUtils.getPropertyValue(METHOD_NOT_ALLOWED_ERROR_MESSAGE))),
                messageUtils.getPropertyValue(METHOD_NOT_ALLOWED_ERROR_CODE),
                messageUtils.getPropertyValue(METHOD_NOT_ALLOWED_ERROR_TYPE),
                messageUtils.getPropertyValue(METHOD_NOT_ALLOWED_ERROR_MESSAGE),
                HttpStatus.METHOD_NOT_ALLOWED);
    }

    /**
     * Catch NoHandlerFoundException
     *
     * @param ex @{@link NoHandlerFoundException}
     * @return @{@link ErrorMessage}
     */
    @ExceptionHandler(NoHandlerFoundException.class)
    public ResponseEntity<ErrorMessage> noHandlerFoundExceptionHandler(NoHandlerFoundException ex) {
        log.error("NoHandlerFoundException", ex);

        return responseUtils.wrapErrors(
                Collections.singletonList(ErrorField.of(messageUtils.getPropertyValue(INVALID_URL_ERROR_CODE), null,
                        messageUtils.getPropertyValue(INVALID_URL_ERROR_MESSAGE))),
                messageUtils.getPropertyValue(INVALID_URL_ERROR_CODE),
                messageUtils.getPropertyValue(VALIDATION_ERROR_TYPE),
                messageUtils.getPropertyValue(INVALID_URL_ERROR_MESSAGE),
                HttpStatus.NOT_FOUND);
    }

    /**
     * Catch HttpMediaTypeNotSupportedException
     *
     * @param ex @{@link HttpMediaTypeNotSupportedException}
     * @return @{@link ErrorMessage}
     */
    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public ResponseEntity<ErrorMessage> httpMediaTypeNotSupportedExceptionHandler(HttpMediaTypeNotSupportedException ex) {
        log.error("HttpMediaTypeNotSupportedException", ex);

        return responseUtils.wrapErrors(
                Collections.singletonList(ErrorField.of(messageUtils.getPropertyValue(MEDIA_TYPE_NOT_SUPPORTED_ERROR_CODE), null,
                        messageUtils.getPropertyValue(MEDIA_TYPE_NOT_SUPPORTED_ERROR_MESSAGE))),
                messageUtils.getPropertyValue(MEDIA_TYPE_NOT_SUPPORTED_ERROR_CODE),
                messageUtils.getPropertyValue(VALIDATION_ERROR_TYPE),
                messageUtils.getPropertyValue(MEDIA_TYPE_NOT_SUPPORTED_ERROR_MESSAGE),
                HttpStatus.BAD_REQUEST);
    }

    /**
     * Catch MissingPathVariableException
     *
     * @param ex @{@link MissingPathVariableException}
     * @return @{@link ErrorMessage}
     */
    @ExceptionHandler(MissingPathVariableException.class)
    public ResponseEntity<ErrorMessage> missingPathVariableExceptionHandler(MissingPathVariableException ex) {
        log.error("MissingServletRequestParameterException", ex);

        return responseUtils.wrapErrors(
                Collections.singletonList(ErrorField.of(messageUtils.getPropertyValue(MISSING_PATH_VARIABLE_ERROR_CODE), null,
                        String.format(messageUtils.getPropertyValue(MISSING_PATH_VARIABLE_ERROR_MESSAGE), ex.getVariableName(), ex.getParameter().getNestedParameterType().getSimpleName()))),
                messageUtils.getPropertyValue(VALIDATION_FAILURE_ERROR_CODE),
                messageUtils.getPropertyValue(VALIDATION_ERROR_TYPE),
                messageUtils.getPropertyValue(VALIDATION_FAILURE_ERROR_MESSAGE),
                HttpStatus.BAD_REQUEST);
    }

    /**
     * Catch MissingServletRequestParameterException
     *
     * @param ex @{@link MissingServletRequestParameterException}
     * @return @{@link ErrorMessage}
     */
    @ExceptionHandler(MissingServletRequestParameterException.class)
    public ResponseEntity<ErrorMessage> missingServletRequestParameterExceptionHandler(MissingServletRequestParameterException ex) {
        log.error("MissingServletRequestParameterException", ex);

        return responseUtils.wrapErrors(
                Collections.singletonList(ErrorField.of(messageUtils.getPropertyValue(MISSING_REQUEST_PARAMETER_ERROR_CODE), null,
                        String.format(messageUtils.getPropertyValue(MISSING_REQUEST_PARAMETER_ERROR_MESSAGE), ex.getParameterName(), ex.getParameterType()))),
                messageUtils.getPropertyValue(VALIDATION_FAILURE_ERROR_CODE),
                messageUtils.getPropertyValue(VALIDATION_ERROR_TYPE),
                messageUtils.getPropertyValue(VALIDATION_FAILURE_ERROR_MESSAGE),
                HttpStatus.BAD_REQUEST);
    }

    /**
     * Catch NestedServletException
     *
     * @param ex @{@link ServletException}
     * @return @{@link ErrorMessage}
     */
    @ExceptionHandler(ServletException.class)
    public ResponseEntity<ErrorMessage> nestedServletExceptionHandler(ServletException ex) {
        log.error("ServletException", ex);
        return responseUtils.wrapErrors(
                Collections.singletonList(ErrorField.of(messageUtils.getPropertyValue(NESTED_SERVLET_ERROR_CODE), null,
                        messageUtils.getPropertyValue(DATA_TYPE_MISMATCH_ERROR_MESSAGE))),
                messageUtils.getPropertyValue(NESTED_SERVLET_ERROR_CODE),
                messageUtils.getPropertyValue(VALIDATION_ERROR_TYPE),
                messageUtils.getPropertyValue(DATA_TYPE_MISMATCH_ERROR_MESSAGE),
                HttpStatus.BAD_REQUEST);
    }

    /**
     * Catch HttpMessageNotReadableException
     *
     * @param ex @{@link HttpMessageNotReadableException}
     * @return @{@link ErrorMessage}
     */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ErrorMessage> httpMessageNotReadableExceptionHandler(@NonNull HttpMessageNotReadableException ex) {
        log.error("HttpMessageNotReadableException", ex);

        String[] errors = ex.getLocalizedMessage().split(":");
        String msg = errors.length > 1 ? errors[0] : messageUtils.getPropertyValue(HTTP_MESSAGE_NOT_READABLE_ERROR_MESSAGE);
        String field = null;
        String code = messageUtils.getPropertyValue(HTTP_MESSAGE_NOT_READABLE_ERROR_CODE);

        if (msg.equals("Required request body is missing")) {
            msg = messageUtils.getPropertyValue(REQUEST_BODY_MISSING_ERROR_MESSAGE);
            code = messageUtils.getPropertyValue(REQUEST_BODY_MISSING_ERROR_CODE);
        }

        Throwable cause = ex.getCause();
        if (cause instanceof InvalidFormatException mie) {
            if (CollectionUtils.isNotEmpty(mie.getPath())) {
                code = messageUtils.getPropertyValue(JSON_PARSE_ERROR_CODE);
                field = mie.getPath().get(mie.getPath().size() - 1).getFieldName();
                msg = String.format(messageUtils.getPropertyValue(JSON_PARSE_ERROR_MESSAGE), field, mie.getTargetType().getSimpleName());

            }
        } else if (cause instanceof MismatchedInputException mie) {
            if (CollectionUtils.isNotEmpty(mie.getPath())) {
                code = messageUtils.getPropertyValue(JSON_PARSE_ERROR_CODE);
                field = mie.getPath().get(mie.getPath().size() - 1).getFieldName();
                msg = String.format(messageUtils.getPropertyValue(JSON_PARSE_ERROR_MESSAGE), field, mie.getTargetType().getSimpleName());
            }
        } else if (Objects.nonNull(ex.getCause()) && ex.getCause().getCause() instanceof InputCoercionException mie) {
            final JsonMappingException exception = (JsonMappingException) cause;
            code = messageUtils.getPropertyValue(INVALID_RANGE_ERROR_CODE);
            field = exception.getPath().get(exception.getPath().size() - 1).getFieldName();
            msg = String.format(messageUtils.getPropertyValue(INVALID_RANGE_ERROR_MESSAGE), mie.getTargetType().getSimpleName());

        }

        return responseUtils.wrapErrors(
                Collections.singletonList(
                        ErrorField.of(code, field, msg)),
                messageUtils.getPropertyValue(VALIDATION_FAILURE_ERROR_CODE),
                messageUtils.getPropertyValue(VALIDATION_ERROR_TYPE),
                messageUtils.getPropertyValue(VALIDATION_FAILURE_ERROR_MESSAGE),
                HttpStatus.BAD_REQUEST);
    }

    /**
     * Catch MismatchedInputException
     *
     * @param ex @{@link MismatchedInputException}
     * @return @{@link ErrorMessage}
     */
    @ExceptionHandler(MismatchedInputException.class)
    public ResponseEntity<ErrorMessage> mismatchedInputExceptionHandler(MismatchedInputException ex) {
        log.error("MismatchedInputException", ex);

        final String msg = ex.getOriginalMessage().split(": Failed to deserialize java.time.LocalDateTime:")[0];
        return responseUtils.wrapErrors(
                Collections.singletonList(ErrorField.of(messageUtils.getPropertyValue(INVALID_DATA_FORMAT_ERROR_CODE), null, msg)),
                messageUtils.getPropertyValue(VALIDATION_FAILURE_ERROR_CODE),
                messageUtils.getPropertyValue(VALIDATION_ERROR_TYPE),
                messageUtils.getPropertyValue(VALIDATION_FAILURE_ERROR_MESSAGE),
                HttpStatus.BAD_REQUEST);
    }

    /**
     * catch MethodArgumentTypeMismatchException
     *
     * @param ex @{@link Exception}
     * @return @{@link ErrorMessage}
     */
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<ErrorMessage> methodArgumentTypeMismatchExceptionHandler(MethodArgumentTypeMismatchException ex) {
        log.error("MethodArgumentTypeMismatchException", ex);

        return responseUtils.wrapErrors(
                Collections.singletonList(ErrorField.of(messageUtils.getPropertyValue(METHOD_ARGUMENT_TYPE_MIS_MATCH_ERROR_CODE), ex.getName(),
                        messageUtils.getPropertyValue(METHOD_ARGUMENT_TYPE_MISMATCH_ERROR_MESSAGE) + " " + ex.getRequiredType())),
                messageUtils.getPropertyValue(VALIDATION_FAILURE_ERROR_CODE),
                messageUtils.getPropertyValue(VALIDATION_ERROR_TYPE),
                messageUtils.getPropertyValue(VALIDATION_FAILURE_ERROR_MESSAGE),
                HttpStatus.BAD_REQUEST);

    }

    /**
     * Catch MethodArgumentNotValidException
     *
     * @param ex @{@link MethodArgumentNotValidException}
     * @return @{@link ErrorMessage}
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorMessage> methodArgumentNotValidExceptionHandler(MethodArgumentNotValidException ex) {
        log.error("MethodArgumentNotValidException", ex.getCause());

        List<ErrorField> errorFieldList = new ArrayList<>();
        for (FieldError error : ex.getBindingResult().getFieldErrors()) {
            String defaultMessage = error.getDefaultMessage();
            if (Objects.isNull(defaultMessage)) {
                break;
            }
            final String[] mValues = defaultMessage.split(":");
            ErrorField errorField = new ErrorField();
            errorField.setCode(mValues.length > 0 ? mValues[0] : messageUtils.getPropertyValue(VALIDATION_ERROR_CODE));
            errorField.setField(error.getField());
            errorField.setMessage(mValues.length > 1 ? mValues[1] : defaultMessage);
            errorFieldList.add(errorField);
        }

        return responseUtils.wrapErrors(
                errorFieldList,
                messageUtils.getPropertyValue(VALIDATION_FAILURE_ERROR_CODE),
                messageUtils.getPropertyValue(VALIDATION_ERROR_TYPE),
                messageUtils.getPropertyValue(VALIDATION_FAILURE_ERROR_MESSAGE),
                HttpStatus.BAD_REQUEST);
    }

    /**
     * Catch SQLIntegrityConstraintViolationException
     *
     * @param ex @{@link SQLIntegrityConstraintViolationException}
     * @return @{@link ErrorMessage}
     */
    @ExceptionHandler(SQLIntegrityConstraintViolationException.class)
    public ResponseEntity<ErrorMessage> sqlIntegrityConstraintViolationExceptionHandler(SQLIntegrityConstraintViolationException ex) {
        log.error("SQLIntegrityConstraintViolationException", ex);

        return responseUtils.wrapErrors(
                Collections.singletonList(ErrorField.of(messageUtils.getPropertyValue(SQL_INTEGRITY_VIOLATION_ERROR_CODE), null,
                        messageUtils.getPropertyValue(SQL_INTEGRITY_VIOLATION_ERROR_MESSAGE))),
                messageUtils.getPropertyValue(DATABASE_ERROR_CODE),
                messageUtils.getPropertyValue(DB_ERROR_TYPE),
                messageUtils.getPropertyValue(DATABASE_ERROR_MESSAGE),
                HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Catch SQLException
     *
     * @param ex @{@link SQLException}
     * @return @{@link ErrorMessage}
     */
    @ExceptionHandler(SQLException.class)
    public ResponseEntity<ErrorMessage> sqlExceptionHandler(SQLException ex) {
        log.error("SQLException", ex);

        return responseUtils.wrapErrors(
                Collections.singletonList(ErrorField.of(messageUtils.getPropertyValue(SQL_EXCEPTION_ERROR_CODE), null,
                        messageUtils.getPropertyValue(SQL_EXCEPTION_ERROR_MESSAGE))),
                messageUtils.getPropertyValue(DATABASE_ERROR_CODE),
                messageUtils.getPropertyValue(DB_ERROR_TYPE),
                messageUtils.getPropertyValue(DATABASE_ERROR_MESSAGE),
                HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Catch DataIntegrityViolationException
     *
     * @param ex @{@link DataIntegrityViolationException}
     * @return @{@link ErrorMessage}
     */
    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<ErrorMessage> dataIntegrityViolationExceptionHandler(DataIntegrityViolationException ex) {
        log.error("DataIntegrityViolationException", ex);

        return responseUtils.wrapErrors(
                Collections.singletonList(ErrorField.of(messageUtils.getPropertyValue(DATA_INTEGRITY_VIOLATION_ERROR_CODE), null,
                        messageUtils.getPropertyValue(DATA_INTEGRITY_VIOLATION_ERROR_MESSAGE))),
                messageUtils.getPropertyValue(DATABASE_ERROR_CODE),
                messageUtils.getPropertyValue(DB_ERROR_TYPE),
                messageUtils.getPropertyValue(DATABASE_ERROR_MESSAGE),
                HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Catch DataAccessException
     *
     * @param ex @{@link DataAccessException}
     * @return @{@link ErrorMessage}
     */
    @ExceptionHandler(DataAccessException.class)
    public ResponseEntity<ErrorMessage> dataAccessExceptionHandler(DataAccessException ex) {
        log.error("DataAccessException", ex);

        return responseUtils.wrapErrors(
                Collections.singletonList(ErrorField.of(messageUtils.getPropertyValue(DATA_ACCESS_EXCEPTION_ERROR_CODE), null,
                        messageUtils.getPropertyValue(DATA_ACCESS_EXCEPTION_ERROR_MESSAGE))),
                messageUtils.getPropertyValue(DATABASE_ERROR_CODE),
                messageUtils.getPropertyValue(DB_ERROR_TYPE),
                messageUtils.getPropertyValue(DATABASE_ERROR_MESSAGE),
                HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Catch ValidationException
     *
     * @param ex @{@link ValidationException}
     * @return @{@link ErrorMessage}
     */
    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<ErrorMessage> validationExceptionHandler(ValidationException ex) {
        log.error("ConstraintViolationException", ex);

        return responseUtils.wrapErrors(
                ex.getErrors(),
                messageUtils.getPropertyValue(VALIDATION_FAILURE_ERROR_CODE),
                messageUtils.getPropertyValue(VALIDATION_ERROR_TYPE),
                messageUtils.getPropertyValue(VALIDATION_FAILURE_ERROR_MESSAGE),
                HttpStatus.BAD_REQUEST);
    }

    /**
     * Catch NotFoundException
     *
     * @param ex @{@link NotFoundException}
     * @return @{@link ErrorMessage}
     */
    @ExceptionHandler(NotFoundException.class)
    public ResponseEntity<ErrorMessage> notFoundExceptionHandler(NotFoundException ex) {
        log.error("NotFoundException", ex);

        return responseUtils.wrapErrors(
                Collections.singletonList(ErrorField.of(ex.getCode(), null, ex.getMessage())),
                messageUtils.getPropertyValue(RESOURCE_NOT_FOUND_ERROR_CODE),
                messageUtils.getPropertyValue(BUSINESS_ERROR_TYPE),
                messageUtils.getPropertyValue(RESOURCE_NOT_FOUND_ERROR_MESSAGE),
                HttpStatus.NOT_FOUND);
    }

    /**
     * Catch NullPointerException
     *
     * @param ex @{@link NullPointerException}
     * @return @{@link ErrorMessage}
     */
    @ExceptionHandler(NullPointerException.class)
    public ResponseEntity<ErrorMessage> nullPointerExceptionHandler(NullPointerException ex) {
        log.error("NullPointerException", ex);

        return responseUtils.wrapErrors(
                Collections.singletonList(ErrorField.of(messageUtils.getPropertyValue(NULL_POINTER_ERROR_CODE), null,
                        messageUtils.getPropertyValue(NULL_POINTER_ERROR_MESSAGE))),
                messageUtils.getPropertyValue(SYSTEM_ERROR_CODE),
                messageUtils.getPropertyValue(BUSINESS_ERROR_TYPE),
                messageUtils.getPropertyValue(SYSTEM_ERROR_MESSAGE),
                HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Catch ArrayIndexOutOfBoundsException
     *
     * @param ex @{@link ArrayIndexOutOfBoundsException}
     * @return @{@link ErrorMessage}
     */
    @ExceptionHandler(ArrayIndexOutOfBoundsException.class)
    public ResponseEntity<ErrorMessage> arrayIndexOutOfBoundExceptionHandler(ArrayIndexOutOfBoundsException ex) {
        log.error("ArrayIndexOutOfBoundsException", ex);

        return responseUtils.wrapErrors(
                Collections.singletonList(ErrorField.of(messageUtils.getPropertyValue(ARRAY_INDEX_OUT_OF_BOUND_ERROR_CODE), null,
                        messageUtils.getPropertyValue(ARRAY_INDEX_OUT_OF_BOUND_ERROR_MESSAGE))),
                messageUtils.getPropertyValue(SYSTEM_ERROR_CODE),
                messageUtils.getPropertyValue(BUSINESS_ERROR_TYPE),
                messageUtils.getPropertyValue(SYSTEM_ERROR_MESSAGE),
                HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Catch ConstraintViolationException
     *
     * @param ex @{@link ConstraintViolationException}
     * @return @{@link ErrorMessage}
     */
    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ErrorMessage> constraintViolationHandler(ConstraintViolationException ex) {
        log.error("ConstraintViolationException", ex);

        Set<ConstraintViolation<?>> constraintViolations = ex.getConstraintViolations();
        List<ErrorField> errorFields = new ArrayList<>();
        constraintViolations.forEach(error -> {
            final String[] mValues;
            if (error.getMessage().contains(":")) {
                mValues = error.getMessage().split(":");
            } else {
                mValues = new String[]{messageUtils.getPropertyValue(CONSTRAINT_VIOLATION_ERROR_CODE), error.getMessage()};
            }
            ErrorField errorField = new ErrorField();
            errorField.setCode(mValues[0]);
            String path = error.getPropertyPath().toString();
            errorField.setField(path.substring(path.indexOf('.') + 1));
            errorField.setMessage(mValues[1]);
            errorFields.add(errorField);
        });

        return responseUtils.wrapErrors(
                errorFields,
                messageUtils.getPropertyValue(VALIDATION_FAILURE_ERROR_CODE),
                messageUtils.getPropertyValue(VALIDATION_ERROR_TYPE),
                messageUtils.getPropertyValue(VALIDATION_FAILURE_ERROR_MESSAGE),
                HttpStatus.BAD_REQUEST);
    }

    /**
     * Catch CommonException
     *
     * @param ex @{@link CommonException}
     * @return @{@link ErrorMessage}
     */
    @ExceptionHandler(CommonException.class)
    public ResponseEntity<ErrorMessage> commonExceptionHandler(CommonException ex) {
        log.error("CommonException", ex);

        return responseUtils.wrapErrors(
                Collections.singletonList(ErrorField.of(ex.getCode(), null, ex.getMessage())),
                ex.getCode(),
                ex.getType(),
                ex.getMessage(),
                ex.getStatus());
    }

    /**
     * Catch IllegalArgumentException
     *
     * @param ex @{@link IllegalArgumentException}
     * @return @{@link ErrorMessage}
     */
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ErrorMessage> illegalArgumentExceptionHandler(IllegalArgumentException ex) {
        log.error("MethodArgumentNotValidException", ex);

        List<ErrorField> errorFieldList;
        if (ex.getCause() instanceof InvalidFormatException cause) {
            StringJoiner sj = new StringJoiner(".");
            cause.getPath().forEach(reference -> sj.add(reference.getFieldName()));

            errorFieldList = Collections.singletonList(ErrorField.of(messageUtils.getPropertyValue(INVALID_DATA_FORMAT_ERROR_CODE), sj.toString(),
                    messageUtils.getPropertyValue(INVALID_DATA_FORMAT_ERROR_MESSAGE)));
        } else {
            errorFieldList = null;
        }

        return responseUtils.wrapErrors(
                errorFieldList,
                messageUtils.getPropertyValue(VALIDATION_FAILURE_ERROR_CODE),
                messageUtils.getPropertyValue(VALIDATION_ERROR_TYPE),
                messageUtils.getPropertyValue(VALIDATION_FAILURE_ERROR_MESSAGE),
                HttpStatus.BAD_REQUEST);
    }

    /**
     * Catch AsyncExecutorException
     *
     * @param ex      @{@link AsyncExecutorException}
     * @return @{@link ErrorMessage}
     */
    @ExceptionHandler(AsyncExecutorException.class)
    public ResponseEntity<ErrorMessage> asyncExecutorExceptionHandler(AsyncExecutorException ex) {
        log.error("AsyncExecutorException", ex);

        final Throwable cause = ex.getCause();
        ErrorField errorField = null;
        if (cause instanceof TimeoutException) {
            errorField = ErrorField.of(messageUtils.getPropertyValue(TIMEOUT_EXCEPTION_ERROR_CODE), null,
                    messageUtils.getPropertyValue(TIMEOUT_EXCEPTION_ERROR_MESSAGE));
        } else if (cause instanceof CancellationException) {
            errorField = ErrorField.of(messageUtils.getPropertyValue(CANCELLATION_EXCEPTION_ERROR_CODE), null,
                    messageUtils.getPropertyValue(CANCELLATION_EXCEPTION_ERROR_MESSAGE));
        }

        return responseUtils.wrapErrors(
                Collections.singletonList(errorField),
                messageUtils.getPropertyValue(EXECUTION_ERROR_CODE),
                messageUtils.getPropertyValue(EXECUTION_ERROR_TYPE),
                messageUtils.getPropertyValue(EXECUTION_ERROR_MESSAGE),
                HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Catch Global Exceptions
     *
     * @param ex @{@link Exception}
     * @return @{@link ErrorMessage}
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorMessage> globalExceptionHandler(Exception ex) {
        log.error("Exception", ex);

        return responseUtils.wrapErrors(
                Collections.singletonList(ErrorField.of(messageUtils.getPropertyValue(GLOBAL_ERROR_CODE), null,
                        messageUtils.getPropertyValue(GLOBAL_ERROR_MESSAGE))),
                messageUtils.getPropertyValue(SYSTEM_ERROR_CODE),
                messageUtils.getPropertyValue(GLOBAL_ERROR_TYPE),
                messageUtils.getPropertyValue(SYSTEM_ERROR_MESSAGE),
                HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
