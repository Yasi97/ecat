package com.booleanlabs.ecatalogue.userservice.application.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@Getter
@ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
public class AsyncExecutorException extends RuntimeException {

    /**
     * Async Executor Exception
     *
     * @param t   Throwable Runtime Exception
     * @param <T> Target Type
     */
    public <T> AsyncExecutorException(Throwable t) {
        super(t);
    }

}
