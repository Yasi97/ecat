package com.booleanlabs.ecatalogue.userservice.domain.dto;

/**
 * @author dilanka
 * @created 20/01/2024 - 8:58 PM
 * @project ecat-user-service
 */
public enum OperationType {
    READ,UPDATE
}
