package com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * @author dilanka
 * @created 20/01/2024 - 3:06 PM
 * @project ecat-user-service
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class InternalUserUpdateDomainDto {
    private Long userId;
    private Long roleId;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private Long plantId;
    private Long departmentId;
    private List<Long> userBrandIds;
}
