package com.booleanlabs.ecatalogue.userservice.domain.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author dilanka
 * @created 20/01/2024 - 9:31 PM
 * @project ecat-user-service
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class InternalUserSearchResultEntity {
    private Long id;
    private Long userId;
    private String firstName;
    private String lastName;
    private String emailAddress;
    private String phoneNumber;
    private Long roleId;
    private String roleName;
    private Long plantId;
    private String plantName;
    private Long departmentId;
    private String departmentName;
}
