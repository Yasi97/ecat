package com.booleanlabs.ecatalogue.userservice.application.response.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class ErrorMessage {
    private String message;
    private String code;
    private String traceId;
    private String type;
    private String origin;
    private String details;
    private String timestamp;
    private ErrorResponse data;
}
