package com.booleanlabs.ecatalogue.userservice.application.request.dto.internal.user;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.ENTITY_ERROR_MAX_SIZE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.ENTITY_ERROR_NOT_NULL;

/**
 * @author dilanka
 * @created 20/01/2024 - 7:37 AM
 * @project ecat-user-service
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class InternalUserUpdateRequestDto {

    @NotNull(message = ENTITY_ERROR_NOT_NULL)
    private Long userId;

    @NotNull(message = ENTITY_ERROR_NOT_NULL)
    private Long roleId;

    @NotEmpty(message = ENTITY_ERROR_NOT_NULL)
    @Size(
            max = 150,
            message = ENTITY_ERROR_MAX_SIZE
    )
    private String firstName;

    @NotEmpty(message = ENTITY_ERROR_NOT_NULL)
    @Size(
            max = 150,
            message = ENTITY_ERROR_MAX_SIZE
    )
    private String lastName;

    @NotEmpty(message = ENTITY_ERROR_NOT_NULL)
    @Size(
            max = 20,
            message = ENTITY_ERROR_MAX_SIZE
    )
    private String phoneNumber;

    @NotNull(message = ENTITY_ERROR_NOT_NULL)
    private Long plantId;

    @NotNull(message = ENTITY_ERROR_NOT_NULL)
    private Long departmentId;

    private List<Long> userBrandIds;
}
