package com.booleanlabs.ecatalogue.userservice.domain.service;

import com.booleanlabs.ecatalogue.userservice.domain.dto.BaseResponseMessageDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.role.RoleDomainDto;
import com.booleanlabs.ecatalogue.userservice.external.repository.RoleRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author dilanka
 * @created 23/01/2024 - 9:26 PM
 * @project ecat-user-service
 */
@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class RoleService {
    private final RoleRepository roleRepository;
    private final ObjectMapper mapper;

    /**
     * Create Role
     *
     * @param requestDro request
     * @return response
     */
    public BaseResponseMessageDomainDto createRole(RoleDomainDto requestDro) {
        final String roleValue = requestDro.getRoleName().toUpperCase().replace(" ", "_");
        log.info("Create Role started|{}|{}", requestDro.getRoleName(), roleValue);

        requestDro.setRoleValue(roleValue);
        roleRepository.createRole(requestDro);
        return new BaseResponseMessageDomainDto("Role created successfully");
    }

    /**
     * Get all Roles
     *
     * @return roles
     */
    public List<RoleDomainDto> loadAll() {
        return mapper.convertValue(roleRepository.loadAll(), new TypeReference<>() {
        });
    }
}
