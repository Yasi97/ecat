package com.booleanlabs.ecatalogue.userservice.domain.dto;

public enum UserTypeEnum {
    CUSTOMER,
    ADMIN,
    CUSTOMER_ADMIN
}