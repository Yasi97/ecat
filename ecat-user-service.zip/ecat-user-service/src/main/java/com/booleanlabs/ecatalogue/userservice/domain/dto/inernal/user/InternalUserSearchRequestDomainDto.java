package com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user;

import com.booleanlabs.ecatalogue.userservice.domain.dto.BaseSearchRequestDomainDto;
import lombok.Getter;
import lombok.Setter;

/**
 * @author dilanka
 * @created 20/01/2024 - 5:42 PM
 * @project ecat-user-service
 */
@Getter
@Setter
public class InternalUserSearchRequestDomainDto extends BaseSearchRequestDomainDto {
    private String emailAddress;
    private String name;
    private Long plantId;
    private Long departmentId;
}
