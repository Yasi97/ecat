package com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * @author dilanka
 * @created 20/01/2024 - 9:03 PM
 * @project ecat-user-service
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class InternalUserLoadResponseDomainDto {
    private Long userId;
    private String roleName;
    private String emailAddress;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private Long plantId;
    private String plantName;
    private Long departmentId;
    private String departmentName;
    private List<String> userBrandNames;
    private List<Long> userBrandIds;
}
