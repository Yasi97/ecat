package com.booleanlabs.ecatalogue.userservice.external.repository.mapper.role;

import com.booleanlabs.ecatalogue.userservice.domain.entities.RoleEntity;
import com.booleanlabs.ecatalogue.userservice.external.repository.util.RepositoryUtils;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import static com.booleanlabs.ecatalogue.userservice.external.repository.constant.ColumnConstant.IS_DEFAULT;
import static com.booleanlabs.ecatalogue.userservice.external.repository.constant.ColumnConstant.ROLE_ID;
import static com.booleanlabs.ecatalogue.userservice.external.repository.constant.ColumnConstant.ROLE_NAME;
import static com.booleanlabs.ecatalogue.userservice.external.repository.constant.ColumnConstant.ROLE_VALUE;
import static com.booleanlabs.ecatalogue.userservice.external.repository.constant.ColumnConstant.SYSTEM_ACTOR_ID;

/**
 * @author dilanka
 * @created 23/01/2024 - 10:05 PM
 * @project ecat-user-service
 */
public class RoleResultRowMapper implements RowMapper<RoleEntity> {
    @Override
    public RoleEntity mapRow(ResultSet rs, int rowNum) throws SQLException {
        final RoleEntity roleEntity = new RoleEntity();

        roleEntity.setRoleId(RepositoryUtils.getLongOrDefault(rs, ROLE_ID, null));
        roleEntity.setSystemActorId(RepositoryUtils.getLongOrDefault(rs, SYSTEM_ACTOR_ID, null));
        roleEntity.setRoleName(RepositoryUtils.getStringOrDefault(rs, ROLE_NAME, null));
        roleEntity.setRoleValue(RepositoryUtils.getStringOrDefault(rs, ROLE_VALUE, null));
        roleEntity.setIsDefault(rs.getBoolean(IS_DEFAULT));

        return roleEntity;
    }
}
