package com.booleanlabs.ecatalogue.userservice.application.controller;

import com.booleanlabs.ecatalogue.userservice.application.request.dto.BaseLoadRequest;
import com.booleanlabs.ecatalogue.userservice.application.request.dto.internal.user.InternalUserCreateRequestDto;
import com.booleanlabs.ecatalogue.userservice.application.request.dto.internal.user.InternalUserSearchRequestDto;
import com.booleanlabs.ecatalogue.userservice.application.request.dto.internal.user.InternalUserUpdateRequestDto;
import com.booleanlabs.ecatalogue.userservice.application.response.dto.ErrorMessage;
import com.booleanlabs.ecatalogue.userservice.application.response.dto.SuccessMessage;
import com.booleanlabs.ecatalogue.userservice.application.util.ResponseUtils;
import com.booleanlabs.ecatalogue.userservice.application.validator.RequestEntityValidator;
import com.booleanlabs.ecatalogue.userservice.domain.dto.BaseLoadRequestDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.BaseResponseMessageDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.BaseSearchResponseDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserCreateDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserLoadResponseDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserSearchRequestDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserSearchResponseDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserUpdateDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.service.InternalUserUserService;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Objects;

import static com.booleanlabs.ecatalogue.userservice.application.constant.AppConstants.APP_ROOT_V1_WEB;
import static com.booleanlabs.ecatalogue.userservice.application.constant.AppConstants.Actions.CREATE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.AppConstants.Actions.DELETE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.AppConstants.Actions.LOAD;
import static com.booleanlabs.ecatalogue.userservice.application.constant.AppConstants.Actions.SEARCH;
import static com.booleanlabs.ecatalogue.userservice.application.constant.AppConstants.Actions.UPDATE;

/**
 * @author dilanka
 * @created 20/01/2024 - 7:30 AM
 * @project ecat-user-service
 */
@RestController
@RequestMapping(APP_ROOT_V1_WEB + "/internal-user")
@Validated
@RequiredArgsConstructor
@Slf4j
public class InternalUserController {

    private final ResponseUtils responseUtils;
    private final RequestEntityValidator validator;
    private final ObjectMapper mapper;
    private final InternalUserUserService internalUserUserService;

    @Operation(summary = "Create Internal User")
    @ApiResponses(value = {
            @ApiResponse(description = "Create Internal User Success", responseCode = "201"),
            @ApiResponse(description = "Bad Request in Create Internal User", responseCode = "400", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))}),
            @ApiResponse(description = "Exception occurred when processing Create Internal User", responseCode = "500", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))})})
    @PostMapping(value = CREATE, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessMessage<BaseResponseMessageDomainDto>> createInternalUser(@RequestBody InternalUserCreateRequestDto createRequest) {

        log.info("Create Internal User started");

        //validation
        validator.validate(createRequest);

        final InternalUserCreateDomainDto internalUserCreateDomainDto = mapper.convertValue(createRequest, InternalUserCreateDomainDto.class);

        final BaseResponseMessageDomainDto message = internalUserUserService.createInternalUser(internalUserCreateDomainDto);

        final ResponseEntity<SuccessMessage<BaseResponseMessageDomainDto>> response = responseUtils.wrapSuccess(message, HttpStatus.CREATED);

        log.info("Create Internal User completed|{}|{}", Objects.requireNonNull(response.getBody()).getCode(), Objects.requireNonNull(response.getBody()).getMessage());

        return response;
    }

    @Operation(summary = "Delete internal user")
    @ApiResponses(value = {
            @ApiResponse(description = "internal user deleted", responseCode = "200"),
            @ApiResponse(description = "Bad Request internal user", responseCode = "400", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))}),
            @ApiResponse(description = "Exception occurred when processing internal user", responseCode = "500", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))})})
    @DeleteMapping(value = DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessMessage<BaseResponseMessageDomainDto>> deleteInternalUser(@Validated @NotNull @Max(300) @PathVariable Long id) {

        log.info("Delete internal user started|{}", id);

        final BaseResponseMessageDomainDto message = internalUserUserService.deleteInternalUser(id);

        final ResponseEntity<SuccessMessage<BaseResponseMessageDomainDto>> response = responseUtils.wrapSuccess(message, HttpStatus.OK);

        log.info("Delete internal user completed|{}|{}", Objects.requireNonNull(response.getBody()).getCode(), Objects.requireNonNull(response.getBody()).getMessage());

        return response;
    }

    @Operation(summary = "Update Internal User")
    @ApiResponses(value = {
            @ApiResponse(description = "Update Internal User Success", responseCode = "200"),
            @ApiResponse(description = "Bad Request in Update Internal User", responseCode = "400", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))}),
            @ApiResponse(description = "Exception occurred when processing Update Internal User", responseCode = "500", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))})})
    @PutMapping(value = UPDATE, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessMessage<BaseResponseMessageDomainDto>> updateInternalUser(@RequestBody InternalUserUpdateRequestDto updateRequest) {

        log.info("Update Internal User started");

        //validation
        validator.validate(updateRequest);

        final InternalUserUpdateDomainDto userUpdateDomainDto = mapper.convertValue(updateRequest, InternalUserUpdateDomainDto.class);

        final BaseResponseMessageDomainDto message = internalUserUserService.updateInternalUser(userUpdateDomainDto);

        final ResponseEntity<SuccessMessage<BaseResponseMessageDomainDto>> response = responseUtils.wrapSuccess(message, HttpStatus.OK);

        log.info("Update Internal User completed|{}|{}", Objects.requireNonNull(response.getBody()).getCode(), Objects.requireNonNull(response.getBody()).getMessage());

        return response;
    }

    @Operation(summary = "Search Internal User")
    @ApiResponses(value = {
            @ApiResponse(description = "Search Customer Request Success", responseCode = "200"),
            @ApiResponse(description = "Bad Request in Search Customer Request", responseCode = "400", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))}),
            @ApiResponse(description = "Exception occurred when processing Search Customer Request", responseCode = "500", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))})})
    @PostMapping(value = SEARCH, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessMessage<BaseSearchResponseDomainDto<InternalUserSearchResponseDomainDto>>> searchInternalUser(@RequestBody InternalUserSearchRequestDto searchRequestDto) {

        //validation
        validator.validate(searchRequestDto);
        InternalUserSearchRequestDomainDto customerSearchDomainDto = mapper.convertValue(searchRequestDto, InternalUserSearchRequestDomainDto.class);

        BaseSearchResponseDomainDto<InternalUserSearchResponseDomainDto> searchCustomerResponse = internalUserUserService.searchInternalUser(customerSearchDomainDto);

        final ResponseEntity<SuccessMessage<BaseSearchResponseDomainDto<InternalUserSearchResponseDomainDto>>> response = responseUtils.wrapSuccess(searchCustomerResponse, HttpStatus.OK);

        log.info("Search Internal User Request completed");
        return response;
    }

    @Operation(summary = "Load Internal User")
    @ApiResponses(value = {
            @ApiResponse(description = "Load Customer Request Success", responseCode = "200"),
            @ApiResponse(description = "Bad Request in Load Customer Request", responseCode = "400", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))}),
            @ApiResponse(description = "Exception occurred when processing Load Customer Request", responseCode = "500", content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class))})})
    @PostMapping(value = LOAD, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessMessage<InternalUserLoadResponseDomainDto>> loadInternalUser(@RequestBody BaseLoadRequest loadRequest) {
        log.info("Load Internal User started");

        //validation
        validator.validate(loadRequest);
        BaseLoadRequestDomainDto loadRequestDomainDto = mapper.convertValue(loadRequest, BaseLoadRequestDomainDto.class);

        InternalUserLoadResponseDomainDto searchCustomerResponse = internalUserUserService.loadInternalUser(loadRequestDomainDto);

        final ResponseEntity<SuccessMessage<InternalUserLoadResponseDomainDto>> response = responseUtils.wrapSuccess(searchCustomerResponse, HttpStatus.OK);

        log.info("Load Internal User Request completed");
        return response;
    }
}
