package com.booleanlabs.ecatalogue.userservice.domain.util;

import com.booleanlabs.ecatalogue.userservice.application.request.dto.BaseSearchRequest;
import com.booleanlabs.ecatalogue.userservice.application.request.dto.OrderBy;
import org.junit.jupiter.api.Test;
import org.springframework.data.domain.Pageable;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * @author dilanka
 * @created 15/01/2024 - 11:51 AM
 * @project user-service
 */
class DataTableUtilTest {
    @Test
    void createPageRequestOrdersTest() {
        //given
        BaseSearchRequest baseSearchRequest = new BaseSearchRequest();

        baseSearchRequest.setOrders(List.of(new OrderBy()));

        //then
        Pageable pageRequest = DataTableUtil.createPageRequest(baseSearchRequest);

        assertThat(pageRequest).isNotNull();
    }

    @Test
    void createPageRequestSortingFieldsTest() {
        //given
        BaseSearchRequest baseSearchRequest = new BaseSearchRequest();

        baseSearchRequest.setSortingFields(new String[]{"name", "code"});

        //then
        Pageable pageRequest = DataTableUtil.createPageRequest(baseSearchRequest);

        assertThat(pageRequest).isNotNull();
    }

    @Test
    void createPageRequestDefaultTest() {
        //given
        BaseSearchRequest baseSearchRequest = new BaseSearchRequest();

        //then
        Pageable pageRequest = DataTableUtil.createPageRequest(baseSearchRequest);

        assertThat(pageRequest).isNotNull();
    }
}