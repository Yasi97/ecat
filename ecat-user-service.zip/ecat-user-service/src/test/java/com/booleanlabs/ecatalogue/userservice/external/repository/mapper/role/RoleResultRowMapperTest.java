package com.booleanlabs.ecatalogue.userservice.external.repository.mapper.role;

import com.booleanlabs.ecatalogue.userservice.domain.entities.RoleEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

/**
 * @author dilanka
 * @created 25/01/2024 - 8:42 AM
 * @project ecat-user-service
 */
@ExtendWith(MockitoExtension.class)
class RoleResultRowMapperTest {
    @Mock
    private ResultSet resultSet;

    private final RoleResultRowMapper rowMapper = new RoleResultRowMapper();

    @Test
    void mapRow() throws SQLException {
        //when
        when(resultSet.getLong(anyString())).thenReturn(1L);
        when(resultSet.getString(anyString())).thenReturn("Value");

        //when
        RoleEntity entity = assertDoesNotThrow(() -> rowMapper.mapRow(resultSet, 0));
        assertNotNull(entity);
    }
}