package com.booleanlabs.ecatalogue.userservice.domain.service;

import com.booleanlabs.ecatalogue.userservice.application.exception.ValidationException;
import com.booleanlabs.ecatalogue.userservice.application.exception.vm.ErrorField;
import com.booleanlabs.ecatalogue.userservice.application.util.MessageUtils;
import com.booleanlabs.ecatalogue.userservice.domain.dto.BaseLoadRequestDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.BaseResponseMessageDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.BaseSearchResponseDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.OperationType;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserCreateDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserLoadResponseDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserSearchRequestDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserSearchResponseDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserUpdateDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.entities.InternalUserSearchResultEntity;
import com.booleanlabs.ecatalogue.userservice.external.repository.InternalUserBrandRepository;
import com.booleanlabs.ecatalogue.userservice.external.repository.InternalUserRepository;
import com.booleanlabs.ecatalogue.userservice.external.repository.UserRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.ERROR_MESSAGE_RECORD_EXISTS;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

/**
 * @author dilanka
 * @created 21/01/2024 - 9:18 AM
 * @project ecat-user-service
 */
@ExtendWith(MockitoExtension.class)
class InternalUserUserServiceTest {

    @Mock
    private UserRepository userRepository;
    @Mock
    private InternalUserRepository internalUserRepository;
    @Mock
    private InternalUserBrandRepository internalUserBrandRepository;
    @Mock
    private MessageUtils messageUtils;
    @Mock
    private ObjectMapper mapper;

    @InjectMocks
    private InternalUserUserService userUserService;

    @Test
    void createInternalUser() {
        //given
        final InternalUserCreateDomainDto domainDto = new InternalUserCreateDomainDto(1L, "6yZuW@example.com", "dilanka", "Samara", "0777", 1L, 1L, List.of(1L, 2L));

        //when
        when(userRepository.createUser(domainDto)).thenReturn(1L);
        when(internalUserRepository.createInternalUser(1L, domainDto)).thenReturn(1L);

        //then
        BaseResponseMessageDomainDto messageDomainDto = assertDoesNotThrow(() -> userUserService.createInternalUser(domainDto));
        assertThat(messageDomainDto.getMessage()).isEqualTo("User created successfully");
    }

    @Test
    void createInternalUserExist() {
        //given
        final InternalUserCreateDomainDto domainDto = new InternalUserCreateDomainDto(1L, "6yZuW@example.com", "dilanka", "Samara", "0777", 1L, 1L, List.of(1L, 2L));
        final ErrorField errorField = ErrorField.of("0999", null, "Record already exists");

        //when
        when(userRepository.isUserExist(domainDto.getEmailAddress())).thenReturn(true);
        when(messageUtils.getErrorField(ERROR_MESSAGE_RECORD_EXISTS)).thenReturn(errorField);

        //then
        ValidationException validationException = assertThrows(ValidationException.class, () -> userUserService.createInternalUser(domainDto));
        assertThat(validationException.getErrors().stream().findFirst()).isPresent();
        assertThat(validationException.getErrors().stream().findFirst()).contains(errorField);
    }

    @Test
    void deleteInternalUser() {
        BaseResponseMessageDomainDto messageDomainDto = assertDoesNotThrow(() -> userUserService.deleteInternalUser(1L));
        assertThat(messageDomainDto.getMessage()).isEqualTo("User deleted successfully");
    }

    @Test
    void updateInternalUser() {
        //given
        final InternalUserUpdateDomainDto domainDto = new InternalUserUpdateDomainDto(1L, 2L, "dilanka", "Samara", "0777", 1L, 1L, List.of(1L, 2L));

        //when
        when(internalUserRepository.findIdByUserId(1L)).thenReturn(1L);

        //then
        BaseResponseMessageDomainDto messageDomainDto = assertDoesNotThrow(() -> userUserService.updateInternalUser(domainDto));
        assertThat(messageDomainDto.getMessage()).isEqualTo("User updated successfully");
    }

    @Test
    void searchInternalUser() {
        //given
        final InternalUserSearchRequestDomainDto domainDto = new InternalUserSearchRequestDomainDto();
        domainDto.setEmailAddress("6yZuW@example.com");
        domainDto.setName("dilanka");
        domainDto.setPlantId(1L);
        domainDto.setDepartmentId(1L);

        final InternalUserSearchResultEntity entity = new InternalUserSearchResultEntity(1L, 1L, "dilanka", "Samara", "6yZuW@example.com", "0777", 1L, "Admin", 1L, "Plant 1", 1L, "Department 1");

        final BaseSearchResponseDomainDto<InternalUserSearchResultEntity> searchResult = BaseSearchResponseDomainDto.<InternalUserSearchResultEntity>builder()
                .items(List.of(entity))
                .build();
        //when
        when(internalUserRepository.searchInternalUser(domainDto)).thenReturn(searchResult);
        when(mapper.convertValue(eq(searchResult), any(TypeReference.class))).thenReturn(searchResult);

        //then
        BaseSearchResponseDomainDto<InternalUserSearchResponseDomainDto> responseDomainDto = assertDoesNotThrow(() -> userUserService.searchInternalUser(domainDto));
        assertThat(responseDomainDto.getItems()).hasSize(1);
    }

    @Test
    void loadInternalUserUpdate() {
        //given
        final BaseLoadRequestDomainDto requestDomainDto = new BaseLoadRequestDomainDto(1L, OperationType.UPDATE);
        InternalUserSearchResultEntity entity = new InternalUserSearchResultEntity(1L, 1L, "dilanka", "Samara", "6yZuW@example.com", "0777", 1L, "Admin", 1L, "Plant 1", 1L, "Department 1");
        final InternalUserLoadResponseDomainDto searchCustomerResponse = new InternalUserLoadResponseDomainDto(1L, "Role 01", "dilanka@asd.com", "dilanka", "Samara", "0777", 1L, "Plant 1", 1L, "Department 1", List.of("Brand 01", "Brand 02"), List.of(1L, 2L));

        //when
        when(internalUserRepository.loadInternalUser(requestDomainDto)).thenReturn(entity);
        when(mapper.convertValue(entity, InternalUserLoadResponseDomainDto.class)).thenReturn(searchCustomerResponse);
        when(internalUserBrandRepository.loadUpdate(1L)).thenReturn(List.of(1L, 2L));

        //then
        InternalUserLoadResponseDomainDto responseDomainDto = assertDoesNotThrow(() -> userUserService.loadInternalUser(requestDomainDto));
        assertThat(responseDomainDto).isNotNull();
        assertThat(responseDomainDto.getUserId()).isEqualTo(entity.getUserId());
        assertThat(responseDomainDto.getFirstName()).isEqualTo(entity.getFirstName());
    }

    @Test
    void loadInternalUserRead() {
        //given
        final BaseLoadRequestDomainDto requestDomainDto = new BaseLoadRequestDomainDto(1L, OperationType.READ);
        InternalUserSearchResultEntity entity = new InternalUserSearchResultEntity(1L, 1L, "dilanka", "Samara", "6yZuW@example.com", "0777", 1L, "Admin", 1L, "Plant 1", 1L, "Department 1");
        final InternalUserLoadResponseDomainDto searchCustomerResponse = new InternalUserLoadResponseDomainDto(1L, "Role 01", "dilanka@asd.com", "dilanka", "Samara", "0777", 1L, "Plant 1", 1L, "Department 1", List.of("Brand 01", "Brand 02"), List.of(1L, 2L));

        //when
        when(internalUserRepository.loadInternalUser(requestDomainDto)).thenReturn(entity);
        when(mapper.convertValue(entity, InternalUserLoadResponseDomainDto.class)).thenReturn(searchCustomerResponse);
        when(internalUserBrandRepository.loadRead(1L)).thenReturn(List.of("Brand 01", "Brand 02"));

        //then
        InternalUserLoadResponseDomainDto responseDomainDto = assertDoesNotThrow(() -> userUserService.loadInternalUser(requestDomainDto));
        assertThat(responseDomainDto).isNotNull();
        assertThat(responseDomainDto.getUserId()).isEqualTo(entity.getUserId());
        assertThat(responseDomainDto.getFirstName()).isEqualTo(entity.getFirstName());
    }
}