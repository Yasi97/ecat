package com.booleanlabs.ecatalogue.userservice.external.repository;

import com.booleanlabs.ecatalogue.userservice.domain.dto.BaseLoadRequestDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.BaseSearchResponseDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.OperationType;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserCreateDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserSearchRequestDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserUpdateDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.entities.InternalUserSearchResultEntity;
import com.booleanlabs.ecatalogue.userservice.external.repository.constant.QueryConstants;
import com.booleanlabs.ecatalogue.userservice.external.repository.mapper.internal.user.InternalUserLoadResultRowMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

/**
 * @author dilanka
 * @created 21/01/2024 - 7:00 AM
 * @project ecat-user-service
 */
@ExtendWith(MockitoExtension.class)
class InternalUserRepositoryTest {
    @Mock
    private JdbcTemplate jdbcTemplate;
    @InjectMocks
    private InternalUserRepository internalUserRepository;

    @Test
    void createInternalUser() {
        //given
        long userId = 1L;
        InternalUserCreateDomainDto createDomainDto = new InternalUserCreateDomainDto(1L, "6yZuW@example.com", "dilanka", "Samara", "0777", 1L, 1L, List.of(1L, 2L));

        //when
        when(jdbcTemplate.queryForObject(QueryConstants.InternalUser.SEQ_NEXT_VAL, Long.class)).thenReturn(1L);

        //then
        Long id = assertDoesNotThrow(() -> internalUserRepository.createInternalUser(userId, createDomainDto));
        assertThat(id).isEqualTo(1L);
    }

    @Test
    void softDeleteUser() {
        //given
        long internalUserId = 1L;

        //when

        //then
        assertDoesNotThrow(() -> internalUserRepository.softDeleteUser(internalUserId));
    }

    @Test
    void findIdByUserId() {
        //given
        long userId = 1L;

        //when
        when(jdbcTemplate.queryForObject(QueryConstants.InternalUser.FIND_ID_BY_USER_ID, Long.class, userId)).thenReturn(1L);

        //then
        Long id = assertDoesNotThrow(() -> internalUserRepository.findIdByUserId(userId));
        assertThat(id).isEqualTo(1L);
    }

    @Test
    void updateInternalUser() {
        //given
        InternalUserUpdateDomainDto updateDomainDto = new InternalUserUpdateDomainDto(1L, 2L, "dilanka", "Samara", "0777", 1L, 1L, List.of(1L, 2L));

        //when

        //then
        assertDoesNotThrow(() -> internalUserRepository.updateInternalUser(updateDomainDto));
    }

    @Test
    void searchInternalUser() {
        //given
        InternalUserSearchRequestDomainDto requestDomainDto = new InternalUserSearchRequestDomainDto();
        requestDomainDto.setEmailAddress("6yZuW@example.com");
        requestDomainDto.setName("dilanka");
        requestDomainDto.setPlantId(1L);
        requestDomainDto.setDepartmentId(1L);

        List<InternalUserSearchResultEntity> customerFetchDtos = List.of(
                new InternalUserSearchResultEntity(1L, 1L, "dilanka", "Samara", "6yZuW@example.com", "0777", 1L, "Admin", 1L, "Plant 1", 1L, "Department 1")
        );

        //when
        when(jdbcTemplate.query(any(String.class), any(InternalUserLoadResultRowMapper.class), any(Object[].class))).thenReturn(customerFetchDtos);
        when(jdbcTemplate.queryForObject(any(String.class), eq(Long.class), any(Object[].class))).thenReturn(1L);

        //then
        BaseSearchResponseDomainDto<InternalUserSearchResultEntity> responseDomainDto = assertDoesNotThrow(() -> internalUserRepository.searchInternalUser(requestDomainDto));
        assertThat(responseDomainDto.getItems()).hasSize(1);
    }

    @Test
    void loadInternalUser() {
        //given
        BaseLoadRequestDomainDto loadRequestDomainDto = new BaseLoadRequestDomainDto(1L, OperationType.READ);
        InternalUserSearchResultEntity entity = new InternalUserSearchResultEntity(1L, 1L, "dilanka", "Samara", "6yZuW@example.com", "0777", 1L, "Admin", 1L, "Plant 1", 1L, "Department 1");

        //when
        when(jdbcTemplate.queryForObject(any(String.class), any(InternalUserLoadResultRowMapper.class), eq(loadRequestDomainDto.getId()))).thenReturn(entity);

        //then
        InternalUserSearchResultEntity searchResult = assertDoesNotThrow(() -> internalUserRepository.loadInternalUser(loadRequestDomainDto));
        assertThat(searchResult).isEqualTo(entity);
    }
}