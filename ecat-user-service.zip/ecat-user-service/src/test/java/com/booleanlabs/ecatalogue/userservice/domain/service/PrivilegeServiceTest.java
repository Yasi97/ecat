package com.booleanlabs.ecatalogue.userservice.domain.service;

import com.booleanlabs.ecatalogue.userservice.application.exception.NotFoundException;
import com.booleanlabs.ecatalogue.userservice.application.exception.vm.ErrorField;
import com.booleanlabs.ecatalogue.userservice.application.util.MessageUtils;
import com.booleanlabs.ecatalogue.userservice.domain.dto.BaseResponseMessageDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.role.PrivilegeDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.role.RolePrivilegeSearchResponseDomainDto;
import com.booleanlabs.ecatalogue.userservice.external.repository.PrivilegeRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static com.booleanlabs.ecatalogue.userservice.application.constant.ErrorConstants.ERROR_9006;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

/**
 * @author dilanka
 * @created 25/01/2024 - 9:33 AM
 * @project ecat-user-service
 */
@ExtendWith(MockitoExtension.class)
class PrivilegeServiceTest {
    @Mock
    private MessageUtils messageUtils;
    @Mock
    private PrivilegeRepository privilegeRepository;

    @InjectMocks
    private PrivilegeService privilegeService;

    @Test
    void createRolePrivileges() {
        //given
        final PrivilegeDomainDto domainDto = new PrivilegeDomainDto(11L, List.of(1L, 2L, 3L));

        //then
        final BaseResponseMessageDomainDto messageDomainDto = assertDoesNotThrow(() -> privilegeService.createRolePrivileges(domainDto));
        assertThat(messageDomainDto.getMessage()).isEqualTo("Privileges added successfully");
    }

    @Test
    void loadUpdate() {
        //given
        final Long roleId = 1L;
        final List<Long> privileges = List.of(1L, 2L, 3L);

        //when
        when(privilegeRepository.loadUpdate(roleId)).thenReturn(privileges);

        //then
        final RolePrivilegeSearchResponseDomainDto serviceReturn = assertDoesNotThrow(() -> privilegeService.loadUpdate(roleId));

        assertThat(serviceReturn.getPrivilegeIds()).isEqualTo(privileges);
    }

    @Test
    void loadUpdateRoleNotFound() {
        //given
        final Long roleId = 2L;

        //when
        when(privilegeRepository.loadUpdate(roleId)).thenReturn(null);
        when(messageUtils.getErrorField(ERROR_9006)).thenReturn(ErrorField.of("9006", null, "Role not found"));

        //then
        final NotFoundException notFoundException = assertThrows(NotFoundException.class, () -> privilegeService.loadUpdate(roleId));

        assertThat(notFoundException.getCode()).isEqualTo("9006");
        assertThat(notFoundException.getMessage()).isEqualTo("Role not found");
    }
}