package com.booleanlabs.ecatalogue.userservice.application.controller;

import com.booleanlabs.ecatalogue.userservice.application.request.dto.BaseLoadRequest;
import com.booleanlabs.ecatalogue.userservice.application.request.dto.internal.user.InternalUserCreateRequestDto;
import com.booleanlabs.ecatalogue.userservice.application.request.dto.internal.user.InternalUserSearchRequestDto;
import com.booleanlabs.ecatalogue.userservice.application.request.dto.internal.user.InternalUserUpdateRequestDto;
import com.booleanlabs.ecatalogue.userservice.application.response.dto.SuccessMessage;
import com.booleanlabs.ecatalogue.userservice.application.util.DateTimeUtils;
import com.booleanlabs.ecatalogue.userservice.application.util.ResponseUtils;
import com.booleanlabs.ecatalogue.userservice.application.validator.RequestEntityValidator;
import com.booleanlabs.ecatalogue.userservice.domain.dto.BaseLoadRequestDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.BaseResponseMessageDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.BaseSearchResponseDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.OperationType;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserCreateDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserLoadResponseDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserSearchRequestDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserSearchResponseDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserUpdateDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.service.InternalUserUserService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Date;
import java.util.List;

import static com.booleanlabs.ecatalogue.userservice.application.constant.SuccessConstants.SUCCESS_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.SuccessConstants.SUCCESS_MESSAGE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

/**
 * @author dilanka
 * @created 20/01/2024 - 11:17 AM
 * @project ecat-user-service
 */
@ExtendWith(MockitoExtension.class)
class InternalUserControllerTest {
    @Mock
    private ResponseUtils responseUtils;
    @Mock
    private RequestEntityValidator validator;
    @Mock
    private ObjectMapper mapper;
    @Mock
    private InternalUserUserService userUserService;

    @InjectMocks
    private InternalUserController userController;


    @Test
    void createInternalUser() {
        //given
        final InternalUserCreateRequestDto createRequest = new InternalUserCreateRequestDto(1L, "6yZuW@example.com", "dilanka", "Samara", "0777", 1L, 1L, List.of(1L, 2L));
        final InternalUserCreateDomainDto domainDto = new InternalUserCreateDomainDto(1L, "6yZuW@example.com", "dilanka", "Samara", "0777", 1L, 1L, List.of(1L, 2L));
        final BaseResponseMessageDomainDto message = new BaseResponseMessageDomainDto("Successfully Created Internal User");


        final SuccessMessage<BaseResponseMessageDomainDto> successMessageBuilder = SuccessMessage.<BaseResponseMessageDomainDto>builder()
                .code(SUCCESS_CODE)
                .data(message)
                .message(SUCCESS_MESSAGE)
                .timestamp(DateTimeUtils.format(new Date()))
                .build();
        final ResponseEntity<SuccessMessage<BaseResponseMessageDomainDto>> successMessage = ResponseEntity.status(HttpStatus.CREATED).body(successMessageBuilder);


        //when
        when(mapper.convertValue(any(), eq(InternalUserCreateDomainDto.class))).thenReturn(domainDto);
        when(userUserService.createInternalUser(any(InternalUserCreateDomainDto.class))).thenReturn(message);
        when(responseUtils.wrapSuccess(message, HttpStatus.CREATED)).thenReturn(successMessage);

        //then
        final ResponseEntity<SuccessMessage<BaseResponseMessageDomainDto>> response = assertDoesNotThrow(() -> userController.createInternalUser(createRequest));

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        assertThat(response.getBody()).isNotNull();
    }

    @Test
    void deleteInternalUser() {
        //given
        final Long id = 1L;
        final BaseResponseMessageDomainDto message = new BaseResponseMessageDomainDto("User deleted successfully");
        final SuccessMessage<BaseResponseMessageDomainDto> successMessageBuilder = SuccessMessage.<BaseResponseMessageDomainDto>builder()
                .code(SUCCESS_CODE)
                .data(message)
                .message(SUCCESS_MESSAGE)
                .timestamp(DateTimeUtils.format(new Date()))
                .build();
        final ResponseEntity<SuccessMessage<BaseResponseMessageDomainDto>> successMessage = ResponseEntity.status(HttpStatus.OK).body(successMessageBuilder);

        //when
        when(userUserService.deleteInternalUser(id)).thenReturn(message);
        when(responseUtils.wrapSuccess(message, HttpStatus.OK)).thenReturn(successMessage);

        //then
        final ResponseEntity<SuccessMessage<BaseResponseMessageDomainDto>> response = assertDoesNotThrow(() -> userController.deleteInternalUser(id));
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isNotNull();
    }

    @Test
    void updateInternalUser() {
        //given
        final InternalUserUpdateRequestDto updateRequest = new InternalUserUpdateRequestDto(1L, 2L, "dilanka", "Samara", "0777", 1L, 1L, List.of(1L, 2L));
        final InternalUserUpdateDomainDto domainDto = new InternalUserUpdateDomainDto(1L, 2L, "dilanka", "Samara", "0777", 1L, 1L, List.of(1L, 2L));
        final BaseResponseMessageDomainDto message = new BaseResponseMessageDomainDto("User updated successfully");

        final SuccessMessage<BaseResponseMessageDomainDto> successMessageBuilder = SuccessMessage.<BaseResponseMessageDomainDto>builder()
                .code(SUCCESS_CODE)
                .data(message)
                .message(SUCCESS_MESSAGE)
                .timestamp(DateTimeUtils.format(new Date()))
                .build();
        final ResponseEntity<SuccessMessage<BaseResponseMessageDomainDto>> successMessage = ResponseEntity.status(HttpStatus.OK).body(successMessageBuilder);

        //when
        when(mapper.convertValue(updateRequest, InternalUserUpdateDomainDto.class)).thenReturn(domainDto);
        when(userUserService.updateInternalUser(any(InternalUserUpdateDomainDto.class))).thenReturn(message);
        when(responseUtils.wrapSuccess(message, HttpStatus.OK)).thenReturn(successMessage);

        //then
        final ResponseEntity<SuccessMessage<BaseResponseMessageDomainDto>> response = assertDoesNotThrow(() -> userController.updateInternalUser(updateRequest));
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isNotNull();
    }

    @Test
    void searchInternalUser() {
        //given
        final InternalUserSearchRequestDto requestDto = new InternalUserSearchRequestDto();
        requestDto.setEmailAddress("6yZuW@example.com");
        requestDto.setName("dilanka");
        requestDto.setPlantId(1L);
        requestDto.setDepartmentId(1L);

        final InternalUserSearchRequestDomainDto domainDto = new InternalUserSearchRequestDomainDto();
        domainDto.setEmailAddress("6yZuW@example.com");
        domainDto.setName("dilanka");
        domainDto.setPlantId(1L);
        domainDto.setDepartmentId(1L);

        final BaseSearchResponseDomainDto<InternalUserSearchResponseDomainDto> searchCustomerResponse = BaseSearchResponseDomainDto.<InternalUserSearchResponseDomainDto>builder()
                .items(List.of(new InternalUserSearchResponseDomainDto(1L, "Role 01", "dilanka", "Samara", "Plant 1", "Department 1")))
                .build();

        final SuccessMessage<BaseSearchResponseDomainDto<InternalUserSearchResponseDomainDto>> successMessageBuilder = SuccessMessage.<BaseSearchResponseDomainDto<InternalUserSearchResponseDomainDto>>builder()
                .code(SUCCESS_CODE)
                .data(searchCustomerResponse)
                .message(SUCCESS_MESSAGE)
                .timestamp(DateTimeUtils.format(new Date()))
                .build();
        final ResponseEntity<SuccessMessage<BaseSearchResponseDomainDto<InternalUserSearchResponseDomainDto>>> successMessage = ResponseEntity.status(HttpStatus.OK).body(successMessageBuilder);


        //when
        when(mapper.convertValue(requestDto, InternalUserSearchRequestDomainDto.class)).thenReturn(domainDto);
        when(userUserService.searchInternalUser(domainDto)).thenReturn(searchCustomerResponse);
        when(responseUtils.wrapSuccess(searchCustomerResponse, HttpStatus.OK)).thenReturn(successMessage);

        //then
        final ResponseEntity<SuccessMessage<BaseSearchResponseDomainDto<InternalUserSearchResponseDomainDto>>> response = assertDoesNotThrow(() -> userController.searchInternalUser(requestDto));
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isNotNull();
    }

    @Test
    void loadInternalUser() {
        //given
        final BaseLoadRequest requestDto = new BaseLoadRequest(1L, OperationType.UPDATE);
        final BaseLoadRequestDomainDto requestDomainDto = new BaseLoadRequestDomainDto(1L, OperationType.UPDATE);

        final InternalUserLoadResponseDomainDto searchCustomerResponse = new InternalUserLoadResponseDomainDto(1L, "Role 01", "dilanka@asd.com", "dilanka", "Samara", "0777", 1L, "Plant 1", 1L, "Department 1", List.of("Brand 01", "Brand 02"), List.of(1L, 2L));

        final SuccessMessage<InternalUserLoadResponseDomainDto> successMessageBuilder = SuccessMessage.<InternalUserLoadResponseDomainDto>builder()
                .code(SUCCESS_CODE)
                .data(searchCustomerResponse)
                .message(SUCCESS_MESSAGE)
                .timestamp(DateTimeUtils.format(new Date()))
                .build();
        final ResponseEntity<SuccessMessage<InternalUserLoadResponseDomainDto>> successMessage = ResponseEntity.status(HttpStatus.OK).body(successMessageBuilder);

        //when
        when(mapper.convertValue(requestDto, BaseLoadRequestDomainDto.class)).thenReturn(requestDomainDto);
        when(userUserService.loadInternalUser(requestDomainDto)).thenReturn(searchCustomerResponse);
        when(responseUtils.wrapSuccess(searchCustomerResponse, HttpStatus.OK)).thenReturn(successMessage);

        //then
        final ResponseEntity<SuccessMessage<InternalUserLoadResponseDomainDto>> response = assertDoesNotThrow(() -> userController.loadInternalUser(requestDto));
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isNotNull();
    }
}