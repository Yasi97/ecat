package com.booleanlabs.ecatalogue.userservice.application.validator;

import com.booleanlabs.ecatalogue.userservice.application.exception.ValidationException;
import com.booleanlabs.ecatalogue.userservice.application.util.MessageUtils;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Path;
import jakarta.validation.Validator;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.HashSet;

/**
 * @author dilanka
 * @created 07/01/2024 - 11:02 AM
 * @project user-service
 */
@ExtendWith(MockitoExtension.class)
class RequestEntityValidatorTest {
    @Mock
    private Validator validator;
    @Mock
    private MessageUtils messageUtils;

    @InjectMocks
    private RequestEntityValidator requestValidator;

    @Test
    void testValidation() {

        final TestValidateClass object = new TestValidateClass();
        object.setName("");

        final ConstraintViolation<TestValidateClass> mockViolation = Mockito.mock(ConstraintViolation.class);

        Mockito.when(validator.validate(object)).thenReturn(new HashSet<>(Collections.singletonList(mockViolation)));

        Mockito.when(mockViolation.getMessage()).thenReturn("message");

        final Path mockPath = Mockito.mock(Path.class);
        Mockito.when(mockViolation.getPropertyPath()).thenReturn(mockPath);
        Mockito.when(mockPath.toString()).thenReturn("field");

        Assertions.assertThrows(ValidationException.class, () -> requestValidator.validate(object));

        Mockito.verify(mockViolation, Mockito.times(2)).getMessage();
        Mockito.verify(mockViolation, Mockito.times(1)).getPropertyPath();
    }

    @Test
    void testNoViolation() {

        final TestValidateClass object = new TestValidateClass();
        object.setName("abcd");

        Mockito.when(validator.validate(object)).thenReturn(new HashSet<>(Collections.emptyList()));

        Assertions.assertDoesNotThrow(() -> validator.validate(object));
    }

    @Data
    private static class TestValidateClass {

        @NotEmpty
        private String name;
    }
}