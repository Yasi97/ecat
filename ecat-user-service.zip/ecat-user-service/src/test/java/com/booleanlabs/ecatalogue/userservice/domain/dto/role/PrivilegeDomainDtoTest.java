package com.booleanlabs.ecatalogue.userservice.domain.dto.role;

import com.booleanlabs.ecatalogue.userservice.JavaBeanTester;
import org.junit.jupiter.api.Test;

import java.beans.IntrospectionException;

/**
 * @author dilanka
 * @created 25/01/2024 - 9:08 AM
 * @project ecat-user-service
 */
class PrivilegeDomainDtoTest {

    @Test
    void testBeanProperties() throws IntrospectionException {
        JavaBeanTester.test(PrivilegeDomainDto.class, new PrivilegeDomainDto());
    }
}