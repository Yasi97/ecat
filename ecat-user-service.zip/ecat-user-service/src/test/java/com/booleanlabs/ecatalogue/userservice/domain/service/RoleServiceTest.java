package com.booleanlabs.ecatalogue.userservice.domain.service;

import com.booleanlabs.ecatalogue.userservice.domain.dto.BaseResponseMessageDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.role.RoleDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.entities.RoleEntity;
import com.booleanlabs.ecatalogue.userservice.external.repository.RoleRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

/**
 * @author dilanka
 * @created 25/01/2024 - 10:25 AM
 * @project ecat-user-service
 */
@ExtendWith(MockitoExtension.class)
class RoleServiceTest {
    @Mock
    private RoleRepository roleRepository;
    @Mock
    private ObjectMapper mapper;

    @InjectMocks
    private RoleService roleService;

    @Test
    void createRole() {
        //given
        final RoleDomainDto domainDto = new RoleDomainDto(1L, "Role Name", "ROLE_NAME", 2L, false);

        //then
        final BaseResponseMessageDomainDto messageDomainDto = assertDoesNotThrow(() -> roleService.createRole(domainDto));
        assertThat(messageDomainDto.getMessage()).isEqualTo("Role created successfully");
    }

    @Test
    void loadAll() {
        //given
        final List<RoleEntity> roleEntities = List.of(new RoleEntity(1L, "Role_01", "ROLE_01", 1L, false));
        final List<RoleDomainDto> domainDtos = List.of(new RoleDomainDto(1L, "Role_01", "ROLE_01", 1L, false));

        //when
        when(roleRepository.loadAll()).thenReturn(roleEntities);
        when(mapper.convertValue(eq(roleEntities), any(TypeReference.class))).thenReturn(domainDtos);

        //then
        final List<RoleDomainDto> serviceReturn = assertDoesNotThrow(() -> roleService.loadAll());

        assertThat(serviceReturn).isNotNull();
    }
}