package com.booleanlabs.ecatalogue.userservice.external.repository;

import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserCreateDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user.InternalUserUpdateDomainDto;
import com.booleanlabs.ecatalogue.userservice.external.repository.constant.QueryConstants;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

/**
 * @author dilanka
 * @created 21/01/2024 - 8:21 AM
 * @project ecat-user-service
 */
@ExtendWith(MockitoExtension.class)
class UserRepositoryTest {

    @Mock
    private JdbcTemplate jdbcTemplate;

    @InjectMocks
    private UserRepository userRepository;

    @Test
    void isUserExist() {
        //given
        String emailAddress = "test@abc.com";

        //when
        when(jdbcTemplate.queryForObject(QueryConstants.User.COUNT_EMAIL, Integer.class, emailAddress)).thenReturn(1);

        //then
        Boolean result = assertDoesNotThrow(() -> userRepository.isUserExist(emailAddress));
        assertTrue(result);
    }

    @Test
    void isUserNotExist() {
        //given
        String emailAddress = "test@abc.com";

        //when
        when(jdbcTemplate.queryForObject(QueryConstants.User.COUNT_EMAIL, Integer.class, emailAddress)).thenReturn(null);

        //then
        Boolean result = assertDoesNotThrow(() -> userRepository.isUserExist(emailAddress));
        assertFalse(result);
    }

    @Test
    void createUser() {
        //given
        InternalUserCreateDomainDto userCreateDomainDto = new InternalUserCreateDomainDto(1L, "6yZuW@example.com", "dilanka", "Samara", "0777", 1L, 1L, List.of(1L, 2L));

        //when
        when(jdbcTemplate.queryForObject(QueryConstants.User.SEQ_NEXT_VAL, Long.class)).thenReturn(1L);

        //then
        Long id = assertDoesNotThrow(() -> userRepository.createUser(userCreateDomainDto));
        assertThat(id).isEqualTo(1L);
    }

    @Test
    void updateUser() {
        //given
        InternalUserUpdateDomainDto userUpdateDomainDto = new InternalUserUpdateDomainDto(1L, 2L, "dilanka", "Samara", "0777", 1L, 1L, List.of(1L, 2L));

        //when

        //then
        assertDoesNotThrow(() -> userRepository.updateUser(userUpdateDomainDto));
    }
}