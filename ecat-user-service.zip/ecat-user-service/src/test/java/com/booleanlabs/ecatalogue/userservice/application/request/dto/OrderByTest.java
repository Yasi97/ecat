package com.booleanlabs.ecatalogue.userservice.application.request.dto;

import com.booleanlabs.ecatalogue.userservice.JavaBeanTester;
import org.junit.jupiter.api.Test;

import java.beans.IntrospectionException;

/**
 * @author dilanka
 * @created 15/01/2024 - 11:57 AM
 * @project user-service
 */
class OrderByTest {
    @Test
    void testBeanProperties() throws IntrospectionException {
        JavaBeanTester.test(OrderBy.class, new OrderBy());
    }
}