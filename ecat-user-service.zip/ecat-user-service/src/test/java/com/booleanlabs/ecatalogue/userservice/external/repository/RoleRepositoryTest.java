package com.booleanlabs.ecatalogue.userservice.external.repository;

import com.booleanlabs.ecatalogue.userservice.domain.dto.role.RoleDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.entities.RoleEntity;
import com.booleanlabs.ecatalogue.userservice.external.repository.constant.QueryConstants;
import com.booleanlabs.ecatalogue.userservice.external.repository.mapper.role.RoleResultRowMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

/**
 * @author dilanka
 * @created 25/01/2024 - 8:35 AM
 * @project ecat-user-service
 */
@ExtendWith(MockitoExtension.class)
class RoleRepositoryTest {
    @Mock
    private JdbcTemplate jdbcTemplate;

    @InjectMocks
    private RoleRepository roleRepository;

    @Test
    void createRole() {
        //given
        final RoleDomainDto domainDto = new RoleDomainDto(1L, "Role_01", "ROLE_01", 1L, false);

        //when
        when(jdbcTemplate.queryForObject(QueryConstants.ROLE.SEQ_NEXT_VAL, Long.class)).thenReturn(1L);

        //then
        assertDoesNotThrow(() -> roleRepository.createRole(domainDto));
    }

    @Test
    void loadAll() {
        //given
        final RoleEntity roleEntity = new RoleEntity(1L, "Role_01", "ROLE_01", 1L, false);

        //when
        when(jdbcTemplate.query(any(String.class), any(RoleResultRowMapper.class))).thenReturn(List.of(roleEntity));

        //then
        List<RoleEntity> searchResult = assertDoesNotThrow(() -> roleRepository.loadAll());

        assertThat(searchResult)
                .isNotNull()
                .hasSize(1);

        assertThat(searchResult.get(0)).isEqualTo(roleEntity);
    }
}