package com.booleanlabs.ecatalogue.userservice.domain.dto;

import com.booleanlabs.ecatalogue.userservice.JavaBeanTester;
import org.junit.jupiter.api.Test;

import java.beans.IntrospectionException;

/**
 * @author dilanka
 * @created 21/01/2024 - 6:38 AM
 * @project ecat-user-service
 */
class BaseSearchRequestDomainDtoTest {

    @Test
    void testBeanProperties() throws IntrospectionException {
        JavaBeanTester.test(BaseSearchRequestDomainDto.class, new BaseSearchRequestDomainDto());
    }
}