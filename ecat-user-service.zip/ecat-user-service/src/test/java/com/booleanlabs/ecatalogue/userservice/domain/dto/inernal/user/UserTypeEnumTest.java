package com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user;

import com.booleanlabs.ecatalogue.userservice.JavaBeanTester;
import com.booleanlabs.ecatalogue.userservice.domain.dto.UserTypeEnum;
import org.junit.jupiter.api.Test;

import java.beans.IntrospectionException;

/**
 * @author dilanka
 * @created 20/01/2024 - 10:59 AM
 * @project ecat-user-service
 */
class UserTypeEnumTest {

    @Test
    void testGettersAndSetters() throws IntrospectionException {
        JavaBeanTester.test(UserTypeEnum.class, UserTypeEnum.CUSTOMER_ADMIN);
        JavaBeanTester.test(UserTypeEnum.class, UserTypeEnum.ADMIN);
        JavaBeanTester.test(UserTypeEnum.class, UserTypeEnum.CUSTOMER);
    }
}