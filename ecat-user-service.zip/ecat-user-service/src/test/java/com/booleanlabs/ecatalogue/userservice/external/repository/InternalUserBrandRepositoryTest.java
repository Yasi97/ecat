package com.booleanlabs.ecatalogue.userservice.external.repository;

import com.booleanlabs.ecatalogue.userservice.external.repository.constant.QueryConstants;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ParameterizedPreparedStatementSetter;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * @author dilanka
 * @created 20/01/2024 - 11:01 AM
 * @project ecat-user-service
 */
@ExtendWith(MockitoExtension.class)
class InternalUserBrandRepositoryTest {
    @Mock
    private JdbcTemplate jdbcTemplate;

    @Mock
    private PreparedStatement preparedStatement;

    @Captor
    private ArgumentCaptor<ParameterizedPreparedStatementSetter<Long>> preparedStatementSetterCaptor;

    @InjectMocks
    private InternalUserBrandRepository internalUserBrandRepository;

    @Test
    void testCreateInternalUserBrand() throws SQLException {
        // given
        long internalUserId = 123L;
        List<Long> brandIds = List.of(1L, 2L, 3L);

        // when
        when(jdbcTemplate.batchUpdate(anyString(), any(List.class), anyInt(), any(ParameterizedPreparedStatementSetter.class)))
                .thenReturn(new int[][]{{1}, {1}, {1}});

        // then
        internalUserBrandRepository.createInternalUserBrand(internalUserId, brandIds);

        // Assert
        verify(jdbcTemplate).batchUpdate(anyString(), eq(brandIds), anyInt(), preparedStatementSetterCaptor.capture());

        ParameterizedPreparedStatementSetter<Long> capturedSetter = preparedStatementSetterCaptor.getValue();

        capturedSetter.setValues(preparedStatement, 1L);

        verify(preparedStatement).setLong(1, internalUserId);
        verify(preparedStatement).setLong(2, 1L);
    }


    @Test
    void testDeleteInternalUserBrand() {
        //given
        long internalUserId = 1L;

        //when

        //then
        assertDoesNotThrow(() -> internalUserBrandRepository.deleteInternalUserBrand(internalUserId));
    }

    @Test
    void testLoadRead() {
        //given
        long internalUserId = 1L;
        List<String> brandNames = List.of("Brand 1", "Brand 2");

        //when
        when(jdbcTemplate.queryForList(QueryConstants.InternalUserBrand.LOAD_READ, String.class, internalUserId)).thenReturn(brandNames);

        //then
        List<String> list = assertDoesNotThrow(() -> internalUserBrandRepository.loadRead(internalUserId));
        assertNotNull(list);
        assertThat(list).hasSize(2);
    }

    @Test
    void testLoadUpdate() {
        //given
        long internalUserId = 1L;
        List<Long> brandIds = List.of(1L, 2L);

        //when
        when(jdbcTemplate.queryForList(QueryConstants.InternalUserBrand.LOAD_UPDATE, Long.class, internalUserId)).thenReturn(brandIds);

        //then
        List<Long> list = assertDoesNotThrow(() -> internalUserBrandRepository.loadUpdate(internalUserId));
        assertNotNull(list);
        assertThat(list).hasSize(2);
    }

}