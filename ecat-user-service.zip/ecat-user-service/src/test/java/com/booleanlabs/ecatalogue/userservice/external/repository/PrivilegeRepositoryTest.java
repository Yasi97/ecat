package com.booleanlabs.ecatalogue.userservice.external.repository;

import com.booleanlabs.ecatalogue.userservice.domain.dto.role.PrivilegeDomainDto;
import com.booleanlabs.ecatalogue.userservice.external.repository.constant.QueryConstants;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ParameterizedPreparedStatementSetter;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * @author dilanka
 * @created 25/01/2024 - 8:51 AM
 * @project ecat-user-service
 */

@ExtendWith(MockitoExtension.class)
class PrivilegeRepositoryTest {

    @Mock
    private JdbcTemplate jdbcTemplate;

    @Mock
    private PreparedStatement preparedStatement;

    @Captor
    private ArgumentCaptor<ParameterizedPreparedStatementSetter<Long>> preparedStatementSetterCaptor;

    @InjectMocks
    private PrivilegeRepository repository;

    @Test
    void createRolePrivilege() throws SQLException {
        //given
        final List<Long> privilegeIds = List.of(1L, 2L, 3L);
        final PrivilegeDomainDto domainDto = new PrivilegeDomainDto(1L, privilegeIds);

        //when
        when(jdbcTemplate.batchUpdate(anyString(), anyList(), anyInt(), any(ParameterizedPreparedStatementSetter.class)))
                .thenReturn(new int[][]{{1}, {1}, {1}});

        //then
        assertDoesNotThrow(() -> repository.createRolePrivilege(domainDto));

        verify(jdbcTemplate).batchUpdate(anyString(), eq(privilegeIds), anyInt(), preparedStatementSetterCaptor.capture());

        ParameterizedPreparedStatementSetter<Long> capturedSetter = preparedStatementSetterCaptor.getValue();

        capturedSetter.setValues(preparedStatement, 1L);

        verify(preparedStatement).setLong(1, 1L);
        verify(preparedStatement).setLong(2, 1L);
    }

    @Test
    void clearRolePrivilegesByRoleId() {
        //given
        long roleId = 1L;

        //then
        assertDoesNotThrow(() -> repository.clearRolePrivilegesByRoleId(roleId));
    }

    @Test
    void loadUpdate() {
        //given
        final Long roleId = 1L;
        final List<Long> privilegeIds = List.of(1L, 2L, 3L, 4L);

        //when
        when(jdbcTemplate.queryForList(QueryConstants.PRIVILEGE.LOAD, Long.class, roleId)).thenReturn(privilegeIds);

        //then
        final List<Long> list = assertDoesNotThrow(() -> repository.loadUpdate(roleId));
        assertNotNull(list);
        assertThat(list)
                .contains(1L, 2L, 3L, 4L)
                .hasSize(4);
    }
}