package com.booleanlabs.ecatalogue.userservice.application.controller;

import com.booleanlabs.ecatalogue.userservice.application.request.dto.role.PrivilegeCreateRequestDto;
import com.booleanlabs.ecatalogue.userservice.application.response.dto.SuccessMessage;
import com.booleanlabs.ecatalogue.userservice.application.util.DateTimeUtils;
import com.booleanlabs.ecatalogue.userservice.application.util.ResponseUtils;
import com.booleanlabs.ecatalogue.userservice.application.validator.RequestEntityValidator;
import com.booleanlabs.ecatalogue.userservice.domain.dto.BaseResponseMessageDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.role.PrivilegeDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.role.RolePrivilegeSearchResponseDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.service.PrivilegeService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Date;
import java.util.List;

import static com.booleanlabs.ecatalogue.userservice.application.constant.SuccessConstants.SUCCESS_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.SuccessConstants.SUCCESS_MESSAGE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

/**
 * @author dilanka
 * @created 25/01/2024 - 9:23 AM
 * @project ecat-user-service
 */
@ExtendWith(MockitoExtension.class)
class PrivilegeControllerTest {
    @Mock
    private ResponseUtils responseUtils;
    @Mock
    private RequestEntityValidator validator;
    @Mock
    private ObjectMapper mapper;
    @Mock
    private PrivilegeService privilegeService;

    @InjectMocks
    private PrivilegeController controller;

    @Test
    void createRole() {
        //given
        final PrivilegeCreateRequestDto request = new PrivilegeCreateRequestDto(1L, List.of(1L, 2L, 3L));
        final PrivilegeDomainDto domainDto = new PrivilegeDomainDto(11L, List.of(1L, 2L, 3L));
        final BaseResponseMessageDomainDto message = new BaseResponseMessageDomainDto("Privileges added successfully");

        final SuccessMessage<BaseResponseMessageDomainDto> successMessageBuilder = SuccessMessage.<BaseResponseMessageDomainDto>builder()
                .code(SUCCESS_CODE)
                .data(message)
                .message(SUCCESS_MESSAGE)
                .timestamp(DateTimeUtils.format(new Date()))
                .build();
        final ResponseEntity<SuccessMessage<BaseResponseMessageDomainDto>> successMessage = ResponseEntity.status(HttpStatus.CREATED).body(successMessageBuilder);


        //when
        when(mapper.convertValue(any(), eq(PrivilegeDomainDto.class))).thenReturn(domainDto);
        when(privilegeService.createRolePrivileges(any(PrivilegeDomainDto.class))).thenReturn(message);
        when(responseUtils.wrapSuccess(message, HttpStatus.CREATED)).thenReturn(successMessage);

        //then
        final ResponseEntity<SuccessMessage<BaseResponseMessageDomainDto>> response = assertDoesNotThrow(() -> controller.createRole(request));

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        assertThat(response.getBody()).isNotNull();
    }

    @Test
    void loadAll() {
        //given
        final Long id = 1L;
        final RolePrivilegeSearchResponseDomainDto responseDto = new RolePrivilegeSearchResponseDomainDto(List.of(1L, 2L, 3L));

        final SuccessMessage<RolePrivilegeSearchResponseDomainDto> successMessageBuilder = SuccessMessage.<RolePrivilegeSearchResponseDomainDto>builder()
                .code(SUCCESS_CODE)
                .data(responseDto)
                .message(SUCCESS_MESSAGE)
                .timestamp(DateTimeUtils.format(new Date()))
                .build();
        final ResponseEntity<SuccessMessage<RolePrivilegeSearchResponseDomainDto>> successMessage = ResponseEntity.status(HttpStatus.OK).body(successMessageBuilder);


        //when
        when(privilegeService.loadUpdate(id)).thenReturn(responseDto);
        when(responseUtils.wrapSuccess(responseDto, HttpStatus.OK)).thenReturn(successMessage);

        //then
        final ResponseEntity<SuccessMessage<RolePrivilegeSearchResponseDomainDto>> response = assertDoesNotThrow(() -> controller.loadAll(id));

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isNotNull();
    }
}