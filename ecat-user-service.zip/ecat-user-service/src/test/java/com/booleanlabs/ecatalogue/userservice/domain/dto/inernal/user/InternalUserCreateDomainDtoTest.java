package com.booleanlabs.ecatalogue.userservice.domain.dto.inernal.user;

import com.booleanlabs.ecatalogue.userservice.JavaBeanTester;
import org.junit.jupiter.api.Test;

import java.beans.IntrospectionException;

/**
 * @author dilanka
 * @created 20/01/2024 - 10:53 AM
 * @project ecat-user-service
 */
class InternalUserCreateDomainDtoTest {

    @Test
    void testConstructor() throws IntrospectionException {
        JavaBeanTester.test(InternalUserCreateDomainDto.class, new InternalUserCreateDomainDto());
    }
}