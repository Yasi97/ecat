package com.booleanlabs.ecatalogue.userservice.domain.dto.role;

import com.booleanlabs.ecatalogue.userservice.JavaBeanTester;
import org.junit.jupiter.api.Test;

import java.beans.IntrospectionException;

/**
 * @author dilanka
 * @created 25/01/2024 - 9:09 AM
 * @project ecat-user-service
 */
class RoleDomainDtoTest {
    @Test
    void testBeanProperties() throws IntrospectionException {
        JavaBeanTester.test(RoleDomainDto.class, new RoleDomainDto());
    }

}