package com.booleanlabs.ecatalogue.userservice.external.repository.mapper.internal.user;

import com.booleanlabs.ecatalogue.userservice.domain.entities.InternalUserSearchResultEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

/**
 * @author dilanka
 * @created 21/01/2024 - 6:44 AM
 * @project ecat-user-service
 */
@ExtendWith(MockitoExtension.class)
class InternalUserLoadResultRowMapperTest {
    @Mock
    private ResultSet resultSet;

    private final InternalUserLoadResultRowMapper internalUserLoadResultRowMapper = new InternalUserLoadResultRowMapper();

    @Test
    void mapRow() throws SQLException {
        //given

        //then
        when(resultSet.getLong(anyString())).thenReturn(1L);
        when(resultSet.getString(anyString())).thenReturn("Value");

        //when
        InternalUserSearchResultEntity entity = assertDoesNotThrow(() -> internalUserLoadResultRowMapper.mapRow(resultSet, 0));
        assertNotNull(entity);
    }
}