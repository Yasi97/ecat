package com.booleanlabs.ecatalogue.userservice.external.repository.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.when;

/**
 * @author dilanka
 * @created 21/01/2024 - 9:50 AM
 * @project ecat-user-service
 */
@ExtendWith(MockitoExtension.class)
class RepositoryUtilsTest {
    @Mock
    private ResultSet resultSet;

    @Test
    void getLongOrDefault() throws SQLException {
        //when
        when(resultSet.getLong("test")).thenReturn(5L);

        //then
        Long test = assertDoesNotThrow(() -> RepositoryUtils.getLongOrDefault(resultSet, "test", 50L));

        assertThat(test).isEqualTo(5L);
    }

    @Test
    void getLongOrDefaultTest() throws SQLException {

        //when
        when(resultSet.getLong("test")).thenThrow(new RuntimeException("Exception"));

        //then
        Long test = assertDoesNotThrow(() -> RepositoryUtils.getLongOrDefault(resultSet, "test", 50L));

        assertThat(test).isEqualTo(50L);
    }

    @Test
    void getStringOrDefault() throws SQLException {
        //when
        when(resultSet.getString("test")).thenReturn("value");

        //then
        String test = assertDoesNotThrow(() -> RepositoryUtils.getStringOrDefault(resultSet, "test", "default value"));

        assertThat(test).isEqualTo("value");
    }

    @Test
    void getStringOrDefaultTest() throws SQLException {
        //when
        when(resultSet.getString("test")).thenThrow(new RuntimeException("Exception"));

        //then
        String test = assertDoesNotThrow(() -> RepositoryUtils.getStringOrDefault(resultSet, "test", "default value"));

        assertThat(test).isEqualTo("default value");
    }
}