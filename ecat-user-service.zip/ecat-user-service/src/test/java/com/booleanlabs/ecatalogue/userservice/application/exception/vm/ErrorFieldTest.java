package com.booleanlabs.ecatalogue.userservice.application.exception.vm;

import com.booleanlabs.ecatalogue.userservice.JavaBeanTester;
import org.junit.jupiter.api.Test;

import java.beans.IntrospectionException;

/**
 * @author dilanka
 * @created 07/01/2024 - 8:46 AM
 * @project user-service
 */
class ErrorFieldTest {
    @Test
    void test() throws IntrospectionException {
        JavaBeanTester.test(ErrorField.class, null);
    }
}