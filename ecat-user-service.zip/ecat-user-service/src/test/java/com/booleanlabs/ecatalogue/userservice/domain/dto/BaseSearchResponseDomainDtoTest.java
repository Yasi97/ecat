package com.booleanlabs.ecatalogue.userservice.domain.dto;

import com.booleanlabs.ecatalogue.userservice.JavaBeanTester;
import org.junit.jupiter.api.Test;
import org.springframework.data.domain.Page;

import java.beans.IntrospectionException;

/**
 * @author dilanka
 * @created 08/01/2024 - 12:58 PM
 * @project user-service
 */
class BaseSearchResponseDomainDtoTest {
    @Test
    void testBeanProperties() throws IntrospectionException {
        JavaBeanTester.test(BaseSearchResponseDomainDto.class, new BaseSearchResponseDomainDto.BaseSearchResponseDomainDtoBuilder<>().build());
    }

    @Test
    void testBeanPropertiesTwo() throws IntrospectionException {
        JavaBeanTester.test(BaseSearchResponseDomainDto.class, BaseSearchResponseDomainDto.builder().build().calculatePageable(Page.empty()));
    }

    @Test
    void testBeanPropertiesThree() throws IntrospectionException {
        JavaBeanTester.test(BaseSearchResponseDomainDto.class, BaseSearchResponseDomainDto.builder().build().calculatePageable(10L, 0, 10));
    }
}