package com.booleanlabs.ecatalogue.userservice.application.util;

import com.booleanlabs.ecatalogue.userservice.application.exception.vm.ErrorField;
import com.booleanlabs.ecatalogue.userservice.application.response.dto.ErrorMessage;
import com.booleanlabs.ecatalogue.userservice.application.response.dto.ErrorResponse;
import com.booleanlabs.ecatalogue.userservice.application.response.dto.SuccessMessage;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.booleanlabs.ecatalogue.userservice.application.constant.SuccessConstants.ACTION_SUCCESS_MESSAGE;
import static org.mockito.Mockito.when;
import static org.springframework.test.util.AssertionErrors.assertEquals;

/**
 * @author dilanka
 * @created 07/01/2024 - 8:40 AM
 * @project user-service
 */
@ExtendWith(MockitoExtension.class)
class ResponseUtilsTest {
    @Mock
    private HttpServletRequest request;
    @Mock
    private MessageUtils messageUtils;

    @InjectMocks
    private ResponseUtils responseUtils;


    @Test
    void wrapSuccessTest() {
        final String value = "value";
        final ResponseEntity<SuccessMessage<String>> success = responseUtils.wrapSuccess(value, HttpStatus.OK);
        assertEquals("Value should equal to", "value", Objects.requireNonNull(success.getBody()).getData());
        assertEquals("Value should equal to", HttpStatus.OK, success.getStatusCode());
        assertEquals("Value should equal to", "success", success.getBody().getMessage());
        assertEquals("Value should equal to", "0000", success.getBody().getCode());
    }

    @Test
    void wrapSuccessWithMessageTest() {
        final String value = "value";
        when(messageUtils.getPropertyValue(ACTION_SUCCESS_MESSAGE)).thenReturn("%s successfully");

        final ResponseEntity<SuccessMessage<String>> success = responseUtils.wrapSuccess(value,"Created", HttpStatus.OK);
        assertEquals("Value should equal to", "value", Objects.requireNonNull(success.getBody()).getData());
        assertEquals("Value should equal to", HttpStatus.OK, success.getStatusCode());
        assertEquals("Value should equal to", "Created successfully", success.getBody().getMessage());
        assertEquals("Value should equal to", "0000", success.getBody().getCode());
    }

    @Test
    void wrapErrorsTest() {
        final List<ErrorField> errorFieldList = new ArrayList<>();
        final ErrorField errorField = new ErrorField();
        errorField.setMessage("value");
        errorFieldList.add(errorField);

        final ResponseEntity<ErrorMessage> success = responseUtils.wrapErrors(errorFieldList, "code", "type", "msg", HttpStatus.BAD_REQUEST);
        assertEquals("Value should equal to", new ErrorResponse(errorFieldList), Objects.requireNonNull(success.getBody()).getData());
        assertEquals("Value should equal to", HttpStatus.BAD_REQUEST, success.getStatusCode());
        assertEquals("Value should equal to", "msg", success.getBody().getMessage());
        assertEquals("Value should equal to", "code", success.getBody().getCode());

    }
}