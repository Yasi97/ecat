package com.booleanlabs.ecatalogue.userservice.application.controller;

import com.booleanlabs.ecatalogue.userservice.application.request.dto.role.RoleCreateRequest;
import com.booleanlabs.ecatalogue.userservice.application.response.dto.SuccessMessage;
import com.booleanlabs.ecatalogue.userservice.application.util.DateTimeUtils;
import com.booleanlabs.ecatalogue.userservice.application.util.ResponseUtils;
import com.booleanlabs.ecatalogue.userservice.application.validator.RequestEntityValidator;
import com.booleanlabs.ecatalogue.userservice.domain.dto.BaseResponseMessageDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.dto.role.RoleDomainDto;
import com.booleanlabs.ecatalogue.userservice.domain.service.RoleService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Date;
import java.util.List;

import static com.booleanlabs.ecatalogue.userservice.application.constant.SuccessConstants.SUCCESS_CODE;
import static com.booleanlabs.ecatalogue.userservice.application.constant.SuccessConstants.SUCCESS_MESSAGE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

/**
 * @author dilanka
 * @created 25/01/2024 - 9:13 AM
 * @project ecat-user-service
 */
@ExtendWith(MockitoExtension.class)
class RoleControllerTest {
    @Mock
    private ResponseUtils responseUtils;
    @Mock
    private RequestEntityValidator validator;
    @Mock
    private ObjectMapper mapper;
    @Mock
    private RoleService roleService;

    @InjectMocks
    private RoleController controller;

    @Test
    void createRole() {
        //given
        final RoleCreateRequest request = new RoleCreateRequest("Role Name", 2L);
        final RoleDomainDto domainDto = new RoleDomainDto(1L, "Role Name", "ROLE_NAME", 2L, false);
        final BaseResponseMessageDomainDto message = new BaseResponseMessageDomainDto("Role created successfully");

        final SuccessMessage<BaseResponseMessageDomainDto> successMessageBuilder = SuccessMessage.<BaseResponseMessageDomainDto>builder()
                .code(SUCCESS_CODE)
                .data(message)
                .message(SUCCESS_MESSAGE)
                .timestamp(DateTimeUtils.format(new Date()))
                .build();
        final ResponseEntity<SuccessMessage<BaseResponseMessageDomainDto>> successMessage = ResponseEntity.status(HttpStatus.CREATED).body(successMessageBuilder);


        //when
        when(mapper.convertValue(any(), eq(RoleDomainDto.class))).thenReturn(domainDto);
        when(roleService.createRole(any(RoleDomainDto.class))).thenReturn(message);
        when(responseUtils.wrapSuccess(message, HttpStatus.CREATED)).thenReturn(successMessage);

        //then
        final ResponseEntity<SuccessMessage<BaseResponseMessageDomainDto>> response = assertDoesNotThrow(() -> controller.createRole(request));

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        assertThat(response.getBody()).isNotNull();
    }

    @Test
    void loadAll() {
        //given
        final List<RoleDomainDto> domainDtos = List.of(new RoleDomainDto(1L, "Role Name", "ROLE_NAME", 2L, false));

        final SuccessMessage<List<RoleDomainDto>> successMessageBuilder = SuccessMessage.<List<RoleDomainDto>>builder()
                .code(SUCCESS_CODE)
                .data(domainDtos)
                .message(SUCCESS_MESSAGE)
                .timestamp(DateTimeUtils.format(new Date()))
                .build();
        final ResponseEntity<SuccessMessage<List<RoleDomainDto>>> successMessage = ResponseEntity.status(HttpStatus.OK).body(successMessageBuilder);


        //when
        when(roleService.loadAll()).thenReturn(domainDtos);
        when(responseUtils.wrapSuccess(domainDtos, HttpStatus.OK)).thenReturn(successMessage);

        //then
        final ResponseEntity<SuccessMessage<List<RoleDomainDto>>> response = assertDoesNotThrow(() -> controller.loadAll());

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isNotNull();
    }
}