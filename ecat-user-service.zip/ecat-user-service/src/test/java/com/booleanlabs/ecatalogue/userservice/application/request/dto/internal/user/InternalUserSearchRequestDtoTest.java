package com.booleanlabs.ecatalogue.userservice.application.request.dto.internal.user;

import com.booleanlabs.ecatalogue.userservice.JavaBeanTester;
import org.junit.jupiter.api.Test;

import java.beans.IntrospectionException;

/**
 * @author dilanka
 * @created 21/01/2024 - 6:35 AM
 * @project ecat-user-service
 */
class InternalUserSearchRequestDtoTest {

    @Test
    void testBeanProperties() throws IntrospectionException {
        JavaBeanTester.test(InternalUserSearchRequestDto.class, new InternalUserSearchRequestDto());
    }

}