package com.booleanlabs.ecatalogue.productservice.domain.dto;

import com.booleanlabs.ecatalogue.productservice.application.request.dto.OrderBy;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.domain.Sort.Direction;

import java.util.ArrayList;
import java.util.List;

import static com.booleanlabs.ecatalogue.productservice.application.constant.ErrorConstants.ENTITY_ERROR_NOT_NULL;

/**
 * @author dilanka
 * @created 0/01/2024 - 11:28 AM
 * @project ecat-product-service
 */

@Getter
@Setter
public class BaseSearchRequestDomainDto {
    @NotNull(message = ENTITY_ERROR_NOT_NULL)
    private Integer pageIndex = 0;

    private String sortingField = "id";

    // Order by multiple fields
    private String[] sortingFields;

    // Order by multiple fields and direction
    private List<OrderBy> orders = new ArrayList<>();

    private Direction sortingDirection = Direction.ASC;

    @NotNull(message = ENTITY_ERROR_NOT_NULL)
    private Integer itemPerPage = 10;

    private boolean deleted = false;
}
