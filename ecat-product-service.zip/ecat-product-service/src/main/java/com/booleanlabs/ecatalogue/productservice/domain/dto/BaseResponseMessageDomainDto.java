package com.booleanlabs.ecatalogue.productservice.domain.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author dilanka
 * @created 20/01/2024 - 7:55 AM
 * @project ecat-product-service
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BaseResponseMessageDomainDto {
    private String message;
}
