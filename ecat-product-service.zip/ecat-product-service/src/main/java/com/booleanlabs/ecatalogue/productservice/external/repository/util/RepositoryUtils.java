package com.booleanlabs.ecatalogue.productservice.external.repository.util;

import jakarta.annotation.Nullable;
import jakarta.validation.constraints.NotNull;
import lombok.experimental.UtilityClass;

import java.sql.ResultSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@UtilityClass
public class RepositoryUtils {

    /**
     * Append pagination for query
     *
     * @param query     query
     * @param pageSize  page size
     * @param pageIndex page index
     */
    public String addPagination(@NotNull final String query, @NotNull final int pageSize, @NotNull final int pageIndex) {
        return query + " OFFSET " +
                (pageSize) * (pageIndex <= 0 ? 0 : pageIndex - 1) +
                " ROWS FETCH NEXT " +
                pageSize +
                " ROWS ONLY";
    }

    /**
     * Make query count
     *
     * @param query query
     * @return count query
     */
    public static String convertToCount(@NotNull final String query) {
        final Pattern pattern = Pattern.compile("^SELECT\\s+(DISTINCT\\s+)?(.+?)\\s+FROM", Pattern.CASE_INSENSITIVE);
        final Matcher matcher = pattern.matcher(query);
        if (matcher.find()) {
            return matcher.replaceFirst("SELECT COUNT(*) FROM");
        } else {
            throw new IllegalArgumentException("Invalid SELECT query: " + query);
        }
    }

    /**
     * Get long or default
     * @param rs result set
     * @param column column name
     * @param defaultValue default value
     * @return long
     */
    public static Long getLongOrDefault(@NotNull ResultSet rs, @NotNull String column, @Nullable Long defaultValue) {
        try {
            return rs.getLong(column);
        } catch (Exception e) {
            return defaultValue;
        }
    }

    /**
     * Get string or default
     * @param rs result set
     * @param column column name
     * @param defaultValue default value
     * @return string
     */
    public static String getStringOrDefault(@NotNull ResultSet rs, @NotNull String column, @Nullable String defaultValue) {
        try {
            return rs.getString(column);
        } catch (Exception e) {
            return defaultValue;
        }
    }
}
