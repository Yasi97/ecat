package com.booleanlabs.ecatalogue.productservice.domain.boundary;

public interface AsyncAdaptorInterface {

    void runAll(Long timeout, Runnable... tasks);

    void runAsync(Runnable task);

}
