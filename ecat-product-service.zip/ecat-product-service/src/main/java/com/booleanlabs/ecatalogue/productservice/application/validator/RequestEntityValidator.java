package com.booleanlabs.ecatalogue.productservice.application.validator;

import com.booleanlabs.ecatalogue.productservice.application.exception.ValidationException;
import com.booleanlabs.ecatalogue.productservice.application.exception.vm.ErrorField;
import com.booleanlabs.ecatalogue.productservice.application.util.MessageUtils;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.function.Function;

import static com.booleanlabs.ecatalogue.productservice.application.constant.AppConstants.COLON;
import static com.booleanlabs.ecatalogue.productservice.application.constant.ErrorConstants.CONSTRAINT_VIOLATION_ERROR_CODE;


@Component
public class RequestEntityValidator {

    private final Validator validator;
    private final MessageUtils messageUtils;

    public RequestEntityValidator(Validator validator, MessageUtils messageUtils) {
        this.validator = validator;
        this.messageUtils = messageUtils;
    }

    /**
     * Request Entity Validation
     *
     * @param target Target
     * @param <T>    Target type
     * @throws ValidationException Validation Exception
     */
    public <T> void validate(T target) throws ValidationException {

        validate(target, t -> Collections.emptyList());
    }

    /**
     * Request Entity Validation With Custom Validations
     *
     * @param target          Target
     * @param customValidator Custom validator
     * @param <T>             Target type
     * @throws ValidationException Validation Exception
     */
    public <T> void validate(T target, Function<T, List<ErrorField>> customValidator) throws ValidationException {

        Set<ConstraintViolation<T>> errors = this.validator.validate(target);

        List<ErrorField> errorFields = convertToErrorFields(errors);
        errorFields.addAll(customValidator.apply(target));

        if (CollectionUtils.isNotEmpty(errorFields)) {
            throw new ValidationException(errorFields);
        }
    }

    private <T> List<ErrorField> convertToErrorFields(Set<ConstraintViolation<T>> violations) {

        List<ErrorField> errorFields = new ArrayList<>();
        violations.forEach(error -> {
            final String[] mValues;
            if (error.getMessage().contains(COLON)) {
                mValues = error.getMessage().split(COLON);
            } else {
                mValues = new String[]{messageUtils.getPropertyValue(CONSTRAINT_VIOLATION_ERROR_CODE), error.getMessage()};
            }
            ErrorField errorField = new ErrorField();
            errorField.setCode(mValues[0]);
            errorField.setField(error.getPropertyPath().toString());
            errorField.setMessage(mValues[1]);
            errorFields.add(errorField);
        });

        return errorFields;
    }

}
