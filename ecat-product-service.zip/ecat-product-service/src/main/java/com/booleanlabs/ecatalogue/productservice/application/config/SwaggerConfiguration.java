package com.booleanlabs.ecatalogue.productservice.application.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.springdoc.core.utils.SpringDocUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.Errors;

import java.awt.print.Pageable;
import java.util.Date;

@Configuration

public class SwaggerConfiguration {

    @Bean
    public OpenAPI swaggerSpringdocOpenAPI() {

        SpringDocUtils.getConfig().addAnnotationsToIgnore(Pageable.class, Errors.class, java.sql.Date.class);
        SpringDocUtils.getConfig().replaceWithClass(java.time.LocalDate.class, java.sql.Date.class);
        SpringDocUtils.getConfig().replaceWithClass(java.time.ZonedDateTime.class, Date.class);
        SpringDocUtils.getConfig().replaceWithClass(java.time.LocalDateTime.class, Date.class);

        return new OpenAPI()
                .info(metaData());
    }

    private Info metaData() {
        return new Info()
                .title("Api Documentation")
                .description("Api Documentation")
                .version("1.0.0")
                .license(new License().name("Apache License Version 2.0").url("https://www.apache.org/licenses/LICENSE-2.0"))
                .contact(new Contact().name("Boolean Labs").url("https://www.booleanlabs.biz/").email("admin@www.booleanlabs.biz"));
    }

}