package com.booleanlabs.ecatalogue.productservice.domain.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.domain.Page;

import java.util.List;

/**
 * @author dilanka
 * @created 0/01/2024 - 11:28 AM
 * @project ecat-product-service
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BaseSearchResponseDomainDto<T> {
    @Builder.Default
    private long totalItems = 1;
    @Builder.Default
    private long totalPages = 1;
    @Builder.Default
    private int currentPage = 0;
    private List<T> items;

    /**
     * @param page non null value required.
     * @return {@link BaseSearchResponseDomainDto}
     * <p> Using {@link Page} to calculate totalItems, totalPages, currentPage <p/>
     */
    public BaseSearchResponseDomainDto<T> calculatePageable(@NotNull Page<?> page) {
        this.totalItems = page.getTotalElements();
        this.totalPages = page.getTotalPages();
        this.currentPage = page.getNumber();
        return this;
    }

    /**
     * Calculate page datas
     * @param totalItems total items
     * @param currentPage current page
     * @param itemPerPage item per page
     * @return {@link BaseSearchResponseDomainDto}
     */
    public BaseSearchResponseDomainDto<T> calculatePageable(@NotNull Long totalItems, @NotNull Integer currentPage,@NotNull Integer itemPerPage) {
        this.totalItems = totalItems;
        this.totalPages = (int) Math.ceil((double) totalItems / itemPerPage);
        this.currentPage = currentPage;
        return this;
    }
}
