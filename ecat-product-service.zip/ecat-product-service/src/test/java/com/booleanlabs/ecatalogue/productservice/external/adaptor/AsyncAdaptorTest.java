package com.booleanlabs.ecatalogue.productservice.external.adaptor;

import org.junit.jupiter.api.Test;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ConcurrentTaskExecutor;

import java.util.concurrent.Executors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;

/**
 * @author dilanka
 * @created 15/01/2024 - 11:54 AM
 * @project ecat-product-service
 */
class AsyncAdaptorTest {
    @Test
    void runAsyncTest() {

        final Runnable runnable = mock(Runnable.class);

        final TaskExecutor mockExecutor = mock(TaskExecutor.class);
        doAnswer(invocationOnMock -> {
            ((Runnable) invocationOnMock.getArgument(0)).run();
            return null;
        }).when(mockExecutor).execute(any(Runnable.class));

        new AsyncAdaptor(mockExecutor).runAsync(runnable);

        verify(runnable, times(1)).run();
        verifyNoMoreInteractions(runnable);
    }

    @Test
    void runAllWithTimeOut() {
        final Runnable mockRunnable1 = mock(Runnable.class);
        final Runnable mockRunnable2 = mock(Runnable.class);
        new AsyncAdaptor(new ConcurrentTaskExecutor(Executors.newFixedThreadPool(1))).runAll(50000L, mockRunnable1, mockRunnable2);
        verify(mockRunnable1, times(1)).run();
        verify(mockRunnable2, times(1)).run();
    }

    @Test
    void runAllExceptionWithTimeOut() {
        final Runnable mockRunnable1 = mock(Runnable.class);
        final Runnable mockRunnable2 = mock(Runnable.class);
        doAnswer(invocationOnMock -> {
            throw new RuntimeException("Exception");
        }).when(mockRunnable1).run();
        final ConcurrentTaskExecutor executor = new ConcurrentTaskExecutor(Executors.newFixedThreadPool(1));
        final AsyncAdaptor asyncAdaptor = new AsyncAdaptor(executor);
        final RuntimeException ex = assertThrows(RuntimeException.class, () -> asyncAdaptor.runAll(50000L, mockRunnable1, mockRunnable2));
        assertNotNull(ex);
        assertEquals("Exception", ex.getMessage());
    }
}