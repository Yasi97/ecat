package com.booleanlabs.ecatalogue.productservice.application.util;

import com.booleanlabs.ecatalogue.productservice.application.exception.vm.ErrorField;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.MessageSource;

import java.util.Locale;

import static com.booleanlabs.ecatalogue.productservice.application.constant.ErrorConstants.ERROR_0045;
import static com.booleanlabs.ecatalogue.productservice.application.constant.ErrorConstants.NULL_POINTER_ERROR_MESSAGE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

/**
 * @author dilanka
 * @created 07/01/2024 - 11:03 AM
 * @project ecat-product-service
 */
@ExtendWith(MockitoExtension.class)
class MessageUtilsTest {
    @Mock
    private MessageSource messageSource;

    @InjectMocks
    private MessageUtils messageUtils;

    @Test
    void getErrorField() {
        final String messageValue = "0045:Field can not be set to null";
        when(messageSource.getMessage(ERROR_0045, null, Locale.getDefault())).thenReturn(messageValue);
        final ErrorField result = messageUtils.getErrorField(ERROR_0045);
        assertEquals("0045", result.getCode());
    }

    @Test
    void getPropertyValue() {
        final String messageValue = "Null Pointer Exception Occurred";
        when(messageSource.getMessage(NULL_POINTER_ERROR_MESSAGE, null, Locale.getDefault())).thenReturn(messageValue);
        final String result = messageUtils.getPropertyValue(NULL_POINTER_ERROR_MESSAGE);
        assertEquals(messageValue, result);
    }
}