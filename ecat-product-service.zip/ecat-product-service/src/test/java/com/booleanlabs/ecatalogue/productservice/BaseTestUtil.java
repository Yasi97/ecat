/**
 * The BaseTestUtil class provide common functionality for test classes.
 *
 * @author Asiri Samaraweera
 * @version 1.0
 */
package com.booleanlabs.ecatalogue.productservice;

import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Field;

@ExtendWith(MockitoExtension.class)
public class BaseTestUtil {
    @Mock
    private HttpServletRequest request;

    public void setValueToPrivateField(final Object objectInstance, final String fieldName, final Object value)
            throws NoSuchFieldException, IllegalAccessException {
        final Class<?> clazz = objectInstance.getClass();
        final Field field = clazz.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(objectInstance, value);
    }

    public HttpServletRequest mockHttpServletRequest(final Object object, final boolean isFieldInject)
            throws NoSuchFieldException, IllegalAccessException {
        if (isFieldInject) {
            setValueToPrivateField(object, "request", request);
        }
        return request;
    }

}