package com.booleanlabs.ecatalogue.productservice.application.response.dto;

import com.booleanlabs.ecatalogue.productservice.JavaBeanTester;
import org.junit.jupiter.api.Test;

import java.beans.IntrospectionException;

/**
 * @author dilanka
 * @created 07/01/2024 - 8:13 AM
 * @project ecat-product-service
 */
class SuccessMessageTest {
    @Test
    void testBeanProperties() throws IntrospectionException {
        JavaBeanTester.test(SuccessMessage.class, new SuccessMessage.SuccessMessageBuilder<>().build());
    }
}