package com.booleanlabs.ecatalogue.productservice.domain.dto;

import com.booleanlabs.ecatalogue.productservice.JavaBeanTester;
import org.junit.jupiter.api.Test;

import java.beans.IntrospectionException;

/**
 * @author dilanka
 * @created 20/01/2024 - 10:53 AM
 * @project ecat-product-service
 */
class BaseResponseMessageDomainDtoTest {

    @Test
    void testBeanProperties() throws IntrospectionException {
        JavaBeanTester.test(BaseResponseMessageDomainDto.class, new BaseResponseMessageDomainDto());
    }
    @Test
    void testGettersAndSetters() throws IntrospectionException {
        JavaBeanTester.test(BaseResponseMessageDomainDto.class, new BaseResponseMessageDomainDto("Test"));
    }
}