package com.booleanlabs.ecatalogue.productservice.application.request.dto;

import com.booleanlabs.ecatalogue.productservice.JavaBeanTester;
import org.junit.jupiter.api.Test;

import java.beans.IntrospectionException;

/**
 * @author dilanka
 * @created 15/01/2024 - 11:57 AM
 * @project ecat-product-service
 */
class OrderByTest {
    @Test
    void testBeanProperties() throws IntrospectionException {
        JavaBeanTester.test(OrderBy.class, new OrderBy());
    }
}