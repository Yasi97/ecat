package com.booleanlabs.ecatalogue.productservice.application.request.dto;

import com.booleanlabs.ecatalogue.productservice.JavaBeanTester;
import org.junit.jupiter.api.Test;

import java.beans.IntrospectionException;

/**
 * @author dilanka
 * @created 21/01/2024 - 9:08 AM
 * @project ecat-product-service
 */
class BaseLoadRequestTest {
    @Test
    void testBeanProperties() throws IntrospectionException {
        JavaBeanTester.test(BaseLoadRequest.class, new BaseLoadRequest());
    }
}