package com.booleanlabs.ecatalogue.productservice.application.exception.vm;

import com.booleanlabs.ecatalogue.productservice.JavaBeanTester;
import org.junit.jupiter.api.Test;

import java.beans.IntrospectionException;

/**
 * @author dilanka
 * @created 07/01/2024 - 8:46 AM
 * @project ecat-product-service
 */
class ErrorFieldTest {
    @Test
    void test() throws IntrospectionException {
        JavaBeanTester.test(ErrorField.class, null);
    }
}