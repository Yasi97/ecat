package com.booleanlabs.ecatalogue.productservice.application.exception;

import com.booleanlabs.ecatalogue.productservice.application.exception.vm.ErrorField;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * @author dilanka
 * @created 07/01/2024 - 8:47 AM
 * @project ecat-product-service
 */
class ValidationExceptionTest {
    private ValidationException validationException;

    @BeforeEach
    public void init() {
        final List<ErrorField> errorFields = List.of(
                ErrorField.of("0003", "name", "field can not be null")
        );
        validationException = new ValidationException(errorFields);
    }

    @Test
    void test() {
        assertThat(validationException.getErrors()).isNotEmpty();
        assertThat(validationException.getErrors().stream().findFirst()).isNotEmpty();
        assertThat(validationException.getErrors().stream().findFirst().get().getCode()).isEqualTo("0003");
        assertThat(validationException.getErrors().stream().findFirst().get().getField()).isEqualTo("name");
        assertThat(validationException.getErrors().stream().findFirst().get().getMessage()).isEqualTo("field can not be null");
    }
}