package com.booleanlabs.ecatalogue.productservice.application.response.dto;

import com.booleanlabs.ecatalogue.productservice.JavaBeanTester;
import org.junit.jupiter.api.Test;

import java.beans.IntrospectionException;

/**
 * @author dilanka
 * @created 07/01/2024 - 8:15 AM
 * @project ecat-product-service
 */
class ErrorResponseTest {
    @Test
    void testBeanProperties() throws IntrospectionException {
        JavaBeanTester.test(ErrorResponse.class, new ErrorResponse());
    }
}